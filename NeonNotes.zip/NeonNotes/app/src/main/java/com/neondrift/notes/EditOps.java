package com.neondrift.notes;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Операции кнопок форматирования над текстом и выделением. Без Android — всё проверяется тестами.
 * Каждая операция возвращает новый текст и новое выделение.
 */
final class EditOps {
    private EditOps() {}

    static final class Result {
        final String text;
        final int start, end;

        Result(String text, int start, int end) {
            this.text = text;
            this.start = Math.max(0, Math.min(text.length(), start));
            this.end = Math.max(this.start, Math.min(text.length(), end));
        }
    }

    static final int P_CHECK = 1, P_BULLET = 2, P_NUMBER = 3, P_QUOTE = 4;

    private static final Pattern ANY_PREFIX = Pattern.compile("^(\\s*)(?:[-*+] \\[[ xX]\\] ?|[-*+] |\\d{1,4}[.)] |> ?)?(.*)$");

    static int lineStart(String t, int pos) {
        pos = Math.max(0, Math.min(t.length(), pos));
        int i = t.lastIndexOf('\n', pos - 1);
        return i + 1;
    }

    static int lineEnd(String t, int pos) {
        pos = Math.max(0, Math.min(t.length(), pos));
        int i = t.indexOf('\n', pos);
        return i < 0 ? t.length() : i;
    }

    private static boolean isWord(char c) {
        return Character.isLetterOrDigit(c) || c == '\'' || c == '’';
    }

    // ================================================================== строчные стили

    /** Обернуть выделение маркером (**, _, ~~, ==, `) или снять обёртку, если она уже есть. */
    static Result wrap(String t, int s, int e, String mk) {
        if (s > e) { int x = s; s = e; e = x; }
        s = Math.max(0, s);
        e = Math.min(t.length(), e);
        int n = mk.length();
        // выделение вместе с маркерами
        if (e - s >= 2 * n && t.startsWith(mk, s) && t.startsWith(mk, e - n) && !t.substring(s, e).contains("\n")) {
            String inner = t.substring(s + n, e - n);
            return new Result(t.substring(0, s) + inner + t.substring(e), s, s + inner.length());
        }
        // маркеры сразу снаружи выделения или вокруг слова под курсором
        int ws = s, we = e;
        if (s == e) {
            while (ws > 0 && isWord(t.charAt(ws - 1))) ws--;
            while (we < t.length() && isWord(t.charAt(we))) we++;
        }
        if (ws >= n && we + n <= t.length() && t.startsWith(mk, ws - n) && t.startsWith(mk, we)
                && !(n == 1 && ws >= 2 && t.charAt(ws - 2) == mk.charAt(0))) {
            String out = t.substring(0, ws - n) + t.substring(ws, we) + t.substring(we + n);
            return new Result(out, s - n, e - n);
        }
        if (s == e) {
            if (we > ws) { // слово под курсором
                String out = t.substring(0, ws) + mk + t.substring(ws, we) + mk + t.substring(we);
                return new Result(out, s + n, s + n);
            }
            return new Result(t.substring(0, s) + mk + mk + t.substring(s), s + n, s + n);
        }
        // каждая строка выделения — отдельно: разметка не переходит через перевод строки
        StringBuilder sb = new StringBuilder(t.substring(0, s));
        int pos = s, newStart = s, newEnd = e;
        boolean first = true;
        while (pos <= e) {
            int le = t.indexOf('\n', pos);
            if (le < 0 || le > e) le = e;
            int a = pos, b = le;
            while (a < b && Character.isWhitespace(t.charAt(a))) a++;
            while (b > a && Character.isWhitespace(t.charAt(b - 1))) b--;
            sb.append(t, pos, a);
            if (b > a) {
                if (first) newStart = sb.length() + n;
                sb.append(mk).append(t, a, b);
                newEnd = sb.length();
                sb.append(mk);
                first = false;
            }
            sb.append(t, b, le);
            if (le < e) sb.append('\n');
            pos = le + 1;
            if (le == e) break;
        }
        sb.append(t.substring(e));
        return new Result(sb.toString(), newStart, newEnd);
    }

    // ================================================================== начала строк

    /** Включить или выключить тип пункта (чек-лист, маркер, номер, цитата) у строк выделения. */
    static Result prefix(String t, int s, int e, int kind) {
        if (s > e) { int x = s; s = e; e = x; }
        int bs = lineStart(t, s), be = lineEnd(t, e);
        String[] lines = t.substring(bs, be).split("\n", -1);
        boolean all = true, any = false;
        for (String l : lines) {
            if (l.trim().isEmpty() && lines.length > 1) continue;
            any = true;
            if (kindOf(l) != kind) all = false;
        }
        boolean remove = any && all;
        StringBuilder sb = new StringBuilder();
        int num = 1, firstDelta = 0, firstPrefix = 0;
        for (int i = 0; i < lines.length; i++) {
            String l = lines[i];
            if (i > 0) sb.append('\n');
            if (l.trim().isEmpty() && lines.length > 1) {
                sb.append(l);
                continue;
            }
            Matcher m = ANY_PREFIX.matcher(l);
            m.matches();
            String indent = m.group(1), rest = m.group(2);
            String p;
            if (remove) p = "";
            else if (kind == P_CHECK) p = "- [ ] ";
            else if (kind == P_BULLET) p = "- ";
            else if (kind == P_NUMBER) p = (num++) + ". ";
            else p = "> ";
            String nl = (kind == P_QUOTE && !remove ? "" : indent) + p + rest;
            if (i == 0) {
                firstDelta = nl.length() - l.length();
                firstPrefix = (kind == P_QUOTE && !remove ? 0 : indent.length()) + p.length();
            }
            sb.append(nl);
        }
        String out = t.substring(0, bs) + sb + t.substring(be);
        if (s == e) {
            int c = Math.max(bs + firstPrefix, s + firstDelta);
            return new Result(out, c, c);
        }
        return new Result(out, bs, bs + sb.length());
    }

    static int kindOf(String line) {
        if (Md.CHECK_LINE.matcher(line).matches()) return P_CHECK;
        if (Md.BULLET_LINE.matcher(line).matches()) return P_BULLET;
        if (Md.NUMBER_LINE.matcher(line).matches()) return P_NUMBER;
        if (line.startsWith(">")) return P_QUOTE;
        return 0;
    }

    /** Заголовок по кругу: обычный → # → ## → ### → обычный. */
    static Result heading(String t, int s, int e) {
        int bs = lineStart(t, s), be = lineEnd(t, e);
        String first = t.substring(bs, lineEnd(t, bs));
        Matcher fm = Md.HEADING.matcher(first);
        int lvl = fm.matches() ? fm.group(1).length() : 0;
        int next = (lvl + 1) % 4;
        String[] lines = t.substring(bs, be).split("\n", -1);
        StringBuilder sb = new StringBuilder();
        int firstDelta = 0;
        for (int i = 0; i < lines.length; i++) {
            String l = lines[i];
            if (i > 0) sb.append('\n');
            Matcher m = Md.HEADING.matcher(l);
            String rest = m.matches() ? m.group(2) : l;
            String nl = (next == 0 ? "" : "###".substring(0, next) + " ") + rest;
            if (i == 0) firstDelta = nl.length() - l.length();
            sb.append(nl);
        }
        String out = t.substring(0, bs) + sb + t.substring(be);
        if (s == e) {
            int c = Math.max(bs + (next == 0 ? 0 : next + 1), s + firstDelta);
            return new Result(out, c, c);
        }
        return new Result(out, bs, bs + sb.length());
    }

    /** Сдвиг строк вправо (+2 пробела) или влево. */
    static Result indent(String t, int s, int e, boolean in) {
        if (s > e) { int x = s; s = e; e = x; }
        int bs = lineStart(t, s), be = lineEnd(t, e);
        String[] lines = t.substring(bs, be).split("\n", -1);
        StringBuilder sb = new StringBuilder();
        int firstDelta = 0, total = 0;
        for (int i = 0; i < lines.length; i++) {
            String l = lines[i];
            if (i > 0) sb.append('\n');
            String nl;
            if (in) nl = l.isEmpty() ? l : "  " + l;
            else {
                int k = 0;
                while (k < 2 && k < l.length() && l.charAt(k) == ' ') k++;
                if (k == 0 && l.startsWith("\t")) k = 1;
                nl = l.substring(k);
            }
            if (i == 0) firstDelta = nl.length() - l.length();
            total += nl.length() - l.length();
            sb.append(nl);
        }
        String out = t.substring(0, bs) + sb + t.substring(be);
        if (s == e) {
            int c = Math.max(bs, s + firstDelta);
            return new Result(out, c, c);
        }
        return new Result(out, Math.max(bs, s + firstDelta), e + total);
    }

    static Result insert(String t, int s, int e, String ins) {
        if (s > e) { int x = s; s = e; e = x; }
        return new Result(t.substring(0, s) + ins + t.substring(e), s + ins.length(), s + ins.length());
    }

    /** Разделитель на отдельной строке. */
    static Result divider(String t, int s, int e) {
        if (s > e) { int x = s; s = e; e = x; }
        String before = t.substring(0, s), after = t.substring(e);
        String ins = (before.isEmpty() || before.endsWith("\n") ? "" : "\n") + "---\n";
        if (!after.isEmpty() && after.startsWith("\n")) after = after.substring(1);
        String out = before + ins + after;
        return new Result(out, s + ins.length(), s + ins.length());
    }

    // ================================================================== Enter в списке

    /**
     * Сразу после того как пользователь вставил перевод строки в позицию nl.
     * Продолжает список, закрывает пустой пункт или поднимает вложенный на уровень выше.
     * null — ничего делать не нужно.
     */
    static Result afterNewline(String t, int nl) {
        if (nl < 0 || nl >= t.length() || t.charAt(nl) != '\n') return null;
        int ps = lineStart(t, nl);
        String prev = t.substring(ps, nl);
        String cont = Md.continueList(prev);
        if (cont == null) return null;
        int restEnd = lineEnd(t, nl + 1);
        boolean restEmpty = t.substring(nl + 1, restEnd).trim().isEmpty();
        if (cont.equals(Md.END_LIST)) {
            if (!restEmpty) {
                // Enter в самом начале текста пункта: пустой пункт остаётся сверху, текст уходит в новый
                String p = Md.continueList(prev + "x");
                if (p == null || p.equals(Md.END_LIST)) return null;
                String out = t.substring(0, nl + 1) + p + t.substring(nl + 1);
                out = renumberAt(out, lineIndex(out, nl + 1));
                return new Result(out, nl + 1 + p.length(), nl + 1 + p.length());
            }
            int lead = 0;
            while (lead < prev.length() && prev.charAt(lead) == ' ') lead++;
            if (lead >= 2) { // вложенный пустой пункт — на уровень выше
                String up = prev.substring(2);
                String out = t.substring(0, ps) + up + t.substring(nl + 1);
                int c = ps + up.length();
                return new Result(out, c, c);
            }
            // пустой пункт закрывает список
            String out = t.substring(0, ps) + t.substring(nl + 1);
            return new Result(out, ps, ps);
        }
        String out = t.substring(0, nl + 1) + cont + t.substring(nl + 1);
        if (Md.NUMBER_LINE.matcher(cont + "x").matches()) out = renumberAt(out, lineIndex(out, nl + 1));
        int c = nl + 1 + cont.length();
        return new Result(out, c, c);
    }

    static int lineIndex(String t, int pos) {
        int n = 0;
        for (int i = 0; i < pos && i < t.length(); i++) if (t.charAt(i) == '\n') n++;
        return n;
    }

    /** Перенумеровать пункты после строки lineIndex (тот же отступ, до конца списка). */
    static String renumberAt(String t, int lineIndex) {
        String[] lines = t.split("\n", -1);
        if (lineIndex < 0 || lineIndex >= lines.length) return t;
        Matcher m = Md.NUMBER_LINE.matcher(lines[lineIndex]);
        if (!m.matches()) return t;
        String indent = m.group(1);
        int n = Integer.parseInt(m.group(2));
        boolean changed = false;
        for (int i = lineIndex + 1; i < lines.length; i++) {
            String l = lines[i];
            Matcher k = Md.NUMBER_LINE.matcher(l);
            if (k.matches() && k.group(1).equals(indent)) {
                n++;
                String nl = indent + n + k.group(3) + " " + k.group(4);
                if (!nl.equals(l)) { lines[i] = nl; changed = true; }
                continue;
            }
            int lead = 0;
            while (lead < l.length() && l.charAt(lead) == ' ') lead++;
            if (!l.trim().isEmpty() && lead > indent.length()) continue; // вложенные строки пропускаем
            break;
        }
        return changed ? String.join("\n", lines) : t;
    }

    /**
     * Позиция в тексте приходится на служебное начало пункта чек-листа? Тогда вернуть номер строки.
     * Нужно, чтобы нажатие на нарисованную галочку в редакторе отмечало пункт.
     */
    static int checkAt(String t, int pos) {
        int ls = lineStart(t, pos), le = lineEnd(t, pos);
        Matcher m = Md.CHECK_LINE.matcher(t.substring(ls, le));
        if (!m.matches()) return -1;
        int bs = ls + m.start(2);
        return pos >= bs && pos <= bs + 5 ? lineIndex(t, ls) : -1;
    }

    /** Все строки-пункты выделены? Нужно для подсветки кнопок панели. */
    static int kindAt(String t, int pos) {
        return kindOf(t.substring(lineStart(t, pos), lineEnd(t, pos)));
    }

    /**
     * Служебное начало пункта в строке с позицией pos: {начало маркера, начало текста} или null.
     * Backspace сразу перед текстом пункта снимает маркер целиком, как в обычных редакторах.
     */
    static int[] markerRange(String t, int pos) {
        int ls = lineStart(t, pos), le = lineEnd(t, pos);
        String line = t.substring(ls, le);
        Matcher m;
        if ((m = Md.CHECK_LINE.matcher(line)).matches()) return new int[]{ls + m.start(2), ls + m.start(4)};
        if ((m = Md.BULLET_LINE.matcher(line)).matches()) return new int[]{ls + m.start(2), ls + m.start(3)};
        if ((m = Md.NUMBER_LINE.matcher(line)).matches()) return new int[]{ls + m.start(2), ls + m.start(4)};
        if ((m = Md.QUOTE_LINE.matcher(line)).matches()) return new int[]{ls, ls + m.start(1)};
        return null;
    }

    static List<int[]> lines(String t) {
        return Md.lines(t);
    }
}
