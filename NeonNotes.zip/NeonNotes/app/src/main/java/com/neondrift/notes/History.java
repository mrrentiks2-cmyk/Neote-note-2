package com.neondrift.notes;

import java.util.ArrayList;

/**
 * Отмена и повтор правок текста. Подряд набранные символы склеиваются в одну правку,
 * автоматические правки (продолжение списка) отменяются вместе с вызвавшим их нажатием.
 */
final class History {
    static final class Edit {
        final int start;
        String before, after;
        long time;
        final int group;

        Edit(int start, String before, String after, long time, int group) {
            this.start = start;
            this.before = before;
            this.after = after;
            this.time = time;
            this.group = group;
        }
    }

    private static final int LIMIT = 300;
    private static final long MERGE_MS = 1500;

    private final ArrayList<Edit> undo = new ArrayList<>(), redo = new ArrayList<>();
    private int groups;

    /** Записать замену before → after в позиции start. join — приклеить к предыдущему действию. */
    void record(int start, String before, String after, long now, boolean join) {
        if (before.equals(after)) return;
        redo.clear();
        Edit last = undo.isEmpty() ? null : undo.get(undo.size() - 1);
        if (last != null && !join && now - last.time < MERGE_MS) {
            boolean typing = before.isEmpty() && last.before.isEmpty() && !after.isEmpty()
                    && start == last.start + last.after.length() && after.indexOf('\n') < 0
                    && last.after.indexOf('\n') < 0 && !(isSpace(after) && !isSpace(last.after.substring(last.after.length() - 1)));
            boolean erasing = after.isEmpty() && last.after.isEmpty() && !before.isEmpty()
                    && start + before.length() == last.start && before.indexOf('\n') < 0;
            if (typing) {
                last.after = last.after + after;
                last.time = now;
                return;
            }
            if (erasing) {
                undo.set(undo.size() - 1, new Edit(start, before + last.before, "", now, last.group));
                return;
            }
        }
        int g = join && last != null ? last.group : ++groups;
        undo.add(new Edit(start, before, after, now, g));
        while (undo.size() > LIMIT) undo.remove(0);
    }

    private static boolean isSpace(String s) {
        return !s.isEmpty() && s.trim().isEmpty();
    }

    boolean canUndo() {
        return !undo.isEmpty();
    }

    boolean canRedo() {
        return !redo.isEmpty();
    }

    /** Правки для отмены (в порядке применения). Каждую применять как замену after → before. */
    ArrayList<Edit> undo() {
        ArrayList<Edit> out = new ArrayList<>();
        if (undo.isEmpty()) return out;
        int g = undo.get(undo.size() - 1).group;
        while (!undo.isEmpty() && undo.get(undo.size() - 1).group == g) {
            Edit e = undo.remove(undo.size() - 1);
            out.add(e);
            redo.add(e);
        }
        return out;
    }

    /** Правки для повтора (в порядке применения). Каждую применять как замену before → after. */
    ArrayList<Edit> redo() {
        ArrayList<Edit> out = new ArrayList<>();
        if (redo.isEmpty()) return out;
        int g = redo.get(redo.size() - 1).group;
        while (!redo.isEmpty() && redo.get(redo.size() - 1).group == g) {
            Edit e = redo.remove(redo.size() - 1);
            out.add(e);
            undo.add(e);
        }
        return out;
    }

    /** Применить отмену к строке — для тестов и для простых случаев. */
    static String applyUndo(String text, Edit e) {
        return text.substring(0, e.start) + e.before + text.substring(e.start + e.after.length());
    }

    static String applyRedo(String text, Edit e) {
        return text.substring(0, e.start) + e.after + text.substring(e.start + e.before.length());
    }

    void clear() {
        undo.clear();
        redo.clear();
    }
}
