package com.neondrift.notes;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Заметки, папки и вложения в SQLite. Все методы потокобезопасны (SQLiteDatabase сам блокирует). */
final class Store extends SQLiteOpenHelper {
    private static Store instance;

    static synchronized Store get(Context c) {
        if (instance == null) instance = new Store(c.getApplicationContext());
        return instance;
    }

    private final Context app;

    private Store(Context c) {
        super(c, "notes.db", null, 1);
        app = c;
        setWriteAheadLoggingEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE notes (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL DEFAULT '', body TEXT NOT NULL DEFAULT '',"
                + " search TEXT NOT NULL DEFAULT '', tags TEXT NOT NULL DEFAULT '', color INTEGER DEFAULT 0, folder INTEGER DEFAULT 0,"
                + " pinned INTEGER DEFAULT 0, archived INTEGER DEFAULT 0, trashed INTEGER DEFAULT 0, locked INTEGER DEFAULT 0,"
                + " created INTEGER, edited INTEGER, reminder INTEGER DEFAULT 0, repeat INTEGER DEFAULT 0, fired INTEGER DEFAULT 0)");
        db.execSQL("CREATE INDEX notes_list ON notes(trashed, archived, locked, pinned, edited)");
        db.execSQL("CREATE INDEX notes_reminder ON notes(reminder)");
        db.execSQL("CREATE TABLE folders (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, color INTEGER DEFAULT 0, position INTEGER DEFAULT 0)");
        db.execSQL("CREATE TABLE attachments (id INTEGER PRIMARY KEY AUTOINCREMENT, note INTEGER, kind INTEGER, file TEXT,"
                + " duration INTEGER DEFAULT 0, created INTEGER, w INTEGER DEFAULT 0, h INTEGER DEFAULT 0)");
        db.execSQL("CREATE INDEX att_note ON attachments(note)");
        seed(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int o, int n) {
    }

    /** Первая заметка — короткая подсказка по возможностям. */
    private void seed(SQLiteDatabase db) {
        long now = System.currentTimeMillis();
        String body = "Пишите как обычно — разметка появляется сама:\n"
                + "- [ ] Пункт чек-листа: нажмите на квадратик\n"
                + "- [x] Выполненный пункт\n"
                + "- Список с маркерами продолжается по Enter\n"
                + "**Жирный**, _курсив_, ~~зачёркнутый~~, ==выделение== и `код`\n"
                + "> Цитата\n"
                + "Теги через решётку: #идеи #дом\n\n"
                + "Долгое нажатие на карточку — выбор нескольких заметок. В заметку можно добавить фото, рисунок и голос, "
                + "поставить напоминание, убрать в папку или спрятать в сейф под PIN-код.";
        ContentValues v = values(note("Добро пожаловать в Neon Notes", body, now));
        db.insert("notes", null, v);
    }

    private static Note note(String title, String body, long t) {
        Note n = new Note();
        n.title = title;
        n.body = body;
        n.created = n.edited = t;
        n.color = 7;
        return n;
    }

    // ================================================================== вложения

    static final int IMAGE = 0, AUDIO = 1, DRAWING = 2;

    static final class Att {
        long id, note, duration, created;
        int kind, w, h;
        String file;

        boolean sealed() {
            return file != null && file.endsWith(".nv");
        }

        boolean visual() {
            return kind == IMAGE || kind == DRAWING;
        }
    }

    // ================================================================== запросы списка

    static final int NOTES = 0, REMINDERS = 1, VAULT = 2, ARCHIVE = 3, TRASH = 4;

    static final class Query {
        int section = NOTES;
        long folder;
        String tag, text;
        int sort;
    }

    private static final String LIST_COLS = "n.id, n.title, CASE WHEN n.locked=1 THEN n.body ELSE substr(n.body, 1, 2000) END,"
            + " n.tags, n.color, n.folder, n.pinned, n.archived, n.trashed, n.locked, n.created, n.edited, n.reminder, n.repeat, n.fired,"
            + " (SELECT file || '|' || w || '|' || h FROM attachments a WHERE a.note=n.id AND a.kind!=1 ORDER BY a.id LIMIT 1),"
            + " (SELECT COUNT(*) FROM attachments a WHERE a.note=n.id AND a.kind!=1),"
            + " (SELECT COUNT(*) FROM attachments a WHERE a.note=n.id AND a.kind=1),"
            + " (SELECT COALESCE(SUM(duration),0) FROM attachments a WHERE a.note=n.id AND a.kind=1)";

    List<Note> list(Query q) {
        StringBuilder where = new StringBuilder();
        ArrayList<String> args = new ArrayList<>();
        switch (q.section) {
            case REMINDERS: where.append("n.trashed=0 AND n.reminder>0"); break;
            case VAULT: where.append("n.trashed=0 AND n.locked=1"); break;
            case ARCHIVE: where.append("n.trashed=0 AND n.archived=1 AND n.locked=0"); break;
            case TRASH: where.append("n.trashed>0"); break;
            default: where.append("n.trashed=0 AND n.archived=0 AND n.locked=0");
        }
        if (q.folder > 0 && q.section != TRASH) {
            where.append(" AND n.folder=?");
            args.add(String.valueOf(q.folder));
        }
        if (q.tag != null && q.section != VAULT) {
            where.append(" AND n.tags LIKE ? ESCAPE '\\'");
            args.add("%," + Note.like(q.tag) + ",%");
        }
        if (q.text != null && q.section != VAULT) {
            for (String w : Note.words(q.text)) {
                where.append(" AND n.search LIKE ? ESCAPE '\\'");
                args.add("%" + Note.like(w) + "%");
            }
        }
        String order;
        if (q.section == TRASH) order = "n.trashed DESC";
        else if (q.section == REMINDERS) order = "n.fired ASC, n.reminder ASC";
        else {
            String by = q.sort == 1 ? "n.created DESC" : q.sort == 2 ? "(n.title='') ASC, n.search ASC" : "n.edited DESC";
            order = "n.pinned DESC, " + by;
        }
        ArrayList<Note> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT " + LIST_COLS + " FROM notes n WHERE " + where + " ORDER BY " + order,
                args.toArray(new String[0]))) {
            while (c.moveToNext()) {
                Note n = read(c);
                n.thumb = c.getString(15);
                n.images = c.getInt(16);
                n.audios = c.getInt(17);
                n.audioMs = c.getLong(18);
                out.add(n);
            }
        }
        return out;
    }

    private static final String COLS = "id, title, body, tags, color, folder, pinned, archived, trashed, locked, created, edited, reminder, repeat, fired";

    private static Note read(Cursor c) {
        Note n = new Note();
        n.id = c.getLong(0);
        n.title = c.getString(1);
        n.body = c.getString(2);
        n.tags = c.getString(3);
        n.color = c.getInt(4);
        n.folder = c.getLong(5);
        n.pinned = c.getInt(6) != 0;
        n.archived = c.getInt(7) != 0;
        n.trashed = c.getLong(8);
        n.locked = c.getInt(9) != 0;
        n.created = c.getLong(10);
        n.edited = c.getLong(11);
        n.reminder = c.getLong(12);
        n.repeat = c.getInt(13);
        n.fired = c.getInt(14) != 0;
        if (n.title == null) n.title = "";
        if (n.body == null) n.body = "";
        if (n.tags == null) n.tags = "";
        return n;
    }

    Note get(long id) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT " + COLS + " FROM notes WHERE id=?", new String[]{String.valueOf(id)})) {
            if (!c.moveToFirst()) return null;
            Note n = read(c);
            try (Cursor a = getReadableDatabase().rawQuery("SELECT kind, COUNT(*), COALESCE(SUM(duration),0) FROM attachments WHERE note=? GROUP BY kind",
                    new String[]{String.valueOf(id)})) {
                while (a.moveToNext()) {
                    if (a.getInt(0) == AUDIO) {
                        n.audios = a.getInt(1);
                        n.audioMs = a.getLong(2);
                    } else n.images += a.getInt(1);
                }
            }
            return n;
        }
    }

    List<Note> all() {
        ArrayList<Note> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT " + COLS + " FROM notes ORDER BY id", null)) {
            while (c.moveToNext()) out.add(read(c));
        }
        return out;
    }

    private static ContentValues values(Note n) {
        ContentValues v = new ContentValues();
        v.put("title", n.title);
        v.put("body", n.body);
        if (n.locked) {
            v.put("search", "");
            v.put("tags", "");
        } else {
            v.put("search", Note.searchText(n.title, n.body));
            n.tags = Note.tagString(Md.tags(n.title + "\n" + n.body));
            v.put("tags", n.tags);
        }
        v.put("color", n.color);
        v.put("folder", n.folder);
        v.put("pinned", n.pinned ? 1 : 0);
        v.put("archived", n.archived ? 1 : 0);
        v.put("trashed", n.trashed);
        v.put("locked", n.locked ? 1 : 0);
        v.put("created", n.created);
        v.put("edited", n.edited);
        v.put("reminder", n.reminder);
        v.put("repeat", n.repeat);
        v.put("fired", n.fired ? 1 : 0);
        return v;
    }

    long insert(Note n) {
        if (n.created == 0) n.created = System.currentTimeMillis();
        if (n.edited == 0) n.edited = n.created;
        n.id = getWritableDatabase().insert("notes", null, values(n));
        return n.id;
    }

    void update(Note n) {
        getWritableDatabase().update("notes", values(n), "id=?", new String[]{String.valueOf(n.id)});
    }

    /** Быстрые изменения сразу у нескольких заметок. */
    void set(long[] ids, String column, long value) {
        if (ids.length == 0) return;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues v = new ContentValues();
            v.put(column, value);
            for (long id : ids) db.update("notes", v, "id=?", new String[]{String.valueOf(id)});
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    void trash(long[] ids) {
        set(ids, "trashed", System.currentTimeMillis());
        for (long id : ids) Reminders.cancel(app, id);
    }

    void restore(long[] ids) {
        set(ids, "trashed", 0);
        for (long id : ids) Reminders.schedule(app, get(id));
    }

    /** Удалить навсегда вместе с файлами. */
    void deleteForever(long[] ids) {
        SQLiteDatabase db = getWritableDatabase();
        for (long id : ids) {
            Reminders.cancel(app, id);
            for (Att a : attachments(id)) Media.deleteFile(app, a);
            db.delete("attachments", "note=?", new String[]{String.valueOf(id)});
            db.delete("notes", "id=?", new String[]{String.valueOf(id)});
        }
    }

    long[] trashedBefore(long time) {
        ArrayList<Long> ids = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT id FROM notes WHERE trashed>0 AND trashed<?", new String[]{String.valueOf(time)})) {
            while (c.moveToNext()) ids.add(c.getLong(0));
        }
        long[] out = new long[ids.size()];
        for (int i = 0; i < out.length; i++) out[i] = ids.get(i);
        return out;
    }

    long[] ids(String where) {
        ArrayList<Long> ids = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT id FROM notes WHERE " + where, null)) {
            while (c.moveToNext()) ids.add(c.getLong(0));
        }
        long[] out = new long[ids.size()];
        for (int i = 0; i < out.length; i++) out[i] = ids.get(i);
        return out;
    }

    /** Копия заметки вместе с файлами вложений. */
    long duplicate(long id) {
        Note n = get(id);
        if (n == null) return 0;
        n.id = 0;
        n.created = n.edited = System.currentTimeMillis();
        n.reminder = 0;
        n.fired = false;
        n.pinned = false;
        if (!n.locked && !n.title.isEmpty()) n.title = n.title + " (копия)";
        long nid = insert(n);
        for (Att a : attachments(id)) {
            String name = Media.copyFile(app, a);
            if (name == null) continue;
            a.id = 0;
            a.note = nid;
            a.file = name;
            addAttachment(a);
        }
        return nid;
    }

    /** Заметки с напоминаниями — для будильников. */
    List<Note> withReminders() {
        ArrayList<Note> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT " + COLS + " FROM notes WHERE reminder>0 AND trashed=0", null)) {
            while (c.moveToNext()) out.add(read(c));
        }
        return out;
    }

    /** Найти заметку с тем же временем создания и правки — чтобы не задвоить при восстановлении копии. */
    boolean exists(long created, long edited) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT 1 FROM notes WHERE created=? AND edited=? LIMIT 1",
                new String[]{String.valueOf(created), String.valueOf(edited)})) {
            return c.moveToFirst();
        }
    }

    // ================================================================== счётчики для меню

    static final class Counts {
        int notes, reminders, vault, archive, trash;
        final Map<Long, Integer> folders = new HashMap<>();
        final LinkedHashMap<String, Integer> tags = new LinkedHashMap<>();
    }

    Counts counts() {
        Counts k = new Counts();
        HashMap<String, Integer> tags = new HashMap<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT folder, tags, archived, locked, trashed, reminder FROM notes", null)) {
            while (c.moveToNext()) {
                long folder = c.getLong(0);
                boolean archived = c.getInt(2) != 0, locked = c.getInt(3) != 0, trashed = c.getLong(4) > 0;
                if (trashed) { k.trash++; continue; }
                if (c.getLong(5) > 0) k.reminders++;
                if (locked) { k.vault++; continue; }
                if (archived) { k.archive++; continue; }
                k.notes++;
                if (folder > 0) k.folders.merge(folder, 1, Integer::sum);
                for (String t : Note.tagList(c.getString(1))) tags.merge(t, 1, Integer::sum);
            }
        }
        ArrayList<Map.Entry<String, Integer>> list = new ArrayList<>(tags.entrySet());
        list.sort((a, b) -> b.getValue().equals(a.getValue()) ? a.getKey().compareTo(b.getKey()) : b.getValue() - a.getValue());
        for (Map.Entry<String, Integer> e : list) k.tags.put(e.getKey(), e.getValue());
        return k;
    }

    // ================================================================== папки

    static final class Folder {
        long id;
        String name;
        int color, position;
    }

    List<Folder> folders() {
        ArrayList<Folder> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT id, name, color, position FROM folders ORDER BY position, id", null)) {
            while (c.moveToNext()) {
                Folder f = new Folder();
                f.id = c.getLong(0);
                f.name = c.getString(1);
                f.color = c.getInt(2);
                f.position = c.getInt(3);
                out.add(f);
            }
        }
        return out;
    }

    Folder folder(long id) {
        for (Folder f : folders()) if (f.id == id) return f;
        return null;
    }

    long addFolder(String name, int color) {
        ContentValues v = new ContentValues();
        v.put("name", name);
        v.put("color", color);
        v.put("position", folders().size());
        return getWritableDatabase().insert("folders", null, v);
    }

    long folderByName(String name, int color) {
        for (Folder f : folders()) if (f.name.equalsIgnoreCase(name)) return f.id;
        return addFolder(name, color);
    }

    void updateFolder(Folder f) {
        ContentValues v = new ContentValues();
        v.put("name", f.name);
        v.put("color", f.color);
        v.put("position", f.position);
        getWritableDatabase().update("folders", v, "id=?", new String[]{String.valueOf(f.id)});
    }

    void deleteFolder(long id) {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("UPDATE notes SET folder=0 WHERE folder=?", new Object[]{id});
        db.delete("folders", "id=?", new String[]{String.valueOf(id)});
    }

    void moveFolder(long id, int dir) {
        List<Folder> fs = folders();
        for (int i = 0; i < fs.size(); i++) {
            if (fs.get(i).id != id) continue;
            int j = i + dir;
            if (j < 0 || j >= fs.size()) return;
            Folder a = fs.get(i);
            fs.set(i, fs.get(j));
            fs.set(j, a);
            break;
        }
        for (int i = 0; i < fs.size(); i++) {
            fs.get(i).position = i;
            updateFolder(fs.get(i));
        }
    }

    /** Переименовать тег во всех заметках (или удалить его, если name пустой). */
    int renameTag(String from, String to) {
        int changed = 0;
        Query q = new Query();
        q.tag = from;
        ArrayList<Note> hit = new ArrayList<>();
        for (int section : new int[]{NOTES, ARCHIVE}) {
            q.section = section;
            for (Note n : list(q)) hit.add(get(n.id));
        }
        java.util.regex.Pattern p = java.util.regex.Pattern.compile("(?<=^|[\\s(,;])#" + java.util.regex.Pattern.quote(from)
                + "(?![\\p{L}\\p{N}_-])", java.util.regex.Pattern.CASE_INSENSITIVE | java.util.regex.Pattern.UNICODE_CASE);
        for (Note n : hit) {
            if (n == null) continue;
            String rep = to == null || to.isEmpty() ? "" : "#" + java.util.regex.Matcher.quoteReplacement(to);
            String nb = p.matcher(n.body).replaceAll(rep), nt = p.matcher(n.title).replaceAll(rep);
            if (rep.isEmpty()) {
                nb = nb.replaceAll("[ \\t]{2,}", " ").replaceAll("(?m)[ \\t]+$", "");
                nt = nt.trim();
            }
            if (!nb.equals(n.body) || !nt.equals(n.title)) {
                n.body = nb;
                n.title = nt;
                update(n);
                changed++;
            }
        }
        return changed;
    }

    // ================================================================== вложения

    List<Att> attachments(long note) {
        ArrayList<Att> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT id, note, kind, file, duration, created, w, h FROM attachments WHERE note=? ORDER BY id",
                new String[]{String.valueOf(note)})) {
            while (c.moveToNext()) out.add(readAtt(c));
        }
        return out;
    }

    List<Att> allAttachments() {
        ArrayList<Att> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT id, note, kind, file, duration, created, w, h FROM attachments ORDER BY id", null)) {
            while (c.moveToNext()) out.add(readAtt(c));
        }
        return out;
    }

    private static Att readAtt(Cursor c) {
        Att a = new Att();
        a.id = c.getLong(0);
        a.note = c.getLong(1);
        a.kind = c.getInt(2);
        a.file = c.getString(3);
        a.duration = c.getLong(4);
        a.created = c.getLong(5);
        a.w = c.getInt(6);
        a.h = c.getInt(7);
        return a;
    }

    Att attachment(long id) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT id, note, kind, file, duration, created, w, h FROM attachments WHERE id=?",
                new String[]{String.valueOf(id)})) {
            return c.moveToFirst() ? readAtt(c) : null;
        }
    }

    long addAttachment(Att a) {
        ContentValues v = new ContentValues();
        v.put("note", a.note);
        v.put("kind", a.kind);
        v.put("file", a.file);
        v.put("duration", a.duration);
        v.put("created", a.created == 0 ? System.currentTimeMillis() : a.created);
        v.put("w", a.w);
        v.put("h", a.h);
        a.id = getWritableDatabase().insert("attachments", null, v);
        return a.id;
    }

    void updateAttachment(Att a) {
        ContentValues v = new ContentValues();
        v.put("file", a.file);
        v.put("duration", a.duration);
        v.put("w", a.w);
        v.put("h", a.h);
        getWritableDatabase().update("attachments", v, "id=?", new String[]{String.valueOf(a.id)});
    }

    void deleteAttachment(Att a) {
        Media.deleteFile(app, a);
        getWritableDatabase().delete("attachments", "id=?", new String[]{String.valueOf(a.id)});
    }

    /** Файлы в папке вложений, на которые никто не ссылается (например, после сбоя) — удалить. */
    void cleanOrphans() {
        java.util.HashSet<String> used = new java.util.HashSet<>();
        for (Att a : allAttachments()) used.add(a.file);
        File[] files = Media.dir(app).listFiles();
        if (files == null) return;
        long old = System.currentTimeMillis() - 24 * 3600_000L;
        for (File f : files) if (!used.contains(f.getName()) && f.lastModified() < old) f.delete();
    }
}
