package com.neondrift.notes;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.text.InputType;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.util.function.Consumer;

/** Общее для всех экранов: тема, счётчик видимых экранов (для автоблокировки сейфа), диалоги. */
abstract class Base extends Activity {
    private static int started;

    Ui ui;
    Prefs prefs;
    private int accentAtCreate;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        Theme.load(this);
        ui = new Ui(this);
        prefs = new Prefs(this);
        accentAtCreate = prefs.accent();
        getWindow().setStatusBarColor(Theme.BG);
        getWindow().setNavigationBarColor(Theme.BG);
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (started++ == 0) Lock.onForeground(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (prefs.accent() != accentAtCreate) {
            Theme.load(this);
            recreate();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (--started <= 0) {
            started = 0;
            Lock.onBackground(this);
        }
    }

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    AlertDialog.Builder dialog() {
        return new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert);
    }

    void confirm(String title, String message, String yes, Runnable r) {
        dialog().setTitle(title).setMessage(message).setPositiveButton(yes, (d, w) -> r.run())
                .setNegativeButton("Отмена", null).show();
    }

    /** Диалог с одним полем ввода. */
    void prompt(String title, String value, String hint, Consumer<String> done) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        e.setTextColor(Theme.TEXT);
        e.setHintTextColor(Theme.MUTED);
        e.setSelection(e.getText().length());
        FrameLayout box = new FrameLayout(this);
        box.setPadding(ui.dp(22), ui.dp(8), ui.dp(22), 0);
        box.addView(e);
        AlertDialog d = dialog().setTitle(title).setView(box)
                .setPositiveButton("Готово", (x, w) -> {
                    String s = e.getText().toString().trim();
                    if (!s.isEmpty()) done.accept(s);
                })
                .setNegativeButton("Отмена", null).create();
        d.setOnShowListener(x -> {
            e.requestFocus();
            ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).showSoftInput(e, InputMethodManager.SHOW_IMPLICIT);
        });
        d.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        d.show();
    }

    void hideKeyboard() {
        if (getCurrentFocus() != null) {
            ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                    .hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
    }
}
