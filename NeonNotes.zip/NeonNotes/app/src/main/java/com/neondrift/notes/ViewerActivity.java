package com.neondrift.notes;

import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Просмотр картинок и рисунков заметки: масштаб двумя пальцами, двойное нажатие, листание. */
public class ViewerActivity extends Base {
    private List<Store.Att> items = new ArrayList<>();
    private int index;
    private ZoomView image;
    private TextView counter;
    private LinearLayout bar;
    private long noteId;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(0xFF000000);
        getWindow().setNavigationBarColor(0xFF000000);
        noteId = getIntent().getLongExtra("note", 0);
        long att = getIntent().getLongExtra("att", 0);
        Note n = Store.get(this).get(noteId);
        if (n != null && n.locked) getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
        for (Store.Att a : Store.get(this).attachments(noteId)) if (a.visual()) items.add(a);
        for (int i = 0; i < items.size(); i++) if (items.get(i).id == att) index = i;
        if (items.isEmpty()) {
            finish();
            return;
        }
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        image = new ZoomView(this);
        root.addView(image, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        bar = ui.row();
        bar.setPadding(ui.dp(4), ui.dp(8), ui.dp(4), ui.dp(8));
        bar.setBackground(new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xCC000000, 0x00000000}));
        bar.addView(ui.iconButton("back", Theme.TEXT, 46, 12, v -> finish()));
        counter = ui.text("", 16, Theme.TEXT, true);
        bar.addView(counter, Ui.lp(0, Ui.WRAP, 1f));
        bar.addView(ui.iconButton("share", Theme.TEXT, 44, 11, v -> share()));
        if (n != null && n.trashed == 0) bar.addView(ui.iconButton("trash", Theme.TEXT, 44, 11, v -> delete()));
        root.addView(bar, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP, Gravity.TOP));
        setContentView(root);
        showCurrent();
    }

    private void showCurrent() {
        Store.Att a = items.get(index);
        counter.setText(items.size() > 1 ? (index + 1) + " из " + items.size() : a.kind == Store.DRAWING ? "Рисунок" : "Картинка");
        image.setImageBitmap(null);
        Context app = getApplicationContext();
        int max = Math.min(4096, Math.max(getResources().getDisplayMetrics().widthPixels, getResources().getDisplayMetrics().heightPixels) * 2);
        Media.IO.execute(() -> {
            File f = Media.plain(app, a);
            Bitmap b = f == null ? null : Media.decode(f, max, max);
            Media.MAIN.post(() -> {
                if (isFinishing()) return;
                if (b == null) toast("Не удалось открыть");
                image.setImageBitmap(b);
            });
        });
    }

    private void go(int dir) {
        int ni = index + dir;
        if (ni < 0 || ni >= items.size()) return;
        index = ni;
        image.setTranslationX(dir * ui.dp(40));
        image.setAlpha(0.3f);
        image.animate().translationX(0).alpha(1f).setDuration(180).start();
        showCurrent();
    }

    private void share() {
        Store.Att a = items.get(index);
        Uri u = Files.uri(this, a);
        if (u == null) return;
        Intent s = new Intent(Intent.ACTION_SEND).setType(Files.type(a.file.replace(".nv", ""))).putExtra(Intent.EXTRA_STREAM, u)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        s.setClipData(ClipData.newRawUri("", u));
        startActivity(Intent.createChooser(s, "Поделиться"));
    }

    private void delete() {
        confirm("Удалить из заметки?", null, "Удалить", () -> {
            Store.Att a = items.remove(index);
            Store.get(this).deleteAttachment(a);
            Store.get(this).set(new long[]{noteId}, "edited", System.currentTimeMillis());
            if (items.isEmpty()) {
                finish();
                return;
            }
            index = Math.min(index, items.size() - 1);
            showCurrent();
        });
    }

    private void toggleBar() {
        bar.animate().alpha(bar.getAlpha() > 0.5f ? 0f : 1f).setDuration(150).start();
    }

    /** Картинка с масштабом и сдвигом. */
    final class ZoomView extends ImageView {
        private final Matrix m = new Matrix();
        private final float[] v = new float[9];
        private float minScale = 1f;
        private final ScaleGestureDetector scaler;
        private final GestureDetector gestures;

        ZoomView(Context c) {
            super(c);
            setScaleType(ScaleType.MATRIX);
            scaler = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override
                public boolean onScale(ScaleGestureDetector d) {
                    float cur = scale(), f = d.getScaleFactor();
                    float target = Math.max(minScale * 0.9f, Math.min(minScale * 8f, cur * f));
                    m.postScale(target / cur, target / cur, d.getFocusX(), d.getFocusY());
                    clamp();
                    return true;
                }

                @Override
                public void onScaleEnd(ScaleGestureDetector d) {
                    if (scale() < minScale) fit();
                }
            });
            gestures = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onDoubleTap(MotionEvent e) {
                    if (scale() > minScale * 1.1f) fit();
                    else {
                        m.postScale(2.5f, 2.5f, e.getX(), e.getY());
                        clamp();
                    }
                    return true;
                }

                @Override
                public boolean onSingleTapConfirmed(MotionEvent e) {
                    toggleBar();
                    return true;
                }

                @Override
                public boolean onScroll(MotionEvent a, MotionEvent b, float dx, float dy) {
                    if (scale() <= minScale * 1.02f) return false;
                    m.postTranslate(-dx, -dy);
                    clamp();
                    return true;
                }

                @Override
                public boolean onFling(MotionEvent a, MotionEvent b, float vx, float vy) {
                    if (scale() > minScale * 1.02f || a == null) return false;
                    float dx = b.getX() - a.getX();
                    if (Math.abs(dx) > Math.abs(b.getY() - a.getY()) && Math.abs(vx) > 600) {
                        go(dx < 0 ? 1 : -1);
                        return true;
                    }
                    if (b.getY() - a.getY() > ui.dp(120) && Math.abs(vy) > 800) {
                        finish();
                        return true;
                    }
                    return false;
                }
            });
        }

        private float scale() {
            m.getValues(v);
            return v[Matrix.MSCALE_X];
        }

        @Override
        public void setImageBitmap(Bitmap bm) {
            super.setImageBitmap(bm);
            post(this::fit);
        }

        void fit() {
            if (getDrawable() == null || getWidth() == 0) return;
            float dw = getDrawable().getIntrinsicWidth(), dh = getDrawable().getIntrinsicHeight();
            minScale = Math.min(getWidth() / dw, getHeight() / dh);
            m.reset();
            m.postScale(minScale, minScale);
            m.postTranslate((getWidth() - dw * minScale) / 2f, (getHeight() - dh * minScale) / 2f);
            setImageMatrix(m);
        }

        /** Не даём картинке уехать за край. */
        private void clamp() {
            if (getDrawable() == null) return;
            RectF r = new RectF(0, 0, getDrawable().getIntrinsicWidth(), getDrawable().getIntrinsicHeight());
            m.mapRect(r);
            float dx = 0, dy = 0;
            if (r.width() <= getWidth()) dx = (getWidth() - r.width()) / 2f - r.left;
            else if (r.left > 0) dx = -r.left;
            else if (r.right < getWidth()) dx = getWidth() - r.right;
            if (r.height() <= getHeight()) dy = (getHeight() - r.height()) / 2f - r.top;
            else if (r.top > 0) dy = -r.top;
            else if (r.bottom < getHeight()) dy = getHeight() - r.bottom;
            m.postTranslate(dx, dy);
            setImageMatrix(m);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            fit();
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            scaler.onTouchEvent(e);
            if (!scaler.isInProgress()) gestures.onTouchEvent(e);
            return true;
        }
    }
}
