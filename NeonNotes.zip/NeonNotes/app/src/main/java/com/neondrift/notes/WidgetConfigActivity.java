package com.neondrift.notes;

import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

/** Выбор заметки для виджета. */
public class WidgetConfigActivity extends Base {
    private int widgetId;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        widgetId = getIntent().getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        setResult(RESULT_CANCELED, new Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId));
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish();
            return;
        }
        LinearLayout page = ui.col();
        page.setBackgroundColor(Theme.BG);
        LinearLayout top = ui.row();
        top.setPadding(ui.dp(6), ui.dp(10), ui.dp(16), ui.dp(6));
        top.addView(ui.iconButton("close", Theme.TEXT, 44, 11, v -> finish()));
        top.addView(ui.text("Заметка для виджета", 19, Theme.TEXT, true), Ui.margins(Ui.WRAP, Ui.WRAP, ui.dp(8), 0, 0, 0));
        page.addView(top);
        ScrollView sc = new ScrollView(this);
        LinearLayout box = ui.col();
        box.setPadding(ui.dp(16), ui.dp(4), ui.dp(16), ui.dp(30));
        sc.addView(box, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        page.addView(sc, Ui.lp(Ui.MATCH, 0, 1f));
        setContentView(page);

        box.addView(ui.button("+ Новый чек-лист на экран", true, v -> {
            Note n = new Note();
            n.title = "Список";
            n.body = "- [ ] ";
            n.color = 4;
            Store.get(this).insert(n);
            pick(n.id);
            startActivity(new Intent(this, NoteActivity.class).putExtra("id", n.id).putExtra("outside", true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        }), Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(6), 0, ui.dp(12)));
        Store.Query q = new Store.Query();
        List<Note> notes = Store.get(this).list(q);
        if (notes.isEmpty()) box.addView(ui.text("Заметок пока нет", 14, Theme.MUTED, false));
        for (Note n : notes) {
            LinearLayout row = ui.col();
            row.setPadding(ui.dp(16), ui.dp(12), ui.dp(16), ui.dp(12));
            row.setBackground(Ui.ripple(Ui.stroke(Note.fill(n.color), n.color == 0 ? Theme.LINE : Note.neon(n.color), ui.dp(1), ui.dp(16)),
                    Ui.round(0xFFFFFFFF, ui.dp(16))));
            String plain = Md.plain(n.body).trim();
            TextView t = ui.oneLine(n.title.isEmpty() ? (plain.isEmpty() ? "Без названия" : plain.split("\n")[0]) : n.title, 15.5f, Theme.TEXT, true);
            row.addView(t);
            if (!plain.isEmpty() && !n.title.isEmpty()) {
                TextView p = ui.text(plain, 13, Theme.MUTED, false);
                p.setMaxLines(2);
                p.setEllipsize(TextUtils.TruncateAt.END);
                row.addView(p, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(4), 0, 0));
            }
            row.setOnClickListener(v -> pick(n.id));
            box.addView(row, Ui.margins(Ui.MATCH, Ui.WRAP, 0, 0, 0, ui.dp(8)));
        }
    }

    private void pick(long noteId) {
        new Prefs(this).put("w_" + widgetId, noteId);
        NoteWidget.update(this, AppWidgetManager.getInstance(this), widgetId);
        setResult(RESULT_OK, new Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId));
        finish();
    }
}
