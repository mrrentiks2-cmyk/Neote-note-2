package com.neondrift.notes;

import android.app.Activity;
import android.content.Context;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Build;
import android.os.CancellationSignal;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyPermanentlyInvalidatedException;
import android.security.keystore.KeyProperties;

import java.security.KeyStore;
import java.util.Base64;
import java.util.function.Consumer;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Открытие сейфа отпечатком (Android 11+). Ключ сейфа хранится зашифрованным ключом из аппаратного
 * хранилища, который выдаётся только после подтверждения отпечатком. Новый отпечаток в системе
 * делает его недействительным — тогда снова нужен PIN.
 */
final class Bio {
    private Bio() {}

    private static final String ALIAS = "neon_notes_vault_bio";

    static boolean supported(Context c) {
        if (Build.VERSION.SDK_INT < 30) return false;
        try {
            BiometricManager bm = c.getSystemService(BiometricManager.class);
            return bm != null && bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS;
        } catch (Exception e) {
            return false;
        }
    }

    static boolean enabled(Context c) {
        return new Prefs(c).bioKey() != null && supported(c);
    }

    /** Включить: подтвердить отпечатком и сохранить зашифрованный ключ сейфа. */
    static void enable(Activity a, byte[] vaultKey, Runnable ok, Consumer<String> fail) {
        if (Build.VERSION.SDK_INT < 30) { fail.accept("Нужен Android 11 или новее"); return; }
        try {
            KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            kg.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .setUserAuthenticationRequired(true)
                    .setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG)
                    .setInvalidatedByBiometricEnrollment(true)
                    .build());
            SecretKey key = kg.generateKey();
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] copy = vaultKey.clone();
            prompt(a, "Отпечаток для сейфа", "Подтвердите, чтобы открывать сейф без PIN", cipher, c -> {
                try {
                    byte[] ct = c.doFinal(copy);
                    byte[] iv = c.getIV();
                    byte[] all = new byte[1 + iv.length + ct.length];
                    all[0] = (byte) iv.length;
                    System.arraycopy(iv, 0, all, 1, iv.length);
                    System.arraycopy(ct, 0, all, 1 + iv.length, ct.length);
                    new Prefs(a).put("bioKey", Base64.getEncoder().encodeToString(all));
                    ok.run();
                } catch (Exception e) {
                    fail.accept("Не удалось сохранить ключ");
                }
            }, fail);
        } catch (Exception e) {
            fail.accept("Отпечаток на этом устройстве недоступен");
        }
    }

    /** Открыть сейф отпечатком. При ошибке — fallback (ввод PIN). */
    static void unlock(Activity a, Runnable ok, Runnable fallback) {
        if (Build.VERSION.SDK_INT < 30) { fallback.run(); return; }
        String stored = new Prefs(a).bioKey();
        if (stored == null) { fallback.run(); return; }
        try {
            byte[] all = Base64.getDecoder().decode(stored);
            int ivLen = all[0];
            KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
            ks.load(null);
            SecretKey key = (SecretKey) ks.getKey(ALIAS, null);
            if (key == null) { disable(a); fallback.run(); return; }
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, all, 1, ivLen));
            prompt(a, "Сейф", "Приложите палец, чтобы открыть заметки", cipher, c -> {
                try {
                    byte[] vk = c.doFinal(all, 1 + ivLen, all.length - 1 - ivLen);
                    if (Lock.setKey(a, vk)) ok.run();
                    else { disable(a); fallback.run(); }
                } catch (Exception e) {
                    fallback.run();
                }
            }, msg -> fallback.run());
        } catch (KeyPermanentlyInvalidatedException e) {
            disable(a);
            fallback.run();
        } catch (Exception e) {
            fallback.run();
        }
    }

    static void disable(Context c) {
        new Prefs(c).remove("bioKey");
        try {
            KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
            ks.load(null);
            ks.deleteEntry(ALIAS);
        } catch (Exception ignored) {
        }
    }

    private interface WithCipher { void run(Cipher c); }

    private static void prompt(Activity a, String title, String sub, Cipher cipher, WithCipher ok, Consumer<String> fail) {
        BiometricPrompt p = new BiometricPrompt.Builder(a)
                .setTitle(title)
                .setSubtitle(sub)
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                .setNegativeButton("Ввести PIN", a.getMainExecutor(), (d, w) -> fail.accept(""))
                .build();
        p.authenticate(new BiometricPrompt.CryptoObject(cipher), new CancellationSignal(), a.getMainExecutor(),
                new BiometricPrompt.AuthenticationCallback() {
                    @Override
                    public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r) {
                        Cipher c = r.getCryptoObject() != null ? r.getCryptoObject().getCipher() : null;
                        if (c != null) ok.run(c);
                        else fail.accept("Ошибка отпечатка");
                    }

                    @Override
                    public void onAuthenticationError(int code, CharSequence msg) {
                        // кнопка «Ввести PIN» сюда не приходит — её обрабатывает setNegativeButton
                        fail.accept(code == BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED
                                || code == BiometricPrompt.BIOMETRIC_ERROR_CANCELED ? "" : String.valueOf(msg));
                    }
                });
    }
}
