package com.neondrift.notes;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

/** Виджет быстрых действий: новая заметка, список, голос, рисунок, фото. */
public class QuickWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) {
            RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_quick);
            rv.setOnClickPendingIntent(R.id.q_note, pi(c, NoteActivity.ACTION_NEW, "text", 1));
            rv.setOnClickPendingIntent(R.id.q_list, pi(c, NoteActivity.ACTION_LIST, "list", 2));
            rv.setOnClickPendingIntent(R.id.q_voice, pi(c, NoteActivity.ACTION_VOICE, "voice", 3));
            rv.setOnClickPendingIntent(R.id.q_draw, pi(c, NoteActivity.ACTION_DRAW, "draw", 4));
            rv.setOnClickPendingIntent(R.id.q_photo, pi(c, NoteActivity.ACTION_NEW, "photo", 5));
            Intent app = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            rv.setOnClickPendingIntent(R.id.q_app, PendingIntent.getActivity(c, 6, app, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
            m.updateAppWidget(id, rv);
        }
    }

    private static PendingIntent pi(Context c, String action, String kind, int code) {
        Intent i = new Intent(c, NoteActivity.class).setAction(action).putExtra("kind", kind).putExtra("outside", true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        return PendingIntent.getActivity(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
