package com.neondrift.notes;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.BackgroundColorSpan;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

/** Главный экран: сетка или список заметок, разделы, папки, теги, поиск и выбор нескольких заметок. */
public class MainActivity extends Base {
    private static final String[] SECTION_NAMES = {"Заметки", "Напоминания", "Сейф", "Архив", "Корзина"};
    private static final String[] SECTION_ICONS = {"note", "bell", "lock", "archive", "trash"};
    private static final int PAGE = 30;
    private static boolean startupDone;

    private Store store;
    private final Store.Query query = new Store.Query();

    private FrameLayout root;
    private LinearLayout topBar, selectBar, chipsRow, content, bottomBar;
    private HorizontalScrollView chipsScroll;
    private EditText search;
    private ImageView clearSearch, viewToggle;
    private TextView sectionTitle, sectionCount, selectCount;
    private LinearLayout sectionActions;
    private ScrollView scroll;
    private View fab;
    private SidePanel panel;
    private PinPad pin;
    private FrameLayout drawer;
    private LinearLayout drawerBox;
    private LinearLayout snack;
    private TextView snackText, snackAction;
    private Runnable snackUndo;

    private List<Note> notes = new ArrayList<>();
    private final LinkedHashSet<Long> selected = new LinkedHashSet<>();
    private final Map<Long, View> cardViews = new HashMap<>();
    private Map<Long, String> folderNames = new HashMap<>();
    private Map<Long, Integer> folderColors = new HashMap<>();
    private int rendered;
    private Block pinnedBlock, otherBlock;
    private int loadToken;
    private final Runnable searchRun = this::reload;

    /** Колонки «каменной кладки»: каждая следующая карточка идёт в самую короткую колонку. */
    private final class Block {
        final LinearLayout box;
        final LinearLayout[] cols;
        final int[] heights;
        final int colWidth;

        Block(String label, int n, int width) {
            box = ui.col();
            if (label != null) {
                TextView l = ui.label(label);
                box.addView(l, Ui.margins(Ui.WRAP, Ui.WRAP, ui.dp(8), ui.dp(14), 0, ui.dp(8)));
            }
            LinearLayout row = ui.row();
            row.setGravity(Gravity.TOP);
            cols = new LinearLayout[n];
            heights = new int[n];
            int gap = ui.dp(10);
            colWidth = (width - gap * (n - 1)) / n;
            for (int i = 0; i < n; i++) {
                cols[i] = ui.col();
                LinearLayout.LayoutParams lp = Ui.lp(colWidth, Ui.WRAP);
                if (i > 0) lp.leftMargin = gap;
                row.addView(cols[i], lp);
            }
            box.addView(row);
            content.addView(box);
        }

        void add(View card) {
            int best = 0;
            for (int i = 1; i < cols.length; i++) if (heights[i] < heights[best]) best = i;
            card.measure(View.MeasureSpec.makeMeasureSpec(colWidth, View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
            heights[best] += card.getMeasuredHeight() + ui.dp(10);
            cols[best].addView(card, Ui.margins(Ui.MATCH, Ui.WRAP, 0, 0, 0, ui.dp(10)));
        }
    }

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        store = Store.get(this);
        query.sort = prefs.sort();
        buildUi();
        handleIntent(getIntent());
        if (!startupDone) {
            startupDone = true;
            Media.IO.execute(() -> {
                Lock.clearOpened(this);
                if (prefs.autoPurge() && System.currentTimeMillis() - prefs.lastPurge() > 6 * 3600_000L) {
                    store.deleteForever(store.trashedBefore(System.currentTimeMillis() - 30L * 86400_000));
                    store.cleanOrphans();
                    prefs.put("lastPurge", System.currentTimeMillis());
                }
                Reminders.syncAll(this);
            });
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent i) {
        if (i == null) return;
        String tag = i.getStringExtra("tag");
        if (tag != null) {
            query.section = Store.NOTES;
            query.tag = tag;
            query.folder = 0;
        }
        int section = i.getIntExtra("section", -1);
        if (section >= 0) openSection(section);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (query.section == Store.VAULT && !Lock.isOpen()) {
            query.section = Store.NOTES;
        }
        reload();
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration c) {
        super.onConfigurationChanged(c);
        // колонки и ширина меню зависят от ширины экрана
        root.postDelayed(() -> render(false), 120);
        View sheet = drawer.getChildAt(0);
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) sheet.getLayoutParams();
        lp.width = Math.min(ui.dp(320), Math.round(getResources().getDisplayMetrics().widthPixels * 0.84f));
        sheet.setLayoutParams(lp);
    }

    // ================================================================== интерфейс

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Theme.BG);
        LinearLayout page = ui.col();

        // верхняя панель: меню, поиск, вид
        FrameLayout bars = new FrameLayout(this);
        topBar = ui.row();
        topBar.setPadding(ui.dp(8), ui.dp(10), ui.dp(8), ui.dp(6));
        LinearLayout field = ui.row();
        field.setBackground(Ui.round(Theme.SURFACE, ui.dp(26)));
        field.setPadding(ui.dp(4), 0, ui.dp(4), 0);
        field.addView(ui.iconButton("menu", Theme.TEXT, 46, 12, v -> openDrawer()));
        search = new EditText(this);
        search.setHint("Поиск в заметках");
        search.setHintTextColor(Theme.MUTED);
        search.setTextColor(Theme.TEXT);
        search.setTextSize(16);
        search.setSingleLine(true);
        search.setBackground(null);
        search.setPadding(ui.dp(4), ui.dp(12), ui.dp(4), ui.dp(12));
        search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable e) {
                String t = e.toString().trim();
                query.text = t.isEmpty() ? null : t;
                clearSearch.setVisibility(t.isEmpty() ? View.GONE : View.VISIBLE);
                root.removeCallbacks(searchRun);
                root.postDelayed(searchRun, 180);
            }
        });
        search.setOnEditorActionListener((v, id, ev) -> {
            hideKeyboard();
            return true;
        });
        field.addView(search, Ui.lp(0, Ui.WRAP, 1f));
        clearSearch = ui.iconButton("close", Theme.MUTED, 40, 11, v -> {
            search.setText("");
            hideKeyboard();
            search.clearFocus();
        });
        clearSearch.setVisibility(View.GONE);
        field.addView(clearSearch);
        viewToggle = ui.iconButton(prefs.view() == 0 ? "list" : "grid", Theme.TEXT, 44, 11, v -> {
            prefs.put("view", prefs.view() == 0 ? 1 : 0);
            viewToggle.setImageDrawable(new Glyph(prefs.view() == 0 ? "list" : "grid", Theme.TEXT));
            render(true);
        });
        field.addView(viewToggle);
        topBar.addView(field, Ui.lp(0, Ui.WRAP, 1f));
        bars.addView(topBar);

        // панель выбора нескольких заметок
        selectBar = ui.row();
        selectBar.setPadding(ui.dp(8), ui.dp(10), ui.dp(4), ui.dp(6));
        selectBar.setVisibility(View.GONE);
        selectBar.addView(ui.iconButton("close", Theme.TEXT, 46, 12, v -> clearSelection()));
        selectCount = ui.text("", 18, Theme.TEXT, true);
        selectBar.addView(selectCount, Ui.lp(0, Ui.WRAP, 1f));
        bars.addView(selectBar, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        page.addView(bars);

        // заголовок раздела
        LinearLayout head = ui.row();
        head.setPadding(ui.dp(20), ui.dp(4), ui.dp(10), 0);
        sectionTitle = ui.text("Заметки", 24, Theme.TEXT, true);
        head.addView(sectionTitle);
        sectionCount = ui.text("", 14, Theme.MUTED, false);
        head.addView(sectionCount, Ui.margins(0, Ui.WRAP, ui.dp(10), ui.dp(5), 0, 0));
        ((LinearLayout.LayoutParams) sectionCount.getLayoutParams()).weight = 1f;
        sectionActions = ui.row();
        head.addView(sectionActions);
        page.addView(head, Ui.lp(Ui.MATCH, ui.dp(48)));

        // папки и фильтр по тегу
        chipsScroll = new HorizontalScrollView(this);
        chipsScroll.setHorizontalScrollBarEnabled(false);
        chipsRow = ui.row();
        chipsRow.setPadding(ui.dp(16), ui.dp(4), ui.dp(16), ui.dp(6));
        chipsScroll.addView(chipsRow);
        page.addView(chipsScroll);

        scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setClipToPadding(false);
        content = ui.col();
        content.setPadding(ui.dp(12), ui.dp(2), ui.dp(12), ui.dp(120));
        scroll.addView(content, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        scroll.setOnScrollChangeListener((v, x, y, ox, oy) -> {
            if (rendered < notes.size() && y + scroll.getHeight() > content.getHeight() - ui.dp(900)) renderMore();
        });
        page.addView(scroll, Ui.lp(Ui.MATCH, 0, 1f));
        root.addView(page, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));

        // нижняя панель быстрых действий и кнопка «+»
        bottomBar = ui.row();
        bottomBar.setPadding(ui.dp(10), ui.dp(6), ui.dp(10), ui.dp(6));
        bottomBar.setBackground(Ui.stroke(Theme.alpha(Theme.SURFACE2, 245), Theme.LINE, ui.dp(1), ui.dp(30)));
        bottomBar.setElevation(ui.dp(6));
        bottomBar.addView(quick("checkbox", "Список", v -> newNote("list")));
        bottomBar.addView(quick("brush", "Рисунок", v -> newNote("draw")));
        bottomBar.addView(quick("mic", "Голос", v -> newNote("voice")));
        bottomBar.addView(quick("image", "Фото", v -> newNote("photo")));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM | Gravity.START);
        bp.setMargins(ui.dp(16), 0, 0, ui.dp(18));
        root.addView(bottomBar, bp);

        LinearLayout fabView = ui.row();
        fabView.setGravity(Gravity.CENTER);
        fabView.setPadding(ui.dp(18), 0, ui.dp(22), 0);
        ImageView plus = new ImageView(this);
        plus.setImageDrawable(new Glyph("plus", Theme.BG));
        fabView.addView(plus, Ui.lp(ui.dp(26), ui.dp(26)));
        TextView fl = ui.text("Заметка", 15, Theme.BG, true);
        fabView.addView(fl, Ui.margins(Ui.WRAP, Ui.WRAP, ui.dp(8), 0, 0, 0));
        fabView.setBackground(Ui.ripple(Ui.round(Theme.ACCENT, ui.dp(20)), Ui.round(0xFFFFFFFF, ui.dp(20))));
        fabView.setElevation(ui.dp(10));
        fabView.setOnClickListener(v -> newNote("text"));
        fab = fabView;
        FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(Ui.WRAP, ui.dp(58), Gravity.BOTTOM | Gravity.END);
        fp.setMargins(0, 0, ui.dp(16), ui.dp(18));
        root.addView(fab, fp);

        // всплывающая подсказка с «Отменить»
        snack = ui.row();
        snack.setPadding(ui.dp(18), ui.dp(4), ui.dp(6), ui.dp(4));
        snack.setBackground(Ui.round(0xFF2A2440, ui.dp(14)));
        snack.setElevation(ui.dp(12));
        snackText = ui.text("", 14, Theme.TEXT, false);
        snack.addView(snackText, Ui.lp(0, Ui.WRAP, 1f));
        snackAction = ui.text("ОТМЕНИТЬ", 14, Theme.ACCENT, true);
        snackAction.setPadding(ui.dp(14), ui.dp(14), ui.dp(14), ui.dp(14));
        snackAction.setOnClickListener(v -> {
            Runnable u = snackUndo;
            hideSnack();
            if (u != null) u.run();
        });
        snack.addView(snackAction);
        snack.setVisibility(View.GONE);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP, Gravity.BOTTOM);
        sp.setMargins(ui.dp(12), 0, ui.dp(12), ui.dp(90));
        root.addView(snack, sp);

        buildDrawer();
        panel = new SidePanel(this, ui);
        root.addView(panel, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        pin = new PinPad(this, ui);
        root.addView(pin, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        setContentView(root);
    }

    private View quick(String icon, String label, View.OnClickListener l) {
        ImageView b = ui.iconButton(icon, Theme.TEXT, 46, 12, l);
        b.setContentDescription(label);
        b.setOnLongClickListener(v -> {
            toast(label);
            return true;
        });
        return b;
    }

    // ================================================================== загрузка и отрисовка

    void reload() {
        int token = ++loadToken;
        Store.Query q = new Store.Query();
        q.section = query.section;
        q.folder = query.folder;
        q.tag = query.tag;
        q.text = query.text;
        q.sort = query.sort;
        Media.IO.execute(() -> {
            List<Note> list = store.list(q);
            if (q.section == Store.VAULT) {
                List<String> words = q.text == null ? null : Note.words(q.text);
                ArrayList<Note> open = new ArrayList<>();
                for (Note n : list) {
                    if (!Lock.open(n)) continue;
                    if (words != null && !Note.matches(Note.searchText(n.openTitle, n.openBody), words)) continue;
                    open.add(n);
                }
                list = open;
            }
            Store.Counts counts = store.counts();
            List<Store.Folder> folders = store.folders();
            List<Note> res = list;
            Media.MAIN.post(() -> {
                if (token != loadToken || isFinishing()) return;
                notes = res;
                folderNames = new HashMap<>();
                folderColors = new HashMap<>();
                for (Store.Folder f : folders) {
                    folderNames.put(f.id, f.name);
                    folderColors.put(f.id, f.color);
                }
                if (query.folder > 0 && !folderNames.containsKey(query.folder)) query.folder = 0;
                selected.retainAll(ids(res));
                updateHeader(counts, folders);
                render(false);
                if (drawer.getVisibility() == View.VISIBLE) fillDrawer(counts, folders);
            });
        });
    }

    private static LinkedHashSet<Long> ids(List<Note> l) {
        LinkedHashSet<Long> s = new LinkedHashSet<>();
        for (Note n : l) s.add(n.id);
        return s;
    }

    private void updateHeader(Store.Counts counts, List<Store.Folder> folders) {
        int s = query.section;
        sectionTitle.setText(SECTION_NAMES[s]);
        sectionCount.setText(notes.isEmpty() ? "" : String.valueOf(notes.size()));
        sectionActions.removeAllViews();
        if (s == Store.NOTES || s == Store.ARCHIVE) {
            sectionActions.addView(ui.iconButton("sort", Theme.MUTED, 42, 11, v -> sortPanel()));
        }
        if (s == Store.TRASH && !notes.isEmpty()) {
            TextView empty = ui.text("Очистить", 14, Theme.ACCENT, true);
            empty.setPadding(ui.dp(12), ui.dp(10), ui.dp(12), ui.dp(10));
            empty.setOnClickListener(v -> confirm("Очистить корзину?", Fmt.count(notes.size(), "заметка будет удалена", "заметки будут удалены", "заметок будут удалены")
                    + " навсегда вместе с вложениями.", "Удалить", () -> {
                long[] ids = store.ids("trashed>0");
                Media.IO.execute(() -> {
                    store.deleteForever(ids);
                    Media.MAIN.post(this::reload);
                });
            }));
            sectionActions.addView(empty);
        }
        if (s == Store.VAULT) {
            sectionActions.addView(ui.iconButton("lock", Theme.ACCENT, 42, 10, v -> {
                Lock.lock(this);
                openSection(Store.NOTES);
                toast("Сейф закрыт");
            }));
        }
        boolean showChips = s == Store.NOTES || s == Store.ARCHIVE;
        chipsRow.removeAllViews();
        if (query.tag != null) {
            TextView t = ui.chip("#" + query.tag + "  ✕", true, v -> {
                query.tag = null;
                reload();
            });
            chipsRow.addView(t, chipLp());
        }
        if (showChips && !folders.isEmpty()) {
            chipsRow.addView(ui.chip("Все", query.folder == 0, v -> {
                query.folder = 0;
                reload();
            }), chipLp());
            for (Store.Folder f : folders) {
                Integer n = counts.folders.get(f.id);
                TextView c = ui.chip(f.name + (n != null && s == Store.NOTES ? "  " + n : ""), query.folder == f.id, v -> {
                    query.folder = query.folder == f.id ? 0 : f.id;
                    reload();
                });
                c.setCompoundDrawablesRelativeWithIntrinsicBounds(dot(Note.neon(f.color)), null, null, null);
                c.setCompoundDrawablePadding(ui.dp(8));
                c.setOnLongClickListener(v -> {
                    folderMenu(f);
                    return true;
                });
                chipsRow.addView(c, chipLp());
            }
            TextView add = ui.chip("+ Папка", false, v -> newFolder(null));
            chipsRow.addView(add, chipLp());
        }
        chipsScroll.setVisibility(chipsRow.getChildCount() > 0 ? View.VISIBLE : View.GONE);
        boolean quickBar = s == Store.NOTES || s == Store.VAULT;
        bottomBar.setVisibility(quickBar && selected.isEmpty() ? View.VISIBLE : View.GONE);
        fab.setVisibility(quickBar && selected.isEmpty() ? View.VISIBLE : View.GONE);
        search.setHint(s == Store.NOTES ? "Поиск в заметках" : "Поиск: " + SECTION_NAMES[s].toLowerCase());
    }

    private android.graphics.drawable.Drawable dot(int color) {
        android.graphics.drawable.GradientDrawable d = Ui.oval(color);
        d.setSize(ui.dp(9), ui.dp(9));
        return d;
    }

    private LinearLayout.LayoutParams chipLp() {
        LinearLayout.LayoutParams lp = Ui.lp(Ui.WRAP, Ui.WRAP);
        lp.rightMargin = ui.dp(8);
        return lp;
    }

    private int columns() {
        if (prefs.view() == 1) return 1;
        float wdp = getResources().getDisplayMetrics().widthPixels / ui.density;
        return wdp >= 900 ? 4 : wdp >= 600 ? 3 : 2;
    }

    /** Перерисовать список. keepScroll — после смены вида оставить позицию. */
    private void render(boolean fromToggle) {
        int width = scroll.getWidth() - content.getPaddingLeft() - content.getPaddingRight();
        if (width <= 0) {
            scroll.post(() -> render(fromToggle));
            return;
        }
        int y = scroll.getScrollY();
        int keep = Math.max(PAGE, fromToggle ? PAGE : rendered);
        content.removeAllViews();
        cardViews.clear();
        rendered = 0;
        pinnedBlock = otherBlock = null;
        if (notes.isEmpty()) {
            content.addView(emptyState(), Ui.lp(Ui.MATCH, Ui.WRAP));
            updateSelectionUi();
            return;
        }
        renderUpTo(keep, width);
        updateSelectionUi();
        if (!fromToggle) scroll.post(() -> scroll.scrollTo(0, y));
    }

    private void renderMore() {
        int width = scroll.getWidth() - content.getPaddingLeft() - content.getPaddingRight();
        renderUpTo(rendered + PAGE, width);
    }

    private void renderUpTo(int count, int width) {
        boolean pinGroups = query.section == Store.NOTES || query.section == Store.ARCHIVE || query.section == Store.VAULT;
        boolean anyPinned = pinGroups && !notes.isEmpty() && notes.get(0).pinned;
        int n = columns();
        while (rendered < notes.size() && rendered < count) {
            Note note = notes.get(rendered++);
            Block b;
            if (anyPinned && note.pinned) {
                if (pinnedBlock == null) pinnedBlock = new Block("ЗАКРЕПЛЕНО", n, width);
                b = pinnedBlock;
            } else {
                if (otherBlock == null) otherBlock = new Block(anyPinned ? "ДРУГИЕ" : null, n, width);
                b = otherBlock;
            }
            View card = card(note, b.colWidth);
            cardViews.put(note.id, card);
            b.add(card);
        }
    }

    private View emptyState() {
        LinearLayout box = ui.col();
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(ui.dp(32), ui.dp(80), ui.dp(32), ui.dp(40));
        String icon, text;
        if (query.text != null) {
            icon = "search";
            text = "Ничего не нашлось по запросу «" + query.text + "»";
        } else if (query.tag != null) {
            icon = "tag";
            text = "С тегом #" + query.tag + " заметок нет";
        } else {
            switch (query.section) {
                case Store.REMINDERS: icon = "bell"; text = "Напоминаний нет.\nПоставьте его в заметке — колокольчик вверху."; break;
                case Store.VAULT: icon = "lock"; text = "Сейф пуст.\nЗаметки здесь зашифрованы и открываются только по PIN-коду."; break;
                case Store.ARCHIVE: icon = "archive"; text = "Архив пуст.\nУбирайте сюда то, что жалко удалять, но мешает в списке."; break;
                case Store.TRASH: icon = "trash"; text = "Корзина пуста.\nУдалённые заметки хранятся здесь 30 дней."; break;
                default:
                    icon = query.folder > 0 ? "folder" : "note";
                    text = query.folder > 0 ? "В этой папке пока пусто" : "Здесь будут ваши заметки.\nНажмите «Заметка», чтобы начать.";
            }
        }
        ImageView iv = new ImageView(this);
        iv.setImageDrawable(new Glyph(icon, Theme.alpha(Theme.ACCENT, 200)));
        iv.setBackground(Ui.oval(Theme.alpha(Theme.ACCENT, 22)));
        int p = ui.dp(26);
        iv.setPadding(p, p, p, p);
        box.addView(iv, Ui.lp(ui.dp(104), ui.dp(104)));
        TextView t = ui.text(text, 15, Theme.MUTED, false);
        t.setGravity(Gravity.CENTER);
        t.setLineSpacing(0, 1.35f);
        box.addView(t, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(20), 0, 0));
        return box;
    }

    // ================================================================== карточка

    private View card(Note n, int width) {
        long now = System.currentTimeMillis();
        LinearLayout card = ui.col();
        int fill = Note.fill(n.color);
        card.setTag(n);
        styleCard(card, n, false);
        card.setClipToOutline(true);
        card.setOutlineProvider(Ui.rounded(ui.dp(18)));

        boolean hidden = n.locked && n.openBody == null;
        if (n.thumb != null && !hidden) {
            String[] t = n.thumb.split("\\|");
            int w = t.length > 2 ? parse(t[1]) : 0, h = t.length > 2 ? parse(t[2]) : 0;
            int ih = w > 0 && h > 0 ? Math.round(width * (h / (float) w)) : Math.round(width * 0.75f);
            ih = Math.max(Math.round(width * 0.45f), Math.min(ih, Math.round(width * (columns() == 1 ? 0.6f : 1.35f))));
            FrameLayout imgBox = new FrameLayout(this);
            ImageView img = new ImageView(this);
            img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            img.setBackgroundColor(Theme.mix(fill, 0xFF000000, 0.25f));
            imgBox.addView(img, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
            Media.thumb(this, t[0], Math.min(width, ui.dp(420)), img);
            if (n.images > 1) {
                TextView more = ui.text("+" + (n.images - 1), 12, Theme.TEXT, true);
                more.setPadding(ui.dp(8), ui.dp(4), ui.dp(8), ui.dp(4));
                more.setBackground(Ui.round(0xAA000000, ui.dp(10)));
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM | Gravity.END);
                lp.setMargins(0, 0, ui.dp(8), ui.dp(8));
                imgBox.addView(more, lp);
            }
            card.addView(imgBox, Ui.lp(Ui.MATCH, ih));
        }

        LinearLayout body = ui.col();
        body.setPadding(ui.dp(14), ui.dp(12), ui.dp(14), ui.dp(12));
        String title = hidden ? "" : n.shownTitle();
        String text = hidden ? "" : n.shownBody();
        List<String> words = query.text == null ? null : Note.words(query.text);

        LinearLayout titleRow = ui.row();
        titleRow.setGravity(Gravity.TOP);
        if (hidden) {
            TextView t = ui.text("Заметка в сейфе", 15, Theme.TEXT, true);
            t.setCompoundDrawablesRelativeWithIntrinsicBounds(small("lock", Theme.ACCENT, 16), null, null, null);
            t.setCompoundDrawablePadding(ui.dp(8));
            titleRow.addView(t, Ui.lp(0, Ui.WRAP, 1f));
        } else if (!title.isEmpty()) {
            TextView t = ui.text("", 16, Theme.TEXT, true);
            t.setText(mark(title, words));
            t.setMaxLines(3);
            t.setEllipsize(TextUtils.TruncateAt.END);
            t.setLineSpacing(0, 1.1f);
            titleRow.addView(t, Ui.lp(0, Ui.WRAP, 1f));
        } else {
            titleRow.addView(new View(this), Ui.lp(0, 0, 1f));
        }
        if (n.pinned && query.section != Store.TRASH) {
            ImageView pinIc = new ImageView(this);
            pinIc.setImageDrawable(new Glyph("pinFill", Theme.ACCENT));
            titleRow.addView(pinIc, Ui.margins(ui.dp(16), ui.dp(16), ui.dp(6), ui.dp(2), 0, 0));
        }
        if (titleRow.getChildCount() > 1 || !title.isEmpty() || hidden) body.addView(titleRow);

        if (!text.trim().isEmpty()) {
            TextView b = ui.text("", 14, Theme.mix(Theme.TEXT, Theme.MUTED, 0.25f), false);
            b.setLineSpacing(0, 1.18f);
            b.setText(mark(preview(text), words));
            b.setMaxLines(columns() == 1 ? Math.max(3, prefs.previewLines() / 2) : prefs.previewLines());
            b.setEllipsize(TextUtils.TruncateAt.END);
            body.addView(b, Ui.margins(Ui.MATCH, Ui.WRAP, 0, title.isEmpty() && !hidden ? 0 : ui.dp(6), 0, 0));
        }

        // чипы: напоминание, голос, папка, теги
        FlowRow chips = new FlowRow(this, ui.dp(6));
        if (n.reminder > 0) {
            boolean past = n.fired || n.reminder < now;
            TextView c = miniChip(n.repeat != Repeat.NONE ? "repeat" : "bell", Fmt.reminder(n.reminder, now), past ? Theme.MUTED : Theme.TEXT);
            if (past) c.setPaintFlags(c.getPaintFlags() | android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
            chips.addView(c);
        }
        if (n.audios > 0 && !hidden) {
            chips.addView(miniChip("mic", n.audios > 1 ? n.audios + " · " + Fmt.duration(n.audioMs) : Fmt.duration(n.audioMs), Theme.TEXT));
        }
        if (n.images > 0 && n.thumb == null && !hidden) chips.addView(miniChip("image", String.valueOf(n.images), Theme.TEXT));
        if (n.folder > 0 && query.folder == 0 && folderNames.containsKey(n.folder) && query.section != Store.TRASH) {
            chips.addView(miniChip("folder", folderNames.get(n.folder), Theme.MUTED));
        }
        if (prefs.showTags() && !hidden && !n.locked) {
            int k = 0;
            for (String tag : Note.tagList(n.tags)) {
                if (k++ >= 3) break;
                TextView c = miniChip(null, "#" + tag, Theme.ACCENT2);
                chips.addView(c);
            }
        }
        if (query.section == Store.TRASH) chips.addView(miniChip("trash", "Удалено " + Fmt.ago(n.trashed, now), Theme.MUTED));
        if (chips.getChildCount() > 0) body.addView(chips, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(10), 0, 0));
        if (body.getChildCount() == 0 && (n.thumb == null || hidden)) body.addView(ui.text("Пустая заметка", 14, Theme.MUTED, false));
        if (body.getChildCount() > 0) card.addView(body);

        card.setOnClickListener(v -> {
            if (!selected.isEmpty()) toggleSelect(n);
            else open(n);
        });
        card.setOnLongClickListener(v -> {
            v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
            toggleSelect(n);
            return true;
        });
        return card;
    }

    private static int parse(String s) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private void styleCard(View card, Note n, boolean sel) {
        int fill = Note.fill(n.color);
        int edge = n.color == 0 ? Theme.LINE : Theme.mix(fill, Note.neon(n.color), 0.45f);
        card.setBackground(Ui.ripple(sel ? Ui.stroke(Theme.mix(fill, Theme.ACCENT, 0.12f), Theme.ACCENT, ui.dp(2.5f), ui.dp(18))
                : Ui.stroke(fill, edge, ui.dp(1), ui.dp(18)), Ui.round(0xFFFFFFFF, ui.dp(18))));
    }

    /** Текст для карточки: у чек-листов выполненные пункты сворачиваются в одну строку. */
    private CharSequence preview(String body) {
        String src = body.length() > 2000 ? body.substring(0, 2000) : body;
        if (Md.isChecklist(src)) {
            StringBuilder sb = new StringBuilder();
            int done = 0;
            for (String l : src.split("\n")) {
                java.util.regex.Matcher m = Md.CHECK_LINE.matcher(l);
                if (m.matches() && !m.group(3).equals(" ")) {
                    done++;
                    continue;
                }
                if (sb.length() > 0) sb.append('\n');
                sb.append(l);
            }
            SpannableStringBuilder out = Styler.rendered(Md.render(sb.toString().trim()), Theme.TEXT, null, null);
            if (done > 0) {
                int st = out.length();
                out.append(out.length() > 0 ? "\n" : "").append("+ ").append(Fmt.count(done, "выполненный пункт", "выполненных пункта", "выполненных пунктов"));
                out.setSpan(new android.text.style.ForegroundColorSpan(Theme.MUTED), st, out.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            return out;
        }
        return Styler.rendered(Md.render(src.trim()), Theme.TEXT, null, null);
    }

    /** Подсветить найденные слова. */
    private CharSequence mark(CharSequence text, List<String> words) {
        if (words == null || words.isEmpty()) return text;
        String norm = Note.norm(text.toString());
        if (norm.length() != text.length()) return text;
        SpannableStringBuilder sb = new SpannableStringBuilder(text);
        for (String w : words) {
            int i = 0;
            while ((i = norm.indexOf(w, i)) >= 0) {
                sb.setSpan(new BackgroundColorSpan(Theme.alpha(Theme.ACCENT, 110)), i, i + w.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                i += w.length();
            }
        }
        return sb;
    }

    private TextView miniChip(String icon, String text, int color) {
        TextView t = ui.oneLine(text, 12, color, false);
        t.setPadding(ui.dp(icon == null ? 9 : 7), ui.dp(4), ui.dp(9), ui.dp(4));
        t.setBackground(Ui.round(0x22FFFFFF, ui.dp(10)));
        if (icon != null) {
            t.setCompoundDrawablesRelativeWithIntrinsicBounds(small(icon, color, 14), null, null, null);
            t.setCompoundDrawablePadding(ui.dp(5));
        }
        t.setMaxWidth(ui.dp(200));
        return t;
    }

    private Glyph small(String icon, int color, int dp) {
        Glyph g = new Glyph(icon, color);
        g.setBounds(0, 0, ui.dp(dp), ui.dp(dp));
        return g;
    }

    // ================================================================== открытие и создание

    private void open(Note n) {
        Intent i = new Intent(this, NoteActivity.class).putExtra("id", n.id);
        startActivity(i);
    }

    private void newNote(String kind) {
        Intent i = new Intent(this, NoteActivity.class).putExtra("kind", kind);
        if (query.section == Store.NOTES && query.folder > 0) i.putExtra("folder", query.folder);
        if (query.section == Store.NOTES && query.tag != null) i.putExtra("tag", query.tag);
        if (query.section == Store.VAULT) i.putExtra("vault", true);
        startActivity(i);
    }

    // ================================================================== выбор нескольких

    private void toggleSelect(Note n) {
        if (!selected.remove(n.id)) selected.add(n.id);
        View v = cardViews.get(n.id);
        if (v != null) {
            styleCard(v, n, selected.contains(n.id));
            v.animate().scaleX(selected.contains(n.id) ? 0.97f : 1f).scaleY(selected.contains(n.id) ? 0.97f : 1f).setDuration(120).start();
        }
        updateSelectionUi();
    }

    private void clearSelection() {
        ArrayList<Long> was = new ArrayList<>(selected);
        selected.clear();
        for (Long id : was) {
            View v = cardViews.get(id);
            if (v != null && v.getTag() instanceof Note) {
                styleCard(v, (Note) v.getTag(), false);
                v.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
            }
        }
        updateSelectionUi();
    }

    private void updateSelectionUi() {
        boolean on = !selected.isEmpty();
        topBar.setVisibility(on ? View.INVISIBLE : View.VISIBLE);
        selectBar.setVisibility(on ? View.VISIBLE : View.GONE);
        boolean quickBar = (query.section == Store.NOTES || query.section == Store.VAULT) && !on;
        bottomBar.setVisibility(quickBar ? View.VISIBLE : View.GONE);
        fab.setVisibility(quickBar ? View.VISIBLE : View.GONE);
        if (!on) return;
        selectCount.setText(String.valueOf(selected.size()));
        while (selectBar.getChildCount() > 2) selectBar.removeViewAt(2);
        List<Note> sel = selectedNotes();
        if (query.section == Store.TRASH) {
            selectBar.addView(action("restore", "Восстановить", () -> {
                long[] ids = selectedIds();
                store.restore(ids);
                clearSelection();
                reload();
                snack(Fmt.count(ids.length, "заметка восстановлена", "заметки восстановлены", "заметок восстановлено"), null);
            }));
            selectBar.addView(action("trash", "Удалить навсегда", () -> {
                long[] ids = selectedIds();
                confirm("Удалить навсегда?", "Восстановить будет нельзя.", "Удалить", () -> {
                    store.deleteForever(ids);
                    clearSelection();
                    reload();
                });
            }));
            return;
        }
        boolean allPinned = true;
        for (Note n : sel) if (!n.pinned) allPinned = false;
        boolean pinState = allPinned;
        selectBar.addView(action(allPinned ? "pinFill" : "pin", allPinned ? "Открепить" : "Закрепить", () -> {
            store.set(selectedIds(), "pinned", pinState ? 0 : 1);
            clearSelection();
            reload();
        }));
        selectBar.addView(action("palette", "Цвет", this::colorPanel));
        if (query.section != Store.VAULT) selectBar.addView(action("folder", "В папку", this::folderPanel));
        if (query.section != Store.VAULT) {
            boolean arch = query.section == Store.ARCHIVE;
            selectBar.addView(action(arch ? "unarchive" : "archive", arch ? "Вернуть из архива" : "В архив", () -> {
                long[] ids = selectedIds();
                store.set(ids, "archived", arch ? 0 : 1);
                clearSelection();
                reload();
                snack(arch ? Fmt.count(ids.length, "заметка возвращена", "заметки возвращены", "заметок возвращено")
                        : Fmt.count(ids.length, "заметка в архиве", "заметки в архиве", "заметок в архиве"), () -> {
                    store.set(ids, "archived", arch ? 1 : 0);
                    reload();
                });
            }));
        }
        selectBar.addView(action("trash", "Удалить", () -> {
            long[] ids = selectedIds();
            store.trash(ids);
            clearSelection();
            reload();
            NoteWidget.refreshAll(this);
            snack(Fmt.count(ids.length, "заметка в корзине", "заметки в корзине", "заметок в корзине"), () -> {
                store.restore(ids);
                reload();
            });
        }));
        selectBar.addView(action("more", "Ещё", this::selectionMore));
    }

    private View action(String icon, String label, Runnable r) {
        ImageView b = ui.iconButton(icon, Theme.TEXT, 44, 11, v -> r.run());
        b.setContentDescription(label);
        b.setOnLongClickListener(v -> {
            toast(label);
            return true;
        });
        return b;
    }

    private long[] selectedIds() {
        long[] out = new long[selected.size()];
        int i = 0;
        for (Long id : selected) out[i++] = id;
        return out;
    }

    private List<Note> selectedNotes() {
        ArrayList<Note> out = new ArrayList<>();
        for (Note n : notes) if (selected.contains(n.id)) out.add(n);
        return out;
    }

    private void colorPanel() {
        LinearLayout box = panel.open("Цвет");
        colorSwatches(box, -1, c -> {
            store.set(selectedIds(), "color", c);
            panel.close();
            clearSelection();
            reload();
        });
    }

    /** Ряд цветных кружков. current — выделенный цвет, −1 — никакой. */
    void colorSwatches(LinearLayout box, int current, java.util.function.IntConsumer pick) {
        FlowRow row = new FlowRow(this, ui.dp(12));
        for (int i = 0; i < Note.FILL.length; i++) {
            int c = i;
            FrameLayout sw = new FrameLayout(this);
            View dotV = new View(this);
            dotV.setBackground(Ui.stroke(Note.fill(i), i == 0 ? Theme.MUTED : Note.neon(i), ui.dp(2), ui.dp(30)));
            sw.addView(dotV, new FrameLayout.LayoutParams(ui.dp(46), ui.dp(46), Gravity.CENTER));
            if (i == current) {
                ImageView ck = new ImageView(this);
                ck.setImageDrawable(new Glyph("check", Theme.TEXT));
                sw.addView(ck, new FrameLayout.LayoutParams(ui.dp(22), ui.dp(22), Gravity.CENTER));
            }
            sw.setContentDescription(Note.COLOR_NAMES[i]);
            sw.setOnClickListener(v -> pick.accept(c));
            row.addView(sw, new ViewGroup.LayoutParams(ui.dp(50), ui.dp(50)));
        }
        box.addView(row, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(10), 0, 0));
    }

    private void folderPanel() {
        LinearLayout box = panel.open("Переместить в папку");
        long[] ids = selectedIds();
        panel.option(box, "Без папки", null, false, () -> {
            store.set(ids, "folder", 0);
            panel.close();
            clearSelection();
            reload();
        });
        for (Store.Folder f : store.folders()) {
            panel.option(box, f.name, null, false, () -> {
                store.set(ids, "folder", f.id);
                panel.close();
                clearSelection();
                reload();
                snack("Перемещено в «" + f.name + "»", null);
            });
        }
        panel.option(box, "+ Новая папка", null, false, () -> {
            panel.close();
            newFolder(id -> {
                store.set(ids, "folder", id);
                clearSelection();
                reload();
            });
        });
    }

    private void selectionMore() {
        LinearLayout box = panel.open(Fmt.count(selected.size(), "заметка", "заметки", "заметок"));
        panel.option(box, "Выбрать все", null, false, () -> {
            panel.close();
            for (Note n : notes) selected.add(n.id);
            render(false);
        });
        if (selected.size() == 1) {
            panel.option(box, "Создать копию", null, false, () -> {
                panel.close();
                long id = selectedIds()[0];
                Media.IO.execute(() -> {
                    store.duplicate(id);
                    Media.MAIN.post(() -> {
                        clearSelection();
                        reload();
                        toast("Копия создана");
                    });
                });
            });
        }
        if (query.section != Store.VAULT) {
            panel.option(box, "Поделиться текстом", null, false, () -> {
                panel.close();
                StringBuilder sb = new StringBuilder();
                for (Note n : selectedNotes()) {
                    Note full = store.get(n.id);
                    if (full == null || full.locked) continue;
                    if (sb.length() > 0) sb.append("\n\n———\n\n");
                    if (!full.title.isEmpty()) sb.append(full.title).append("\n\n");
                    sb.append(Md.plain(full.body));
                }
                Intent s = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, sb.toString());
                startActivity(Intent.createChooser(s, "Поделиться"));
            });
            panel.option(box, "Убрать в сейф", "Текст и вложения будут зашифрованы", false, () -> {
                panel.close();
                withVault(() -> moveToVault(selectedIds(), true));
            });
        } else {
            panel.option(box, "Достать из сейфа", "Заметки снова будут храниться без шифрования", false, () -> {
                panel.close();
                moveToVault(selectedIds(), false);
            });
        }
    }

    /** Зашифровать (to=true) или расшифровать заметки вместе с файлами. */
    private void moveToVault(long[] ids, boolean to) {
        byte[] key = Lock.key();
        if (key == null) return;
        toast(to ? "Шифрую…" : "Расшифровываю…");
        Media.IO.execute(() -> {
            int done = 0;
            for (long id : ids) {
                Note n = store.get(id);
                if (n == null || n.locked == to) continue;
                if (to) {
                    Lock.seal(n, n.title, n.body);
                    n.locked = true;
                    n.archived = false;
                    n.folder = 0;
                } else {
                    if (!Lock.open(n)) continue;
                    n.title = n.openTitle;
                    n.body = n.openBody;
                    n.locked = false;
                }
                for (Store.Att a : store.attachments(id)) {
                    if (to ? Media.seal(this, a, key) : Media.unseal(this, a, key)) store.updateAttachment(a);
                }
                store.update(n);
                done++;
            }
            int d = done;
            Media.MAIN.post(() -> {
                clearSelection();
                reload();
                NoteWidget.refreshAll(this);
                snack(to ? Fmt.count(d, "заметка убрана в сейф", "заметки убраны в сейф", "заметок убрано в сейф")
                        : Fmt.count(d, "заметка достана из сейфа", "заметки достаны из сейфа", "заметок достано из сейфа"), null);
            });
        });
    }

    /** Выполнить r, когда сейф открыт: при необходимости создать PIN или спросить его. */
    void withVault(Runnable r) {
        if (Lock.isOpen()) {
            r.run();
            return;
        }
        if (!Lock.isSet(this)) {
            pin.create("Новый сейф", p -> Lock.setup(this, p), () -> {
                toast("Сейф создан");
                r.run();
            }, null);
            return;
        }
        pin.ask("Сейф", "Введите PIN-код", p -> Lock.unlock(this, p), r, null);
        if (Bio.enabled(this)) {
            Runnable bio = () -> Bio.unlock(this, pin::success, () -> {});
            pin.setBio(bio);
            bio.run();
        }
    }

    // ================================================================== разделы, папки, теги

    void openSection(int s) {
        if (s == Store.VAULT && !Lock.isOpen()) {
            withVault(() -> openSection(Store.VAULT));
            return;
        }
        query.section = s;
        if (s != Store.NOTES && s != Store.ARCHIVE) query.folder = 0;
        if (s == Store.VAULT || s == Store.TRASH || s == Store.REMINDERS) query.tag = null;
        selected.clear();
        scroll.scrollTo(0, 0);
        reload();
    }

    private void sortPanel() {
        LinearLayout box = panel.open("Сортировка");
        String[] names = {"По дате изменения", "По дате создания", "По названию"};
        for (int i = 0; i < names.length; i++) {
            int k = i;
            panel.option(box, names[i], null, query.sort == i, () -> {
                query.sort = k;
                prefs.put("sort", k);
                panel.close();
                reload();
            });
        }
        panel.note(box, "Закреплённые заметки всегда наверху.");
    }

    private void newFolder(java.util.function.LongConsumer then) {
        prompt("Новая папка", "", "Название", name -> {
            long id = store.addFolder(name, (store.folders().size() % (Note.NEON.length - 1)) + 1);
            if (then != null) then.accept(id);
            else reload();
        });
    }

    private void folderMenu(Store.Folder f) {
        LinearLayout box = panel.open(f.name);
        panel.option(box, "Переименовать", null, false, () -> {
            panel.close();
            prompt("Название папки", f.name, "Название", name -> {
                f.name = name;
                store.updateFolder(f);
                reload();
            });
        });
        panel.section(box, "ЦВЕТ");
        colorSwatches(box, f.color, c -> {
            f.color = c;
            store.updateFolder(f);
            panel.close();
            reload();
        });
        panel.section(box, "ПОРЯДОК");
        panel.option(box, "Левее", null, false, () -> {
            store.moveFolder(f.id, -1);
            panel.close();
            reload();
        });
        panel.option(box, "Правее", null, false, () -> {
            store.moveFolder(f.id, 1);
            panel.close();
            reload();
        });
        panel.section(box, "");
        panel.option(box, "Удалить папку", "Заметки останутся, просто без папки", false, () -> {
            panel.close();
            confirm("Удалить папку «" + f.name + "»?", "Заметки из неё не удалятся.", "Удалить", () -> {
                store.deleteFolder(f.id);
                if (query.folder == f.id) query.folder = 0;
                reload();
            });
        });
    }

    private void tagMenu(String tag) {
        LinearLayout box = panel.open("#" + tag);
        panel.option(box, "Показать заметки", null, false, () -> {
            panel.close();
            closeDrawer();
            query.section = Store.NOTES;
            query.tag = tag;
            reload();
        });
        panel.option(box, "Переименовать тег", "Изменится во всех заметках", false, () -> {
            panel.close();
            prompt("Новое имя тега", tag, "без #", name -> {
                String clean = name.replace("#", "").trim().replaceAll("\\s+", "_");
                if (clean.isEmpty()) return;
                Media.IO.execute(() -> {
                    int n = store.renameTag(tag, clean);
                    Media.MAIN.post(() -> {
                        if (tag.equals(query.tag)) query.tag = clean.toLowerCase();
                        reload();
                        toast("Обновлено: " + Fmt.count(n, "заметка", "заметки", "заметок"));
                        if (drawer.getVisibility() == View.VISIBLE) openDrawer();
                    });
                });
            });
        });
        panel.option(box, "Удалить тег", "Тег уберётся из текста заметок", false, () -> {
            panel.close();
            confirm("Удалить тег #" + tag + "?", "Сами заметки останутся.", "Удалить", () -> Media.IO.execute(() -> {
                int n = store.renameTag(tag, "");
                Media.MAIN.post(() -> {
                    if (tag.equals(query.tag)) query.tag = null;
                    reload();
                    toast("Тег убран из " + Fmt.count(n, "заметки", "заметок", "заметок"));
                    if (drawer.getVisibility() == View.VISIBLE) openDrawer();
                });
            }));
        });
    }

    // ================================================================== боковое меню

    private void buildDrawer() {
        drawer = new FrameLayout(this);
        drawer.setBackgroundColor(Theme.SCRIM);
        drawer.setVisibility(View.GONE);
        drawer.setOnClickListener(v -> closeDrawer());
        ScrollView sc = new ScrollView(this);
        sc.setVerticalScrollBarEnabled(false);
        sc.setBackground(Ui.round(Theme.PANEL, 0));
        sc.setClickable(true);
        drawerBox = ui.col();
        drawerBox.setPadding(ui.dp(12), ui.dp(20), ui.dp(12), ui.dp(24));
        sc.addView(drawerBox, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        int w = Math.min(ui.dp(320), Math.round(getResources().getDisplayMetrics().widthPixels * 0.84f));
        drawer.addView(sc, new FrameLayout.LayoutParams(w, Ui.MATCH, Gravity.START));
        root.addView(drawer, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
    }

    private void openDrawer() {
        hideKeyboard();
        Media.IO.execute(() -> {
            Store.Counts counts = store.counts();
            List<Store.Folder> folders = store.folders();
            Media.MAIN.post(() -> {
                fillDrawer(counts, folders);
                if (drawer.getVisibility() != View.VISIBLE) {
                    drawer.setVisibility(View.VISIBLE);
                    drawer.setAlpha(0f);
                    drawer.animate().alpha(1f).setDuration(160).start();
                    View sheet = drawer.getChildAt(0);
                    sheet.setTranslationX(-ui.dp(320));
                    sheet.animate().translationX(0).setDuration(220).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
                }
            });
        });
    }

    private void closeDrawer() {
        if (drawer.getVisibility() != View.VISIBLE) return;
        View sheet = drawer.getChildAt(0);
        sheet.animate().translationX(-sheet.getWidth()).setDuration(180).start();
        drawer.animate().alpha(0f).setDuration(180).withEndAction(() -> drawer.setVisibility(View.GONE)).start();
    }

    private void fillDrawer(Store.Counts k, List<Store.Folder> folders) {
        drawerBox.removeAllViews();
        LinearLayout brand = ui.row();
        brand.setPadding(ui.dp(10), 0, 0, ui.dp(14));
        ImageView logo = new ImageView(this);
        logo.setImageDrawable(new Glyph("note", Theme.ACCENT));
        brand.addView(logo, Ui.lp(ui.dp(28), ui.dp(28)));
        TextView name = ui.text("Neon Notes", 21, Theme.TEXT, true);
        brand.addView(name, Ui.margins(Ui.WRAP, Ui.WRAP, ui.dp(12), 0, 0, 0));
        drawerBox.addView(brand);
        int[] counts = {k.notes, k.reminders, k.vault, k.archive, k.trash};
        for (int i = 0; i < SECTION_NAMES.length; i++) {
            int s = i;
            boolean on = query.section == i && query.tag == null && query.folder == 0;
            drawerBox.addView(drawerItem(SECTION_ICONS[i], SECTION_NAMES[i], counts[i] > 0 && i != Store.VAULT ? String.valueOf(counts[i]) : "",
                    on, 0, () -> {
                        closeDrawer();
                        query.tag = null;
                        query.folder = 0;
                        openSection(s);
                    }));
        }
        LinearLayout fh = ui.row();
        fh.setPadding(ui.dp(12), ui.dp(20), ui.dp(4), ui.dp(6));
        fh.addView(ui.label("ПАПКИ"), Ui.lp(0, Ui.WRAP, 1f));
        TextView add = ui.text("+ Новая", 13, Theme.ACCENT, true);
        add.setPadding(ui.dp(10), ui.dp(6), ui.dp(10), ui.dp(6));
        add.setOnClickListener(v -> newFolder(id -> openDrawer()));
        fh.addView(add);
        drawerBox.addView(fh);
        if (folders.isEmpty()) {
            TextView t = ui.text("Папки помогают разложить заметки по темам: работа, дом, учёба.", 12.5f, Theme.MUTED, false);
            t.setLineSpacing(0, 1.25f);
            t.setPadding(ui.dp(12), 0, ui.dp(12), ui.dp(4));
            drawerBox.addView(t);
        }
        for (Store.Folder f : folders) {
            Integer n = k.folders.get(f.id);
            boolean on = query.section == Store.NOTES && query.folder == f.id;
            View item = drawerItem("folder", f.name, n == null ? "" : String.valueOf(n), on, Note.neon(f.color), () -> {
                closeDrawer();
                query.section = Store.NOTES;
                query.folder = f.id;
                query.tag = null;
                reload();
            });
            item.setOnLongClickListener(v -> {
                folderMenu(f);
                return true;
            });
            drawerBox.addView(item);
        }
        if (!k.tags.isEmpty()) {
            LinearLayout th = ui.row();
            th.setPadding(ui.dp(12), ui.dp(20), ui.dp(4), ui.dp(6));
            th.addView(ui.label("ТЕГИ"), Ui.lp(0, Ui.WRAP, 1f));
            drawerBox.addView(th);
            int shown = 0;
            for (Map.Entry<String, Integer> e : k.tags.entrySet()) {
                if (shown++ >= 40) break;
                String tag = e.getKey();
                boolean on = tag.equals(query.tag);
                View item = drawerItem("tag", tag, String.valueOf(e.getValue()), on, 0, () -> {
                    closeDrawer();
                    query.section = Store.NOTES;
                    query.tag = tag;
                    query.folder = 0;
                    reload();
                });
                item.setOnLongClickListener(v -> {
                    tagMenu(tag);
                    return true;
                });
                drawerBox.addView(item);
            }
        }
        View line = new View(this);
        line.setBackgroundColor(Theme.LINE);
        drawerBox.addView(line, Ui.margins(Ui.MATCH, ui.dp(1), ui.dp(12), ui.dp(16), ui.dp(12), ui.dp(8)));
        drawerBox.addView(drawerItem("settings", "Настройки", "", false, 0, () -> {
            closeDrawer();
            startActivity(new Intent(this, SettingsActivity.class));
        }));
    }

    private View drawerItem(String icon, String text, String count, boolean on, int iconColor, Runnable r) {
        LinearLayout row = ui.row();
        row.setPadding(ui.dp(12), ui.dp(12), ui.dp(14), ui.dp(12));
        row.setBackground(Ui.ripple(Ui.round(on ? Theme.alpha(Theme.ACCENT, 40) : 0, ui.dp(14)), Ui.round(0xFFFFFFFF, ui.dp(14))));
        ImageView iv = new ImageView(this);
        iv.setImageDrawable(new Glyph(icon, iconColor != 0 ? iconColor : on ? Theme.ACCENT : Theme.MUTED));
        row.addView(iv, Ui.lp(ui.dp(22), ui.dp(22)));
        TextView t = ui.oneLine(text, 15, on ? Theme.TEXT : 0xFFD8D2EE, on);
        row.addView(t, Ui.margins(0, Ui.WRAP, ui.dp(16), 0, ui.dp(8), 0));
        ((LinearLayout.LayoutParams) t.getLayoutParams()).weight = 1f;
        if (!count.isEmpty()) row.addView(ui.text(count, 13, Theme.MUTED, false));
        row.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams lp = Ui.lp(Ui.MATCH, Ui.WRAP);
        lp.topMargin = ui.dp(2);
        row.setLayoutParams(lp);
        return row;
    }

    // ================================================================== подсказка внизу

    void snack(String text, Runnable undo) {
        snackText.setText(text);
        snackUndo = undo;
        snackAction.setVisibility(undo != null ? View.VISIBLE : View.GONE);
        snack.removeCallbacks(hideSnackRun);
        if (snack.getVisibility() != View.VISIBLE) {
            snack.setVisibility(View.VISIBLE);
            snack.setTranslationY(ui.dp(40));
            snack.setAlpha(0f);
            snack.animate().translationY(0).alpha(1f).setDuration(180).start();
        }
        snack.postDelayed(hideSnackRun, undo != null ? 5000 : 2800);
    }

    private final Runnable hideSnackRun = this::hideSnack;

    private void hideSnack() {
        snackUndo = null;
        snack.animate().alpha(0f).translationY(ui.dp(30)).setDuration(160).withEndAction(() -> snack.setVisibility(View.GONE)).start();
    }

    // ================================================================== назад

    @Override
    public void onBackPressed() {
        if (pin.isShowing()) pin.cancel();
        else if (panel.isOpen()) panel.close();
        else if (drawer.getVisibility() == View.VISIBLE) closeDrawer();
        else if (!selected.isEmpty()) clearSelection();
        else if (query.text != null) search.setText("");
        else if (query.tag != null) {
            query.tag = null;
            reload();
        } else if (query.folder > 0) {
            query.folder = 0;
            reload();
        } else if (query.section != Store.NOTES) openSection(Store.NOTES);
        else super.onBackPressed();
    }

    @Override
    public boolean onKeyDown(int code, KeyEvent e) {
        if (code == KeyEvent.KEYCODE_N && e.isCtrlPressed()) {
            newNote("text");
            return true;
        }
        if (code == KeyEvent.KEYCODE_F && e.isCtrlPressed()) {
            search.requestFocus();
            return true;
        }
        return super.onKeyDown(code, e);
    }

    // ================================================================== перенос по строкам

    /** Простой контейнер «в строку с переносом» — для чипов на карточке и палитры. */
    static final class FlowRow extends ViewGroup {
        private final int gap;

        FlowRow(android.content.Context c, int gap) {
            super(c);
            this.gap = gap;
        }

        @Override
        protected void onMeasure(int ws, int hs) {
            int max = MeasureSpec.getMode(ws) == MeasureSpec.UNSPECIFIED ? Integer.MAX_VALUE : MeasureSpec.getSize(ws);
            int x = 0, y = 0, rowH = 0, widest = 0;
            for (int i = 0; i < getChildCount(); i++) {
                View ch = getChildAt(i);
                if (ch.getVisibility() == GONE) continue;
                LayoutParams lp = ch.getLayoutParams();
                int cw = lp != null && lp.width > 0 ? MeasureSpec.makeMeasureSpec(lp.width, MeasureSpec.EXACTLY)
                        : MeasureSpec.makeMeasureSpec(max == Integer.MAX_VALUE ? 0 : max, max == Integer.MAX_VALUE ? MeasureSpec.UNSPECIFIED : MeasureSpec.AT_MOST);
                int chs = lp != null && lp.height > 0 ? MeasureSpec.makeMeasureSpec(lp.height, MeasureSpec.EXACTLY)
                        : MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED);
                ch.measure(cw, chs);
                int w = ch.getMeasuredWidth(), h = ch.getMeasuredHeight();
                if (x > 0 && x + w > max) {
                    x = 0;
                    y += rowH + gap;
                    rowH = 0;
                }
                x += w + gap;
                widest = Math.max(widest, x - gap);
                rowH = Math.max(rowH, h);
            }
            int width = MeasureSpec.getMode(ws) == MeasureSpec.EXACTLY ? MeasureSpec.getSize(ws) : Math.min(widest, max);
            setMeasuredDimension(width, y + rowH);
        }

        @Override
        protected void onLayout(boolean changed, int l, int t, int r, int b) {
            int max = r - l, x = 0, y = 0, rowH = 0;
            for (int i = 0; i < getChildCount(); i++) {
                View ch = getChildAt(i);
                if (ch.getVisibility() == GONE) continue;
                int w = ch.getMeasuredWidth(), h = ch.getMeasuredHeight();
                if (x > 0 && x + w > max) {
                    x = 0;
                    y += rowH + gap;
                    rowH = 0;
                }
                ch.layout(x, y, x + w, y + h);
                x += w + gap;
                rowH = Math.max(rowH, h);
            }
        }
    }
}
