package com.neondrift.notes;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;

/** Заметка. Для зашифрованных заметок title пуст, а body — запечатанные «заголовок + текст». */
final class Note {
    long id;
    String title = "", body = "";
    int color;
    long folder;
    boolean pinned, archived, locked, fired;
    long trashed, created, edited, reminder;
    int repeat;
    String tags = "";

    // для списка: первая картинка и счётчики вложений
    String thumb;
    int images, audios;
    long audioMs;

    // открытый текст зашифрованной заметки (только в памяти, пока сейф открыт)
    String openTitle, openBody;

    static final String[] COLOR_NAMES = {"Без цвета", "Малина", "Закат", "Янтарь", "Мята", "Бирюза", "Океан", "Аметист", "Графит"};
    /** Фон карточки — тёмные насыщенные оттенки, текст на них читается. */
    static final int[] FILL = {0xFF15111F, 0xFF3D1430, 0xFF3F2212, 0xFF3A3013, 0xFF113528, 0xFF0F3039, 0xFF142446, 0xFF2A1A4C, 0xFF24232C};
    /** Неоновый цвет обводки и точки в палитре. */
    static final int[] NEON = {0xFF6C6488, 0xFFFF4F9A, 0xFFFF8A3D, 0xFFFFD447, 0xFF3DFFB0, 0xFF33E1FF, 0xFF5C8DFF, 0xFFB57BFF, 0xFFB8B8C8};

    static int fill(int c) {
        return FILL[c >= 0 && c < FILL.length ? c : 0];
    }

    static int neon(int c) {
        return NEON[c >= 0 && c < NEON.length ? c : 0];
    }

    String shownTitle() {
        return locked ? (openTitle != null ? openTitle : "") : title;
    }

    String shownBody() {
        return locked ? (openBody != null ? openBody : "") : body;
    }

    boolean isBlank() {
        return title.trim().isEmpty() && body.trim().isEmpty() && images == 0 && audios == 0 && !locked;
    }

    Note copy() {
        Note n = new Note();
        n.id = id; n.title = title; n.body = body; n.color = color; n.folder = folder;
        n.pinned = pinned; n.archived = archived; n.locked = locked; n.fired = fired;
        n.trashed = trashed; n.created = created; n.edited = edited; n.reminder = reminder;
        n.repeat = repeat; n.tags = tags; n.thumb = thumb; n.images = images; n.audios = audios;
        n.audioMs = audioMs; n.openTitle = openTitle; n.openBody = openBody;
        return n;
    }

    // ================================================================== поиск и теги

    /** Строчные буквы, «ё» как «е» — чтобы поиск находил оба написания. */
    static String norm(String s) {
        if (s == null) return "";
        return s.toLowerCase(Locale.ROOT).replace('ё', 'е');
    }

    static String searchText(String title, String body) {
        return norm(title + "\n" + Md.plain(body == null ? "" : body));
    }

    static List<String> words(String query) {
        ArrayList<String> out = new ArrayList<>();
        for (String w : norm(query).trim().split("\\s+")) if (!w.isEmpty()) out.add(w);
        return out;
    }

    /** Все слова запроса встречаются в тексте. */
    static boolean matches(String normText, List<String> words) {
        for (String w : words) if (!normText.contains(w)) return false;
        return true;
    }

    /** Теги храним как «,дом,работа,» — так их легко искать в SQLite через LIKE. */
    static String tagString(Collection<String> tags) {
        if (tags.isEmpty()) return "";
        StringBuilder sb = new StringBuilder(",");
        for (String t : tags) sb.append(t).append(',');
        return sb.toString();
    }

    static List<String> tagList(String s) {
        ArrayList<String> out = new ArrayList<>();
        if (s == null) return out;
        for (String t : s.split(",")) if (!t.isEmpty()) out.add(t);
        return out;
    }

    /** Экранировать % и _ для LIKE ... ESCAPE '\'. */
    static String like(String s) {
        return s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_");
    }

    /** Имя файла для экспорта: без запрещённых символов, не длиннее 60. */
    static String fileName(String title, String fallback) {
        String s = title == null ? "" : title.replaceAll("[\\\\/:*?\"<>|\\n\\r\\t]+", " ").replaceAll("\\s+", " ").trim();
        if (s.length() > 60) s = s.substring(0, 60).trim();
        return s.isEmpty() ? fallback : s;
    }
}
