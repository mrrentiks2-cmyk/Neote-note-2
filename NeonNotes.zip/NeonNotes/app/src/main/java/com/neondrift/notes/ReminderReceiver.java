package com.neondrift.notes;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Срабатывание напоминания и кнопки в уведомлении. */
public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        long id = i.getLongExtra("id", 0);
        if (id == 0 || i.getAction() == null) return;
        PendingResult pr = goAsync();
        Context app = c.getApplicationContext();
        new Thread(() -> {
            try {
                handle(app, i.getAction(), id, i.getIntExtra("minutes", 10));
            } finally {
                pr.finish();
            }
        }).start();
    }

    private static void handle(Context c, String action, long id, int minutes) {
        Store st = Store.get(c);
        Note n = st.get(id);
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (n == null || n.trashed > 0) {
            if (nm != null) nm.cancel((int) id);
            return;
        }
        switch (action) {
            case Reminders.ACTION_FIRE:
                if (n.reminder > 0 && !n.fired) Reminders.fire(c, n);
                break;
            case Reminders.ACTION_SNOOZE:
                if (nm != null) nm.cancel((int) id);
                long when = System.currentTimeMillis() + minutes * 60_000L;
                if (n.repeat != Repeat.NONE) {
                    // у повторяющихся — разовый звонок, следующее по расписанию остаётся как было
                    Reminders.later(c, id, when);
                    break;
                }
                n.reminder = when;
                n.fired = false;
                st.set(new long[]{id}, "reminder", n.reminder);
                st.set(new long[]{id}, "fired", 0);
                Reminders.schedule(c, n);
                break;
            case Reminders.ACTION_LATE:
                Reminders.notify(c, n);
                break;
            case Reminders.ACTION_DONE:
                if (nm != null) nm.cancel((int) id);
                if (n.repeat == Repeat.NONE) {
                    st.set(new long[]{id}, "reminder", 0);
                    st.set(new long[]{id}, "fired", 0);
                }
                break;
            default:
                break;
        }
        NoteWidget.refreshAll(c);
    }
}
