package com.neondrift.notes;

import android.content.Context;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

/**
 * Экран ввода PIN-кода поверх содержимого. Проверка идёт в фоне: вывод ключа занимает долю секунды.
 */
final class PinPad extends FrameLayout {
    interface Check { boolean test(String pin); }

    private final Ui ui;
    private final TextView title, sub, error;
    private final LinearLayout dots;
    private final ProgressBar busy;
    private final TextView bioButton;
    private final StringBuilder pin = new StringBuilder();
    private Check check;
    private Runnable onOk, onCancel, onBio;
    private String first; // при создании PIN — первый ввод
    private boolean setupMode, working;

    PinPad(Context c, Ui ui) {
        super(c);
        this.ui = ui;
        setBackgroundColor(Theme.BG);
        setClickable(true);
        setVisibility(GONE);

        LinearLayout col = ui.col();
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(ui.dp(24), ui.dp(24), ui.dp(24), ui.dp(24));

        ImageView lock = new ImageView(c);
        lock.setImageDrawable(new Glyph("lock", Theme.ACCENT));
        lock.setBackground(Ui.oval(Theme.alpha(Theme.ACCENT, 34)));
        int p = ui.dp(16);
        lock.setPadding(p, p, p, p);
        col.addView(lock, Ui.margins(ui.dp(72), ui.dp(72), 0, ui.dp(8), 0, ui.dp(18)));
        title = ui.text("", 21, Theme.TEXT, true);
        title.setGravity(Gravity.CENTER);
        col.addView(title);
        sub = ui.text("", 13.5f, Theme.MUTED, false);
        sub.setGravity(Gravity.CENTER);
        sub.setLineSpacing(0, 1.25f);
        col.addView(sub, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(8), 0, 0));

        dots = ui.row();
        dots.setGravity(Gravity.CENTER);
        col.addView(dots, Ui.margins(Ui.MATCH, ui.dp(26), 0, ui.dp(26), 0, ui.dp(6)));
        error = ui.text("", 13, 0xFFFF5C7A, true);
        error.setGravity(Gravity.CENTER);
        col.addView(error, Ui.lp(Ui.MATCH, ui.dp(22)));
        busy = new ProgressBar(c);
        busy.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(Theme.ACCENT));
        busy.setVisibility(INVISIBLE);
        col.addView(busy, Ui.lp(ui.dp(26), ui.dp(26)));

        String[] keys = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "del", "0", "ok"};
        LinearLayout grid = ui.col();
        for (int r = 0; r < 4; r++) {
            LinearLayout row = ui.row();
            row.setGravity(Gravity.CENTER);
            for (int k = 0; k < 3; k++) row.addView(key(keys[r * 3 + k]), Ui.margins(ui.dp(76), ui.dp(64), ui.dp(9), ui.dp(5), ui.dp(9), ui.dp(5)));
            grid.addView(row);
        }
        col.addView(grid, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(10), 0, 0));
        bioButton = ui.text("Отпечаток пальца", 14, Theme.ACCENT, true);
        bioButton.setPadding(ui.dp(16), ui.dp(12), ui.dp(16), ui.dp(12));
        bioButton.setOnClickListener(v -> { if (onBio != null) onBio.run(); });
        bioButton.setVisibility(GONE);
        col.addView(bioButton, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(8), 0, 0));

        android.widget.ScrollView sc = new android.widget.ScrollView(c);
        sc.setFillViewport(true);
        FrameLayout center = new FrameLayout(c);
        center.addView(col, new LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.CENTER));
        sc.addView(center, new LayoutParams(Ui.MATCH, Ui.WRAP));
        addView(sc, new LayoutParams(Ui.MATCH, Ui.MATCH));
        ImageView close = ui.iconButton("close", Theme.MUTED, 48, 12, v -> cancel());
        addView(close, new LayoutParams(ui.dp(48), ui.dp(48), Gravity.TOP | Gravity.START));
    }

    private View key(String k) {
        View v;
        if (k.equals("del") || k.equals("ok")) {
            ImageView iv = new ImageView(getContext());
            iv.setImageDrawable(new Glyph(k.equals("del") ? "backspace" : "check", k.equals("ok") ? Theme.ACCENT : Theme.TEXT));
            int p = ui.dp(19);
            iv.setPadding(p, p, p, p);
            v = iv;
        } else {
            TextView t = ui.text(k, 26, Theme.TEXT, false);
            t.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
            t.setGravity(Gravity.CENTER);
            v = t;
        }
        v.setBackground(Ui.ripple(Ui.round(k.equals("ok") ? Theme.alpha(Theme.ACCENT, 30) : Theme.SURFACE, ui.dp(22)), Ui.round(0xFFFFFFFF, ui.dp(22))));
        v.setOnClickListener(x -> press(k));
        v.setContentDescription(k);
        return v;
    }

    boolean isShowing() {
        return getVisibility() == VISIBLE;
    }

    /** Ввод существующего PIN. check выполняется в фоновом потоке. */
    void ask(String t, String s, Check check, Runnable ok, Runnable cancel) {
        setupMode = false;
        first = null;
        show(t, s, check, ok, cancel);
    }

    /** Создание нового PIN (дважды). check получает подтверждённый PIN и сохраняет его. */
    void create(String t, Check save, Runnable ok, Runnable cancel) {
        setupMode = true;
        first = null;
        show(t, "Придумайте PIN из 4–8 цифр. Его нельзя восстановить — запомните его.", save, ok, cancel);
    }

    void setBio(Runnable bio) {
        onBio = bio;
        bioButton.setVisibility(bio != null ? VISIBLE : GONE);
    }

    private void show(String t, String s, Check c, Runnable ok, Runnable cancel) {
        check = c;
        onOk = ok;
        onCancel = cancel;
        title.setText(t);
        sub.setText(s);
        error.setText("");
        pin.setLength(0);
        working = false;
        busy.setVisibility(INVISIBLE);
        drawDots();
        if (getVisibility() != VISIBLE) {
            setVisibility(VISIBLE);
            setAlpha(0f);
            animate().alpha(1f).setDuration(150).start();
        }
    }

    void hide() {
        onBio = null;
        bioButton.setVisibility(GONE);
        animate().alpha(0f).setDuration(130).withEndAction(() -> setVisibility(GONE)).start();
    }

    void cancel() {
        if (working) return;
        hide();
        if (onCancel != null) onCancel.run();
    }

    /** Отпечаток подтвердил вход. */
    void success() {
        hide();
        if (onOk != null) onOk.run();
    }

    private void press(String k) {
        if (working) return;
        error.setText("");
        if (k.equals("del")) {
            if (pin.length() > 0) pin.setLength(pin.length() - 1);
        } else if (k.equals("ok")) {
            submit();
            return;
        } else if (pin.length() < 8) {
            pin.append(k);
        }
        drawDots();
    }

    private void submit() {
        if (pin.length() < 4) {
            fail("Нужно хотя бы 4 цифры");
            return;
        }
        String p = pin.toString();
        if (setupMode && first == null) {
            first = p;
            pin.setLength(0);
            sub.setText("Повторите PIN, чтобы не ошибиться");
            drawDots();
            return;
        }
        if (setupMode && !first.equals(p)) {
            first = null;
            sub.setText("Придумайте PIN из 4–8 цифр. Его нельзя восстановить — запомните его.");
            fail("PIN не совпал — попробуйте заново");
            return;
        }
        working = true;
        busy.setVisibility(VISIBLE);
        Media.IO.execute(() -> {
            boolean ok = check.test(p);
            post(() -> {
                working = false;
                busy.setVisibility(INVISIBLE);
                if (ok) {
                    hide();
                    if (onOk != null) onOk.run();
                } else fail("Неверный PIN");
            });
        });
    }

    private void fail(String msg) {
        error.setText(msg);
        pin.setLength(0);
        drawDots();
        dots.animate().translationX(ui.dp(14)).setDuration(50).withEndAction(() -> dots.animate().translationX(-ui.dp(12)).setDuration(60)
                .withEndAction(() -> dots.animate().translationX(ui.dp(6)).setDuration(60)
                        .withEndAction(() -> dots.animate().translationX(0).setDuration(50).start()).start()).start()).start();
        performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
    }

    private void drawDots() {
        dots.removeAllViews();
        int n = Math.max(4, pin.length());
        for (int i = 0; i < n; i++) {
            View d = new View(getContext());
            boolean on = i < pin.length();
            d.setBackground(on ? Ui.oval(Theme.ACCENT) : Ui.stroke(0, Theme.MUTED, ui.dp(1.5f), ui.dp(10)));
            dots.addView(d, Ui.margins(ui.dp(14), ui.dp(14), ui.dp(7), 0, ui.dp(7), 0));
        }
    }
}
