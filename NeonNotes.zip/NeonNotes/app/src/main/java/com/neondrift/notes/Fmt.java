package com.neondrift.notes;

import java.util.Calendar;

/** Даты, длительности и склонения для русского интерфейса. */
final class Fmt {
    private Fmt() {}

    static final String[] MON = {"янв", "фев", "мар", "апр", "мая", "июн", "июл", "авг", "сен", "окт", "ноя", "дек"};
    static final String[] MONTHS = {"января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа",
            "сентября", "октября", "ноября", "декабря"};
    static final String[] WD = {"Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"};

    static Calendar cal(long t) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(t);
        return c;
    }

    static long dayStart(long t) {
        Calendar c = cal(t);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    /** Разница в календарных днях (t − now): 0 — сегодня, 1 — завтра, −1 — вчера. */
    static int dayDiff(long t, long now) {
        Calendar a = cal(dayStart(now)), b = cal(dayStart(t));
        int d = 0;
        if (b.before(a)) {
            while (b.before(a) && d > -400) { b.add(Calendar.DAY_OF_MONTH, 1); d--; }
        } else {
            while (a.before(b) && d < 400) { a.add(Calendar.DAY_OF_MONTH, 1); d++; }
        }
        return d;
    }

    static String time(long t) {
        Calendar c = cal(t);
        return c.get(Calendar.HOUR_OF_DAY) + ":" + two(c.get(Calendar.MINUTE));
    }

    static String two(int n) {
        return n < 10 ? "0" + n : String.valueOf(n);
    }

    private static String date(Calendar c, long now, boolean longMonth) {
        String s = c.get(Calendar.DAY_OF_MONTH) + " " + (longMonth ? MONTHS : MON)[c.get(Calendar.MONTH)];
        if (c.get(Calendar.YEAR) != cal(now).get(Calendar.YEAR)) s += " " + c.get(Calendar.YEAR);
        return s;
    }

    /** Время изменения для карточек: «14:05», «Вчера», «12 окт», «12 окт 2025». */
    static String when(long t, long now) {
        int d = dayDiff(t, now);
        if (d == 0) return time(t);
        if (d == -1) return "Вчера";
        return date(cal(t), now, false);
    }

    /** Подробно: «Сегодня, 14:05», «12 октября 2025, 14:05». */
    static String full(long t, long now) {
        int d = dayDiff(t, now);
        if (d == 0) return "Сегодня, " + time(t);
        if (d == -1) return "Вчера, " + time(t);
        return date(cal(t), now, true) + ", " + time(t);
    }

    /** Время напоминания: «Сегодня, 9:00», «Завтра, 9:00», «Пт, 9:00», «12 окт, 9:00». */
    static String reminder(long t, long now) {
        int d = dayDiff(t, now);
        String day;
        if (d == 0) day = "Сегодня";
        else if (d == 1) day = "Завтра";
        else if (d == -1) day = "Вчера";
        else if (d > 1 && d < 7) day = WD[cal(t).get(Calendar.DAY_OF_WEEK) - 1];
        else day = date(cal(t), now, false);
        return day + ", " + time(t);
    }

    /** «0:05», «12:34», «1:02:03». */
    static String duration(long ms) {
        long s = Math.max(0, ms / 1000);
        long h = s / 3600, m = (s % 3600) / 60, sec = s % 60;
        return h > 0 ? h + ":" + two((int) m) + ":" + two((int) sec) : m + ":" + two((int) sec);
    }

    /** plural(5, "заметка", "заметки", "заметок") → «заметок». */
    static String plural(long n, String one, String few, String many) {
        long a = Math.abs(n) % 100, b = a % 10;
        if (a > 10 && a < 20) return many;
        if (b == 1) return one;
        if (b >= 2 && b <= 4) return few;
        return many;
    }

    static String count(long n, String one, String few, String many) {
        return n + " " + plural(n, one, few, many);
    }

    /** Для корзины: «сегодня», «вчера», «3 дня назад». */
    static String ago(long t, long now) {
        int d = -dayDiff(t, now);
        if (d <= 0) return "сегодня";
        if (d == 1) return "вчера";
        return count(d, "день", "дня", "дней") + " назад";
    }

    static String size(long bytes) {
        if (bytes < 1024) return bytes + " Б";
        if (bytes < 1024 * 1024) return Math.round(bytes / 1024.0) + " КБ";
        return String.format(java.util.Locale.ROOT, "%.1f МБ", bytes / 1048576.0).replace('.', ',');
    }
}
