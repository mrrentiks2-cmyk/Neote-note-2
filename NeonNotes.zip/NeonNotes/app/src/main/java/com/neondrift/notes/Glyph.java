package com.neondrift.notes;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;

/** Векторные иконки, нарисованные кодом в сетке 24×24. */
final class Glyph extends Drawable {
    private final String name;
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path p = new Path();
    private final RectF r = new RectF();

    Glyph(String name, int color) {
        this.name = name;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(2f);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        fill.setStyle(Paint.Style.FILL_AND_STROKE);
        fill.setStrokeWidth(1.2f);
        fill.setStrokeJoin(Paint.Join.ROUND);
        text.setTextAlign(Paint.Align.CENTER);
        text.setTypeface(Typeface.DEFAULT_BOLD);
        setColor(color);
    }

    void setColor(int color) {
        stroke.setColor(color);
        fill.setColor(color);
        text.setColor(color);
        invalidateSelf();
    }

    @Override
    public void draw(Canvas c) {
        Rect b = getBounds();
        float s = Math.min(b.width(), b.height()) / 24f;
        if (s <= 0) return;
        c.save();
        c.translate(b.left + (b.width() - 24f * s) / 2f, b.top + (b.height() - 24f * s) / 2f);
        c.scale(s, s);
        paint(c);
        c.restore();
    }

    private void tri(float x0, float y0, float x1, float y1, float x2, float y2) {
        p.reset();
        p.moveTo(x0, y0);
        p.lineTo(x1, y1);
        p.lineTo(x2, y2);
        p.close();
    }

    private void line(Canvas c, float x0, float y0, float x1, float y1) {
        c.drawLine(x0, y0, x1, y1, stroke);
    }

    private void poly(Canvas c, float... xy) {
        p.reset();
        p.moveTo(xy[0], xy[1]);
        for (int i = 2; i + 1 < xy.length; i += 2) p.lineTo(xy[i], xy[i + 1]);
        c.drawPath(p, stroke);
    }

    private void arcArrow(Canvas c, boolean clockwise) {
        r.set(5f, 6f, 19f, 20f);
        p.reset();
        if (clockwise) {
            p.addArc(r, -100f, 300f);
            c.drawPath(p, stroke);
            tri(12.5f, 2.6f, 16.2f, 6f, 12.5f, 9.4f);
        } else {
            p.addArc(r, -80f, -300f);
            c.drawPath(p, stroke);
            tri(11.5f, 2.6f, 7.8f, 6f, 11.5f, 9.4f);
        }
        c.drawPath(p, fill);
    }

    private void paint(Canvas c) {
        switch (name) {
            case "play":
                tri(8f, 5f, 19.5f, 12f, 8f, 19f);
                c.drawPath(p, fill);
                break;
            case "pause":
                r.set(6f, 5f, 10f, 19f);
                c.drawRoundRect(r, 1f, 1f, fill);
                r.set(14f, 5f, 18f, 19f);
                c.drawRoundRect(r, 1f, 1f, fill);
                break;
            case "replay":
                arcArrow(c, true);
                break;
            case "next":
                tri(5f, 6f, 14.5f, 12f, 5f, 18f);
                c.drawPath(p, fill);
                r.set(16f, 6f, 18.5f, 18f);
                c.drawRoundRect(r, 0.8f, 0.8f, fill);
                break;
            case "prev":
                tri(19f, 6f, 9.5f, 12f, 19f, 18f);
                c.drawPath(p, fill);
                r.set(5.5f, 6f, 8f, 18f);
                c.drawRoundRect(r, 0.8f, 0.8f, fill);
                break;
            case "rewind":
            case "forward": {
                boolean fwd = name.equals("forward");
                arcArrow(c, fwd);
                text.setTextSize(6.4f);
                c.drawText("10", 12f, 15.6f, text);
                break;
            }
            case "back":
                poly(c, 15f, 5f, 8f, 12f, 15f, 19f);
                break;
            case "close":
                line(c, 6f, 6f, 18f, 18f);
                line(c, 18f, 6f, 6f, 18f);
                break;
            case "more":
                c.drawCircle(12f, 5.5f, 1.9f, fill);
                c.drawCircle(12f, 12f, 1.9f, fill);
                c.drawCircle(12f, 18.5f, 1.9f, fill);
                break;
            case "lock":
            case "unlock": {
                r.set(5.5f, 11f, 18.5f, 20.5f);
                c.drawRoundRect(r, 2f, 2f, fill);
                p.reset();
                if (name.equals("lock")) {
                    p.moveTo(8.5f, 11f);
                    p.lineTo(8.5f, 8f);
                    r.set(8.5f, 4f, 15.5f, 11f);
                    p.arcTo(r, 180f, 180f);
                    p.lineTo(15.5f, 11f);
                } else {
                    p.moveTo(8.5f, 11f);
                    p.lineTo(8.5f, 8f);
                    r.set(8.5f, 4f, 15.5f, 11f);
                    p.arcTo(r, 180f, 160f);
                }
                c.drawPath(p, stroke);
                break;
            }
            case "rotate":
                r.set(4.5f, 4.5f, 19.5f, 19.5f);
                p.reset();
                p.addArc(r, 200f, 290f);
                c.drawPath(p, stroke);
                tri(3.2f, 8.6f, 6.1f, 4.8f, 8.4f, 9.6f);
                c.drawPath(p, fill);
                r.set(9.5f, 8.5f, 14.5f, 15.5f);
                c.drawRoundRect(r, 1f, 1f, stroke);
                break;
            case "aspect":
                r.set(3f, 5.5f, 21f, 18.5f);
                c.drawRoundRect(r, 2f, 2f, stroke);
                poly(c, 7f, 12f, 7f, 9f, 10f, 9f);
                poly(c, 17f, 12f, 17f, 15f, 14f, 15f);
                break;
            case "subs":
                r.set(3f, 5f, 21f, 19f);
                c.drawRoundRect(r, 2.5f, 2.5f, stroke);
                line(c, 7f, 11f, 13f, 11f);
                line(c, 15.5f, 11f, 17f, 11f);
                line(c, 7f, 15f, 9f, 15f);
                line(c, 11.5f, 15f, 17f, 15f);
                break;
            case "audio":
                c.drawCircle(8f, 17f, 2.8f, fill);
                line(c, 10.8f, 17f, 10.8f, 5f);
                p.reset();
                p.moveTo(10.8f, 5f);
                p.lineTo(18f, 7f);
                p.lineTo(18f, 10f);
                p.lineTo(10.8f, 8f);
                p.close();
                c.drawPath(p, fill);
                break;
            case "speed":
                r.set(3.5f, 5f, 20.5f, 22f);
                p.reset();
                p.addArc(r, 180f, 180f);
                c.drawPath(p, stroke);
                line(c, 12f, 13.5f, 16.5f, 8.5f);
                c.drawCircle(12f, 13.5f, 1.8f, fill);
                break;
            case "pip":
                r.set(3f, 5f, 21f, 19f);
                c.drawRoundRect(r, 2f, 2f, stroke);
                r.set(12f, 11.5f, 18.5f, 16.5f);
                c.drawRoundRect(r, 1f, 1f, fill);
                break;
            case "eq":
                line(c, 6f, 4f, 6f, 20f);
                line(c, 12f, 4f, 12f, 20f);
                line(c, 18f, 4f, 18f, 20f);
                c.drawCircle(6f, 9f, 2.4f, fill);
                c.drawCircle(12f, 15f, 2.4f, fill);
                c.drawCircle(18f, 7.5f, 2.4f, fill);
                break;
            case "timer":
                c.drawCircle(12f, 13.5f, 7.5f, stroke);
                line(c, 12f, 13.5f, 12f, 9.5f);
                line(c, 12f, 13.5f, 15f, 15.5f);
                line(c, 9.5f, 3f, 14.5f, 3f);
                break;
            case "repeat":
            case "repeatOne":
                poly(c, 5f, 12f, 5f, 8f, 17f, 8f);
                tri(16f, 5f, 19.5f, 8f, 16f, 11f);
                c.drawPath(p, fill);
                poly(c, 19f, 12f, 19f, 16f, 7f, 16f);
                tri(8f, 13f, 4.5f, 16f, 8f, 19f);
                c.drawPath(p, fill);
                if (name.equals("repeatOne")) {
                    text.setTextSize(6f);
                    c.drawText("1", 12f, 14.2f, text);
                }
                break;
            case "ab":
                text.setTextSize(9f);
                c.drawText("A-B", 12f, 15.3f, text);
                break;
            case "info":
                c.drawCircle(12f, 12f, 9f, stroke);
                c.drawCircle(12f, 7.8f, 1.3f, fill);
                line(c, 12f, 11f, 12f, 16.8f);
                break;
            case "folder":
                p.reset();
                p.moveTo(3f, 7f);
                p.lineTo(3f, 18f);
                p.lineTo(21f, 18f);
                p.lineTo(21f, 8.5f);
                p.lineTo(11.5f, 8.5f);
                p.lineTo(9.5f, 6f);
                p.lineTo(4f, 6f);
                p.close();
                c.drawPath(p, stroke);
                break;
            case "file":
                poly(c, 14f, 3f, 6f, 3f, 6f, 21f, 18f, 21f, 18f, 7f, 14f, 3f, 14f, 7f, 18f, 7f);
                line(c, 9f, 12f, 15f, 12f);
                line(c, 9f, 16f, 15f, 16f);
                break;
            case "search":
                c.drawCircle(10.5f, 10.5f, 6f, stroke);
                line(c, 15f, 15f, 20f, 20f);
                break;
            case "sort":
                line(c, 4f, 7f, 20f, 7f);
                line(c, 4f, 12f, 15f, 12f);
                line(c, 4f, 17f, 10f, 17f);
                break;
            case "link":
                c.save();
                c.rotate(-45f, 12f, 12f);
                r.set(2.5f, 9f, 13f, 15f);
                c.drawRoundRect(r, 3f, 3f, stroke);
                r.set(11f, 9f, 21.5f, 15f);
                c.drawRoundRect(r, 3f, 3f, stroke);
                c.restore();
                break;
            case "settings":
                line(c, 4f, 7f, 20f, 7f);
                line(c, 4f, 17f, 20f, 17f);
                c.drawCircle(9f, 7f, 2.6f, fill);
                c.drawCircle(15f, 17f, 2.6f, fill);
                break;
            case "check":
                poly(c, 5f, 12.5f, 10f, 17.5f, 19f, 7f);
                break;
            case "plus":
                line(c, 12f, 5f, 12f, 19f);
                line(c, 5f, 12f, 19f, 12f);
                break;
            case "minus":
                line(c, 5f, 12f, 19f, 12f);
                break;
            case "video":
                r.set(3f, 5f, 21f, 19f);
                c.drawRoundRect(r, 2.5f, 2.5f, stroke);
                tri(10f, 9f, 15.5f, 12f, 10f, 15f);
                c.drawPath(p, fill);
                break;
            case "playlist":
                line(c, 4f, 6f, 16f, 6f);
                line(c, 4f, 11f, 16f, 11f);
                line(c, 4f, 16f, 11f, 16f);
                tri(14f, 14f, 20f, 17f, 14f, 20f);
                c.drawPath(p, fill);
                break;
            case "sun":
                c.drawCircle(12f, 12f, 4f, fill);
                for (int i = 0; i < 8; i++) {
                    double a = Math.PI / 4 * i;
                    float cx = (float) Math.cos(a), sy = (float) Math.sin(a);
                    line(c, 12f + cx * 7f, 12f + sy * 7f, 12f + cx * 9.2f, 12f + sy * 9.2f);
                }
                break;
            case "volume":
            case "mute": {
                p.reset();
                p.moveTo(4f, 9.5f);
                p.lineTo(8f, 9.5f);
                p.lineTo(13f, 5f);
                p.lineTo(13f, 19f);
                p.lineTo(8f, 14.5f);
                p.lineTo(4f, 14.5f);
                p.close();
                c.drawPath(p, fill);
                if (name.equals("mute")) {
                    line(c, 16f, 9f, 21f, 15f);
                    line(c, 21f, 9f, 16f, 15f);
                } else {
                    r.set(10f, 7.5f, 19f, 16.5f);
                    p.reset();
                    p.addArc(r, -50f, 100f);
                    c.drawPath(p, stroke);
                    r.set(9f, 4f, 22f, 20f);
                    p.reset();
                    p.addArc(r, -50f, 100f);
                    c.drawPath(p, stroke);
                }
                break;
            }
            case "heart":
            case "heartFill": {
                p.reset();
                p.moveTo(12f, 20f);
                p.cubicTo(5f, 15.2f, 2.5f, 12f, 2.5f, 8.6f);
                p.cubicTo(2.5f, 5.8f, 4.7f, 3.8f, 7.3f, 3.8f);
                p.cubicTo(9.2f, 3.8f, 11f, 4.9f, 12f, 6.6f);
                p.cubicTo(13f, 4.9f, 14.8f, 3.8f, 16.7f, 3.8f);
                p.cubicTo(19.3f, 3.8f, 21.5f, 5.8f, 21.5f, 8.6f);
                p.cubicTo(21.5f, 12f, 19f, 15.2f, 12f, 20f);
                p.close();
                c.drawPath(p, name.equals("heartFill") ? fill : stroke);
                break;
            }
            case "shuffle":
                poly(c, 4f, 7f, 8f, 7f, 16f, 17f, 19f, 17f);
                poly(c, 4f, 17f, 8f, 17f, 10.5f, 13.8f);
                poly(c, 13.5f, 10.2f, 16f, 7f, 19f, 7f);
                tri(17.5f, 4f, 21f, 7f, 17.5f, 10f);
                c.drawPath(p, fill);
                tri(17.5f, 14f, 21f, 17f, 17.5f, 20f);
                c.drawPath(p, fill);
                break;
            case "queue":
                line(c, 4f, 6f, 20f, 6f);
                line(c, 4f, 11f, 20f, 11f);
                line(c, 4f, 16f, 12f, 16f);
                c.drawCircle(17.5f, 17.5f, 2.6f, fill);
                line(c, 20f, 17.5f, 20f, 11.5f);
                break;
            case "lyrics":
                r.set(4f, 3.5f, 20f, 20.5f);
                c.drawRoundRect(r, 2.5f, 2.5f, stroke);
                line(c, 8f, 8.5f, 16f, 8.5f);
                line(c, 8f, 12f, 16f, 12f);
                line(c, 8f, 15.5f, 12.5f, 15.5f);
                break;
            case "album":
                c.drawCircle(12f, 12f, 9f, stroke);
                c.drawCircle(12f, 12f, 2.6f, fill);
                break;
            case "artist":
                c.drawCircle(12f, 8f, 4f, stroke);
                p.reset();
                r.set(4.5f, 13.5f, 19.5f, 26f);
                p.addArc(r, 180f, 180f);
                c.drawPath(p, stroke);
                break;
            case "genre":
                p.reset();
                p.moveTo(12f, 3f);
                p.lineTo(21f, 12f);
                p.lineTo(12f, 21f);
                p.lineTo(3f, 12f);
                p.close();
                c.drawPath(p, stroke);
                c.drawCircle(12f, 12f, 2f, fill);
                break;
            case "note":
                p.reset();
                p.moveTo(6.5f, 3.5f);
                p.lineTo(14f, 3.5f);
                p.lineTo(18.5f, 8f);
                p.lineTo(18.5f, 19f);
                p.cubicTo(18.5f, 19.8f, 17.8f, 20.5f, 17f, 20.5f);
                p.lineTo(7f, 20.5f);
                p.cubicTo(6.2f, 20.5f, 5.5f, 19.8f, 5.5f, 19f);
                p.lineTo(5.5f, 5f);
                p.cubicTo(5.5f, 4.2f, 6.2f, 3.5f, 7f, 3.5f);
                p.close();
                c.drawPath(p, stroke);
                poly(c, 13.5f, 3.8f, 13.5f, 8.5f, 18.2f, 8.5f);
                line(c, 8.8f, 13f, 15.2f, 13f);
                line(c, 8.8f, 16.8f, 13f, 16.8f);
                break;
            case "playlistAdd":
                line(c, 4f, 6f, 15f, 6f);
                line(c, 4f, 11f, 15f, 11f);
                line(c, 4f, 16f, 10f, 16f);
                line(c, 17.5f, 12f, 17.5f, 20f);
                line(c, 13.5f, 16f, 21.5f, 16f);
                break;
            case "trash":
                line(c, 4f, 6.5f, 20f, 6.5f);
                poly(c, 9f, 6.5f, 9.5f, 3.5f, 14.5f, 3.5f, 15f, 6.5f);
                poly(c, 6f, 6.5f, 7f, 20.5f, 17f, 20.5f, 18f, 6.5f);
                line(c, 10f, 10f, 10.3f, 17f);
                line(c, 14f, 10f, 13.7f, 17f);
                break;
            case "up":
                poly(c, 6f, 15f, 12f, 9f, 18f, 15f);
                break;
            case "down":
            case "collapse":
                poly(c, 6f, 9f, 12f, 15f, 18f, 9f);
                break;
            case "share":
                c.drawCircle(18f, 5.5f, 2.6f, fill);
                c.drawCircle(6f, 12f, 2.6f, fill);
                c.drawCircle(18f, 18.5f, 2.6f, fill);
                line(c, 8.3f, 10.8f, 15.7f, 6.7f);
                line(c, 8.3f, 13.2f, 15.7f, 17.3f);
                break;
            case "chart":
                line(c, 4f, 20f, 20f, 20f);
                r.set(5.5f, 12f, 8.5f, 18f);
                c.drawRoundRect(r, 1f, 1f, fill);
                r.set(10.5f, 7f, 13.5f, 18f);
                c.drawRoundRect(r, 1f, 1f, fill);
                r.set(15.5f, 4f, 18.5f, 18f);
                c.drawRoundRect(r, 1f, 1f, fill);
                break;
            case "radio":
                c.drawCircle(12f, 13f, 2.4f, fill);
                r.set(6.5f, 7.5f, 17.5f, 18.5f);
                p.reset();
                p.addArc(r, 200f, 140f);
                c.drawPath(p, stroke);
                r.set(2.5f, 3.5f, 21.5f, 22.5f);
                p.reset();
                p.addArc(r, 205f, 130f);
                c.drawPath(p, stroke);
                break;
            case "bars":
                for (int i = 0; i < 5; i++) {
                    float hgt = new float[]{8f, 14f, 18f, 11f, 6f}[i];
                    r.set(3.5f + i * 3.6f, 20f - hgt, 5.9f + i * 3.6f, 20f);
                    c.drawRoundRect(r, 1f, 1f, fill);
                }
                break;
            case "headphones":
                p.reset();
                r.set(4f, 4f, 20f, 20f);
                p.addArc(r, 180f, 180f);
                c.drawPath(p, stroke);
                r.set(3f, 12f, 8f, 20f);
                c.drawRoundRect(r, 2f, 2f, fill);
                r.set(16f, 12f, 21f, 20f);
                c.drawRoundRect(r, 2f, 2f, fill);
                break;
            case "send":
                p.reset();
                p.moveTo(4f, 11.2f);
                p.lineTo(20f, 4f);
                p.lineTo(13.5f, 20f);
                p.lineTo(11f, 13f);
                p.close();
                c.drawPath(p, fill);
                break;
            case "attach":
                // скрепка: вытянутая петля, повёрнутая на 45°, и внутренний ус
                c.save();
                c.rotate(45f, 12f, 12f);
                p.reset();
                p.moveTo(14.5f, 15f);
                p.lineTo(14.5f, 6.5f);
                p.cubicTo(14.5f, 3.2f, 9.5f, 3.2f, 9.5f, 6.5f);
                p.lineTo(9.5f, 17.5f);
                p.cubicTo(9.5f, 21.5f, 16.5f, 21.5f, 16.5f, 17.5f);
                p.lineTo(16.5f, 9f);
                c.drawPath(p, stroke);
                line(c, 12f, 8f, 12f, 16f);
                c.restore();
                break;
            case "mic":
                r.set(9f, 3f, 15f, 14f);
                c.drawRoundRect(r, 3f, 3f, fill);
                p.reset();
                r.set(6f, 6.5f, 18f, 17.5f);
                p.addArc(r, 0f, 180f);
                c.drawPath(p, stroke);
                line(c, 12f, 17.5f, 12f, 21f);
                line(c, 8.5f, 21f, 15.5f, 21f);
                break;
            case "image":
                r.set(3.5f, 5f, 20.5f, 19f);
                c.drawRoundRect(r, 2.5f, 2.5f, stroke);
                c.drawCircle(9f, 10f, 1.6f, fill);
                poly(c, 4.5f, 17.5f, 9.5f, 13f, 12.5f, 15.5f, 15.5f, 12f, 19.5f, 16.5f);
                break;
            case "bluetooth":
                poly(c, 7f, 7.5f, 16.5f, 16f, 12f, 20.5f, 12f, 3.5f, 16.5f, 8f, 7f, 16.5f);
                break;
            case "wifi":
                c.drawCircle(12f, 18.5f, 1.6f, fill);
                for (int i = 0; i < 3; i++) {
                    float rr = 4.5f + i * 4f;
                    r.set(12f - rr, 18.5f - rr, 12f + rr, 18.5f + rr);
                    p.reset();
                    p.addArc(r, 225f, 90f);
                    c.drawPath(p, stroke);
                }
                break;
            case "shield":
                p.reset();
                p.moveTo(12f, 3f);
                p.lineTo(19f, 6f);
                p.cubicTo(19f, 13f, 16f, 18f, 12f, 21f);
                p.cubicTo(8f, 18f, 5f, 13f, 5f, 6f);
                p.close();
                c.drawPath(p, stroke);
                poly(c, 8.8f, 12f, 11.2f, 14.4f, 15.5f, 9.8f);
                break;
            case "user":
                c.drawCircle(12f, 8.5f, 3.8f, stroke);
                p.reset();
                r.set(4.5f, 14f, 19.5f, 28f);
                p.addArc(r, 180f, 180f);
                c.drawPath(p, stroke);
                break;
            case "users":
                c.drawCircle(9f, 8.5f, 3.2f, stroke);
                p.reset();
                r.set(2.8f, 14f, 15.2f, 26f);
                p.addArc(r, 180f, 180f);
                c.drawPath(p, stroke);
                p.reset();
                r.set(13.5f, 5f, 19.5f, 11f);
                p.addArc(r, 270f, 200f);
                c.drawPath(p, stroke);
                p.reset();
                r.set(14f, 14f, 22f, 24f);
                p.addArc(r, 270f, 90f);
                c.drawPath(p, stroke);
                break;
            case "chat":
                p.reset();
                p.moveTo(5f, 5f);
                p.lineTo(19f, 5f);
                p.quadTo(21f, 5f, 21f, 7f);
                p.lineTo(21f, 14.5f);
                p.quadTo(21f, 16.5f, 19f, 16.5f);
                p.lineTo(10f, 16.5f);
                p.lineTo(6f, 20f);
                p.lineTo(6f, 16.5f);
                p.lineTo(5f, 16.5f);
                p.quadTo(3f, 16.5f, 3f, 14.5f);
                p.lineTo(3f, 7f);
                p.quadTo(3f, 5f, 5f, 5f);
                p.close();
                c.drawPath(p, stroke);
                break;
            case "checks":
                poly(c, 2.5f, 12.5f, 6.5f, 16.5f, 14f, 8f);
                poly(c, 10.5f, 15f, 12f, 16.5f, 21f, 7.5f);
                break;
            case "clock":
                c.drawCircle(12f, 12f, 8.5f, stroke);
                poly(c, 12f, 7.5f, 12f, 12f, 15f, 14f);
                break;
            case "reply":
                poly(c, 9.5f, 6f, 4f, 11f, 9.5f, 16f);
                p.reset();
                p.moveTo(4.5f, 11f);
                p.lineTo(13f, 11f);
                p.quadTo(20f, 11f, 20f, 18.5f);
                c.drawPath(p, stroke);
                break;
            case "copy":
                r.set(8f, 8f, 19.5f, 19.5f);
                c.drawRoundRect(r, 2f, 2f, stroke);
                poly(c, 15.5f, 4.5f, 6.5f, 4.5f, 4.5f, 6.5f, 4.5f, 15.5f);
                break;
            case "radar":
                c.drawCircle(12f, 12f, 2f, fill);
                for (int i = 0; i < 2; i++) {
                    float rr = 5.5f + i * 4f;
                    r.set(12f - rr, 12f - rr, 12f + rr, 12f + rr);
                    p.reset();
                    p.addArc(r, 200f, 140f);
                    c.drawPath(p, stroke);
                    p.reset();
                    p.addArc(r, 20f, 140f);
                    c.drawPath(p, stroke);
                }
                break;
            case "hub":
                c.drawCircle(12f, 12f, 2.6f, fill);
                c.drawCircle(5f, 6f, 2f, stroke);
                c.drawCircle(19f, 6f, 2f, stroke);
                c.drawCircle(12f, 20.5f, 2f, stroke);
                line(c, 6.6f, 7.3f, 10f, 10.4f);
                line(c, 17.4f, 7.3f, 14f, 10.4f);
                line(c, 12f, 14.6f, 12f, 18.5f);
                break;
            case "key":
                c.drawCircle(8f, 15f, 4f, stroke);
                poly(c, 10.8f, 12.2f, 19.5f, 3.5f);
                poly(c, 16f, 7f, 18.5f, 9.5f);
                poly(c, 18f, 5f, 20.5f, 7.5f);
                break;
            case "bell":
            case "bellOff":
                p.reset();
                p.moveTo(6f, 17f);
                p.lineTo(6f, 11f);
                p.cubicTo(6f, 7f, 8.5f, 4.5f, 12f, 4.5f);
                p.cubicTo(15.5f, 4.5f, 18f, 7f, 18f, 11f);
                p.lineTo(18f, 17f);
                p.close();
                c.drawPath(p, stroke);
                line(c, 4.5f, 17f, 19.5f, 17f);
                line(c, 10f, 20.5f, 14f, 20.5f);
                if (name.equals("bellOff")) line(c, 4f, 4f, 20f, 20f);
                break;
            case "stop":
                r.set(6.5f, 6.5f, 17.5f, 17.5f);
                c.drawRoundRect(r, 2f, 2f, fill);
                break;
            case "download":
                line(c, 12f, 4f, 12f, 15f);
                poly(c, 7.5f, 10.5f, 12f, 15f, 16.5f, 10.5f);
                line(c, 5f, 19.5f, 19f, 19.5f);
                break;
            case "alert":
            {
                c.drawCircle(12f, 12f, 9f, fill);
                int keep = stroke.getColor();
                stroke.setColor(0xFFFFFFFF); // без invalidateSelf: иначе бесконечная перерисовка
                line(c, 12f, 7f, 12f, 13f);
                c.drawCircle(12f, 16.5f, 1.1f, stroke);
                stroke.setColor(keep);
            }
                break;
            case "edit":
                poly(c, 4.5f, 19.5f, 5.2f, 15.6f, 15.8f, 5f, 19f, 8.2f, 8.4f, 18.8f, 4.5f, 19.5f);
                line(c, 13.6f, 7.2f, 16.8f, 10.4f);
                break;
            case "camera":
                r.set(3f, 7f, 21f, 19f);
                c.drawRoundRect(r, 2.5f, 2.5f, stroke);
                poly(c, 8.5f, 7f, 10f, 4.5f, 14f, 4.5f, 15.5f, 7f);
                c.drawCircle(12f, 13f, 3.4f, stroke);
                break;
            case "tabs":
                r.set(4f, 7f, 17f, 20f);
                c.drawRoundRect(r, 2.5f, 2.5f, stroke);
                poly(c, 7.5f, 4f, 17.5f, 4f, 20f, 6.5f, 20f, 16.5f);
                break;
            case "home":
                poly(c, 3.5f, 11.5f, 12f, 4f, 20.5f, 11.5f);
                poly(c, 6f, 10f, 6f, 20f, 18f, 20f, 18f, 10f);
                r.set(10f, 14f, 14f, 20f);
                c.drawRect(r, stroke);
                break;
            case "refresh":
                r.set(5f, 5f, 19f, 19f);
                p.reset();
                p.addArc(r, -60f, 300f);
                c.drawPath(p, stroke);
                tri(15.2f, 2.6f, 19.6f, 6.4f, 14.3f, 8.6f);
                c.drawPath(p, fill);
                break;
            case "bookmark":
            case "bookmarkFill":
                p.reset();
                p.moveTo(6.5f, 4f);
                p.lineTo(17.5f, 4f);
                p.lineTo(17.5f, 20.5f);
                p.lineTo(12f, 16.5f);
                p.lineTo(6.5f, 20.5f);
                p.close();
                c.drawPath(p, name.equals("bookmarkFill") ? fill : stroke);
                break;
            case "history":
                r.set(4f, 4f, 20f, 20f);
                p.reset();
                p.addArc(r, 200f, 300f);
                c.drawPath(p, stroke);
                tri(2.2f, 8.6f, 6.8f, 8.2f, 4.2f, 12.6f);
                c.drawPath(p, fill);
                poly(c, 12f, 8f, 12f, 12.5f, 15f, 14.5f);
                break;
            case "incognito":
                p.reset();
                p.moveTo(3f, 11.5f);
                p.lineTo(21f, 11.5f);
                c.drawPath(p, stroke);
                p.reset();
                p.moveTo(6f, 11f);
                p.lineTo(8f, 5f);
                p.lineTo(16f, 5f);
                p.lineTo(18f, 11f);
                p.close();
                c.drawPath(p, fill);
                c.drawCircle(8f, 16.5f, 2.6f, stroke);
                c.drawCircle(16f, 16.5f, 2.6f, stroke);
                line(c, 10.6f, 16f, 13.4f, 16f);
                break;
            case "desktop":
                r.set(3f, 4.5f, 21f, 16f);
                c.drawRoundRect(r, 1.5f, 1.5f, stroke);
                line(c, 12f, 16f, 12f, 19.5f);
                line(c, 8f, 19.5f, 16f, 19.5f);
                break;
            case "moon":
                p.reset();
                p.moveTo(15.5f, 3.5f);
                p.cubicTo(8.5f, 3.5f, 4f, 8f, 4f, 13f);
                p.cubicTo(4f, 18f, 8f, 21f, 12.5f, 21f);
                p.cubicTo(16.5f, 21f, 19.5f, 18.5f, 20.5f, 15.5f);
                p.cubicTo(14f, 17f, 10f, 10f, 15.5f, 3.5f);
                p.close();
                c.drawPath(p, stroke);
                break;
            case "globe":
                c.drawCircle(12f, 12f, 8.5f, stroke);
                line(c, 3.5f, 12f, 20.5f, 12f);
                r.set(8f, 3.5f, 16f, 20.5f);
                c.drawOval(r, stroke);
                break;
            case "translate":
                poly(c, 3.5f, 6f, 12.5f, 6f);
                line(c, 8f, 4f, 8f, 6f);
                p.reset();
                p.moveTo(10.5f, 6f);
                p.cubicTo(9.5f, 10f, 7f, 13f, 4f, 14.5f);
                c.drawPath(p, stroke);
                p.reset();
                p.moveTo(6f, 9f);
                p.cubicTo(7.5f, 11.5f, 9.5f, 13f, 11.5f, 14f);
                c.drawPath(p, stroke);
                poly(c, 12.5f, 20.5f, 16.5f, 10.5f, 20.5f, 20.5f);
                line(c, 14f, 17.5f, 19f, 17.5f);
                break;
            case "print":
                r.set(3.5f, 9f, 20.5f, 17f);
                c.drawRoundRect(r, 2f, 2f, stroke);
                poly(c, 7f, 9f, 7f, 4f, 17f, 4f, 17f, 9f);
                r.set(7f, 14f, 17f, 20.5f);
                c.drawRect(r, stroke);
                break;
            case "chevronRight":
                poly(c, 9f, 5.5f, 15.5f, 12f, 9f, 18.5f);
                break;
            case "fill":
                line(c, 7f, 7f, 18f, 18f);
                poly(c, 7f, 15f, 7f, 7f, 15f, 7f);
                break;
            case "noImage":
                r.set(3.5f, 5f, 20.5f, 19f);
                c.drawRoundRect(r, 2.5f, 2.5f, stroke);
                poly(c, 4.5f, 17.5f, 9.5f, 13f, 12.5f, 15.5f, 15.5f, 12f, 19.5f, 16.5f);
                line(c, 3f, 3f, 21f, 21f);
                break;
            case "addHome":
                r.set(4f, 4f, 20f, 20f);
                c.drawRoundRect(r, 4f, 4f, stroke);
                line(c, 12f, 8.5f, 12f, 15.5f);
                line(c, 8.5f, 12f, 15.5f, 12f);
                break;
            case "text":
                poly(c, 3f, 19f, 8f, 6f, 13f, 19f);
                line(c, 4.8f, 14.5f, 11.2f, 14.5f);
                poly(c, 14f, 19f, 17.5f, 10f, 21f, 19f);
                line(c, 15.2f, 16f, 19.8f, 16f);
                break;
            // ---------------------------------------------------------- заметки
            case "menu":
                line(c, 4f, 7f, 20f, 7f);
                line(c, 4f, 12f, 20f, 12f);
                line(c, 4f, 17f, 20f, 17f);
                break;
            case "grid":
                r.set(4f, 4f, 11f, 11f);
                c.drawRoundRect(r, 2f, 2f, stroke);
                r.set(13f, 4f, 20f, 11f);
                c.drawRoundRect(r, 2f, 2f, stroke);
                r.set(4f, 13f, 11f, 20f);
                c.drawRoundRect(r, 2f, 2f, stroke);
                r.set(13f, 13f, 20f, 20f);
                c.drawRoundRect(r, 2f, 2f, stroke);
                break;
            case "list":
                r.set(4f, 5f, 20f, 10.5f);
                c.drawRoundRect(r, 2f, 2f, stroke);
                r.set(4f, 13.5f, 20f, 19f);
                c.drawRoundRect(r, 2f, 2f, stroke);
                break;
            case "pin":
            case "pinFill": {
                p.reset();
                p.moveTo(9.5f, 3.5f);
                p.lineTo(14.5f, 3.5f);
                p.lineTo(14.5f, 9f);
                p.lineTo(18f, 13.5f);
                p.lineTo(6f, 13.5f);
                p.lineTo(9.5f, 9f);
                p.close();
                c.drawPath(p, name.equals("pinFill") ? fill : stroke);
                line(c, 12f, 13.5f, 12f, 20.5f);
                break;
            }
            case "palette":
                c.drawCircle(12f, 12f, 8.5f, stroke);
                c.drawCircle(8.3f, 9.6f, 1.5f, fill);
                c.drawCircle(12f, 7.4f, 1.5f, fill);
                c.drawCircle(15.7f, 9.6f, 1.5f, fill);
                c.drawCircle(16.2f, 13.8f, 1.5f, fill);
                c.drawCircle(10f, 15.8f, 2f, stroke);
                break;
            case "archive":
            case "unarchive":
                r.set(3.5f, 4f, 20.5f, 8.5f);
                c.drawRoundRect(r, 1.5f, 1.5f, stroke);
                poly(c, 5f, 8.5f, 5f, 19.5f, 19f, 19.5f, 19f, 8.5f);
                if (name.equals("archive")) line(c, 10f, 12.5f, 14f, 12.5f);
                else {
                    line(c, 12f, 17.5f, 12f, 11f);
                    poly(c, 9.2f, 13.6f, 12f, 10.8f, 14.8f, 13.6f);
                }
                break;
            case "tag":
                p.reset();
                p.moveTo(3.5f, 4.5f);
                p.lineTo(11f, 3.5f);
                p.lineTo(20.5f, 13f);
                p.lineTo(13f, 20.5f);
                p.lineTo(3.5f, 11f);
                p.close();
                c.drawPath(p, stroke);
                c.drawCircle(8f, 8f, 1.6f, fill);
                break;
            case "eye":
                p.reset();
                p.moveTo(2.5f, 12f);
                p.quadTo(12f, 2.5f, 21.5f, 12f);
                p.quadTo(12f, 21.5f, 2.5f, 12f);
                p.close();
                c.drawPath(p, stroke);
                c.drawCircle(12f, 12f, 3f, stroke);
                c.drawCircle(12f, 12f, 1.1f, fill);
                break;
            case "undo":
            case "redo": {
                boolean u = name.equals("undo");
                c.save();
                if (!u) {
                    c.translate(24f, 0f);
                    c.scale(-1f, 1f);
                }
                p.reset();
                p.moveTo(8f, 9f);
                p.lineTo(14.5f, 9f);
                p.cubicTo(18f, 9f, 20f, 11.3f, 20f, 14f);
                p.cubicTo(20f, 16.7f, 18f, 19f, 14.5f, 19f);
                p.lineTo(9f, 19f);
                c.drawPath(p, stroke);
                poly(c, 11.5f, 5.5f, 8f, 9f, 11.5f, 12.5f);
                c.restore();
                break;
            }
            case "restore":
                arcArrow(c, false);
                line(c, 12f, 13f, 12f, 9.6f);
                line(c, 12f, 13f, 14.6f, 14.6f);
                break;
            case "backspace":
                p.reset();
                p.moveTo(8.5f, 5.5f);
                p.lineTo(20.5f, 5.5f);
                p.lineTo(20.5f, 18.5f);
                p.lineTo(8.5f, 18.5f);
                p.lineTo(3f, 12f);
                p.close();
                c.drawPath(p, stroke);
                line(c, 11.5f, 9.5f, 16.5f, 14.5f);
                line(c, 16.5f, 9.5f, 11.5f, 14.5f);
                break;
            case "checkbox":
                r.set(4f, 4f, 20f, 20f);
                c.drawRoundRect(r, 4f, 4f, stroke);
                poly(c, 8f, 12.2f, 10.8f, 15f, 16.2f, 9.2f);
                break;
            case "listBullet":
                c.drawCircle(5f, 7f, 1.5f, fill);
                c.drawCircle(5f, 12f, 1.5f, fill);
                c.drawCircle(5f, 17f, 1.5f, fill);
                line(c, 9.5f, 7f, 20f, 7f);
                line(c, 9.5f, 12f, 20f, 12f);
                line(c, 9.5f, 17f, 20f, 17f);
                break;
            case "listNumber":
                text.setTextSize(6.5f);
                c.drawText("1", 5f, 9.3f, text);
                c.drawText("2", 5f, 14.3f, text);
                c.drawText("3", 5f, 19.3f, text);
                line(c, 9.5f, 7f, 20f, 7f);
                line(c, 9.5f, 12f, 20f, 12f);
                line(c, 9.5f, 17f, 20f, 17f);
                break;
            case "indent":
            case "outdent":
                line(c, 4f, 5f, 20f, 5f);
                line(c, 11f, 10f, 20f, 10f);
                line(c, 11f, 14f, 20f, 14f);
                line(c, 4f, 19f, 20f, 19f);
                if (name.equals("indent")) tri(4f, 9f, 7.5f, 12f, 4f, 15f);
                else tri(7.5f, 9f, 4f, 12f, 7.5f, 15f);
                c.drawPath(p, fill);
                break;
            case "heading":
                line(c, 5f, 5f, 5f, 19f);
                line(c, 14f, 5f, 14f, 19f);
                line(c, 5f, 12f, 14f, 12f);
                text.setTextSize(8f);
                c.drawText("1", 19f, 19f, text);
                break;
            case "bold":
                stroke.setStrokeWidth(2.6f);
                p.reset();
                p.moveTo(7.5f, 5f);
                p.lineTo(13f, 5f);
                p.cubicTo(17.5f, 5f, 17.5f, 11.5f, 13f, 11.5f);
                p.lineTo(7.5f, 11.5f);
                p.close();
                p.moveTo(7.5f, 11.5f);
                p.lineTo(14f, 11.5f);
                p.cubicTo(18.8f, 11.5f, 18.8f, 19f, 14f, 19f);
                p.lineTo(7.5f, 19f);
                p.close();
                c.drawPath(p, stroke);
                stroke.setStrokeWidth(2f);
                break;
            case "italic":
                line(c, 14f, 5f, 10f, 19f);
                line(c, 10.5f, 5f, 17.5f, 5f);
                line(c, 6.5f, 19f, 13.5f, 19f);
                break;
            case "strike":
                p.reset();
                p.moveTo(16.5f, 7.2f);
                p.cubicTo(15.6f, 5.6f, 14f, 5f, 12f, 5f);
                p.cubicTo(9.2f, 5f, 7.5f, 6.5f, 7.5f, 8.4f);
                p.cubicTo(7.5f, 10.3f, 9f, 11.2f, 12f, 12f);
                p.moveTo(14.6f, 13f);
                p.cubicTo(16f, 13.8f, 16.6f, 14.6f, 16.6f, 15.7f);
                p.cubicTo(16.6f, 17.8f, 14.6f, 19f, 12f, 19f);
                p.cubicTo(9.8f, 19f, 8f, 18.2f, 7.2f, 16.6f);
                c.drawPath(p, stroke);
                line(c, 4f, 12.5f, 20f, 12.5f);
                break;
            case "marker":
                p.reset();
                p.moveTo(14.5f, 3.5f);
                p.lineTo(20.5f, 9.5f);
                p.lineTo(12f, 18f);
                p.lineTo(6f, 12f);
                p.close();
                c.drawPath(p, stroke);
                poly(c, 6f, 12f, 4f, 17.5f, 6.5f, 20f, 12f, 18f);
                line(c, 13.5f, 21f, 21f, 21f);
                break;
            case "code":
                poly(c, 8f, 7f, 3.5f, 12f, 8f, 17f);
                poly(c, 16f, 7f, 20.5f, 12f, 16f, 17f);
                line(c, 13.6f, 5f, 10.4f, 19f);
                break;
            case "quote":
                c.drawCircle(8f, 10f, 2.6f, fill);
                c.drawCircle(16f, 10f, 2.6f, fill);
                p.reset();
                p.moveTo(10.5f, 10.2f);
                p.quadTo(10.6f, 15.5f, 6f, 17.5f);
                p.moveTo(18.5f, 10.2f);
                p.quadTo(18.6f, 15.5f, 14f, 17.5f);
                c.drawPath(p, stroke);
                break;
            case "divider":
                line(c, 3f, 12f, 21f, 12f);
                stroke.setStrokeWidth(1.4f);
                line(c, 7f, 6.5f, 17f, 6.5f);
                line(c, 7f, 17.5f, 17f, 17.5f);
                stroke.setStrokeWidth(2f);
                break;
            case "pen":
                p.reset();
                p.moveTo(4f, 20f);
                p.lineTo(5.2f, 15.2f);
                p.lineTo(15.6f, 4.8f);
                p.lineTo(19.2f, 8.4f);
                p.lineTo(8.8f, 18.8f);
                p.close();
                c.drawPath(p, stroke);
                line(c, 13.4f, 7f, 17f, 10.6f);
                break;
            case "brush":
                line(c, 20f, 4f, 12.5f, 11.5f);
                p.reset();
                p.moveTo(12.5f, 11.5f);
                p.cubicTo(9.8f, 10.5f, 7.2f, 12.3f, 7.2f, 15f);
                p.cubicTo(7.2f, 16.8f, 6f, 18.4f, 3.8f, 19.4f);
                p.cubicTo(7.5f, 20.6f, 11.6f, 19.6f, 13f, 16.8f);
                p.cubicTo(13.8f, 15.2f, 13.6f, 12.9f, 12.5f, 11.5f);
                p.close();
                c.drawPath(p, fill);
                break;
            case "eraser":
                p.reset();
                p.moveTo(3.5f, 14.5f);
                p.lineTo(13.5f, 4.5f);
                p.lineTo(20f, 11f);
                p.lineTo(10.5f, 20.5f);
                p.lineTo(6.5f, 20.5f);
                p.close();
                c.drawPath(p, stroke);
                line(c, 8f, 10f, 14.5f, 16.5f);
                line(c, 10.5f, 20.5f, 20.5f, 20.5f);
                break;
            case "fingerprint":
                r.set(5f, 4f, 19f, 18f);
                p.reset();
                p.addArc(r, 200f, 140f);
                c.drawPath(p, stroke);
                r.set(8f, 7.5f, 16f, 15.5f);
                p.reset();
                p.addArc(r, 180f, 180f);
                c.drawPath(p, stroke);
                poly(c, 8f, 11.5f, 8f, 15f, 9.5f, 19f);
                poly(c, 16f, 11.5f, 16f, 15.5f, 14.8f, 20f);
                line(c, 12f, 11f, 12f, 20.5f);
                break;
            case "cast":
            default:
                c.drawCircle(12f, 12f, 3f, fill);
                break;
        }
    }

    @Override
    public void setAlpha(int alpha) {
        stroke.setAlpha(alpha);
        fill.setAlpha(alpha);
        text.setAlpha(alpha);
        invalidateSelf();
    }

    @Override
    public void setColorFilter(ColorFilter cf) {
        stroke.setColorFilter(cf);
        fill.setColorFilter(cf);
        text.setColorFilter(cf);
        invalidateSelf();
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }
}
