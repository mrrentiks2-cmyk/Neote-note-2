package com.neondrift.notes;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;

/** Рисование пальцем или стилусом: перо, маркер, ластик, цвета, отмена. */
public class SketchActivity extends Base {
    static final int[] COLORS = {0xFFF2EEFF, 0xFFFF2D95, 0xFF00E5FF, 0xFF8CFF5A, 0xFFFFD447, 0xFFFF8A3D, 0xFF9D6BFF, 0xFFFF4F4F, 0xFF5C8DFF, 0xFF16131F};
    static final int DARK = 0xFF15111F, PAPER = 0xFFF4F1EA;
    static final int PEN = 0, MARKER = 1, ERASER = 2;

    private SketchView canvas;
    private LinearLayout tools, colorsRow;
    private final ImageView[] toolButtons = new ImageView[3];
    private int tool = PEN, color = COLORS[1];
    private float size = 4f;
    private TextView sizeLabel;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        Bitmap base = null;
        String path = getIntent().getStringExtra("base");
        if (path != null) base = BitmapFactory.decodeFile(path);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Theme.BG);
        LinearLayout page = ui.col();
        LinearLayout top = ui.row();
        top.setPadding(ui.dp(4), ui.dp(8), ui.dp(8), ui.dp(4));
        top.addView(ui.iconButton("back", Theme.TEXT, 46, 12, v -> onBackPressed()));
        top.addView(ui.text("Рисунок", 19, Theme.TEXT, true), Ui.lp(0, Ui.WRAP, 1f));
        top.addView(ui.iconButton("undo", Theme.TEXT, 44, 11, v -> canvas.undo()));
        top.addView(ui.iconButton("redo", Theme.TEXT, 44, 11, v -> canvas.redo()));
        top.addView(ui.iconButton("more", Theme.TEXT, 44, 11, v -> more()));
        TextView done = ui.button("Готово", true, v -> finishSave());
        done.setPadding(ui.dp(16), ui.dp(9), ui.dp(16), ui.dp(9));
        top.addView(done, Ui.margins(Ui.WRAP, Ui.WRAP, ui.dp(6), 0, 0, 0));
        page.addView(top);

        canvas = new SketchView(this, base);
        page.addView(canvas, Ui.margins(Ui.MATCH, 0, ui.dp(10), ui.dp(4), ui.dp(10), ui.dp(8)));
        ((LinearLayout.LayoutParams) canvas.getLayoutParams()).weight = 1f;

        tools = ui.col();
        tools.setPadding(ui.dp(12), ui.dp(6), ui.dp(12), ui.dp(12));
        LinearLayout tr = ui.row();
        String[] icons = {"pen", "marker", "eraser"};
        String[] names = {"Перо", "Маркер", "Ластик"};
        for (int i = 0; i < 3; i++) {
            int t = i;
            ImageView b = ui.iconButton(icons[i], Theme.TEXT, 48, 12, v -> setTool(t));
            b.setContentDescription(names[i]);
            toolButtons[i] = b;
            tr.addView(b, Ui.margins(ui.dp(48), ui.dp(48), 0, 0, ui.dp(6), 0));
        }
        tr.addView(new View(this), Ui.lp(0, 1, 1f));
        tr.addView(roundBtn("minus", () -> setSize(size - 1)));
        sizeLabel = ui.text("", 14, Theme.TEXT, true);
        sizeLabel.setGravity(Gravity.CENTER);
        tr.addView(sizeLabel, Ui.lp(ui.dp(44), Ui.WRAP));
        tr.addView(roundBtn("plus", () -> setSize(size + 1)));
        tools.addView(tr);
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        colorsRow = ui.row();
        colorsRow.setPadding(0, ui.dp(10), 0, 0);
        hs.addView(colorsRow);
        tools.addView(hs);
        page.addView(tools);
        root.addView(page, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        setContentView(root);
        if (base != null) canvas.background = base.getPixel(0, 0) | 0xFF000000;
        setTool(PEN);
        setSize(4);
        drawColors();
    }

    private View roundBtn(String icon, Runnable r) {
        ImageView b = ui.iconButton(icon, Theme.TEXT, 40, 11, v -> r.run());
        b.setBackground(Ui.ripple(Ui.oval(Theme.SURFACE2), Ui.oval(0xFFFFFFFF)));
        return b;
    }

    private void setTool(int t) {
        tool = t;
        for (int i = 0; i < 3; i++) {
            toolButtons[i].setBackground(Ui.ripple(Ui.round(i == t ? Theme.alpha(Theme.ACCENT, 60) : 0, ui.dp(14)), Ui.round(0xFFFFFFFF, ui.dp(14))));
            ((Glyph) toolButtons[i].getDrawable()).setColor(i == t ? Theme.ACCENT : Theme.TEXT);
        }
        if (t == MARKER && size < 10) setSize(14);
        else if (t == PEN && size > 12) setSize(4);
        else if (t == ERASER && size < 12) setSize(24);
    }

    private void setSize(float s) {
        size = Math.max(1, Math.min(60, s));
        sizeLabel.setText(String.valueOf(Math.round(size)));
    }

    private void drawColors() {
        colorsRow.removeAllViews();
        for (int c : COLORS) {
            View dot = new View(this);
            boolean on = c == color;
            dot.setBackground(Ui.stroke(c, on ? Theme.TEXT : Theme.LINE, ui.dp(on ? 3 : 1), ui.dp(30)));
            dot.setOnClickListener(v -> {
                color = c;
                if (tool == ERASER) setTool(PEN);
                drawColors();
            });
            colorsRow.addView(dot, Ui.margins(ui.dp(36), ui.dp(36), 0, 0, ui.dp(10), 0));
        }
    }

    private void more() {
        String[] items = {"Тёмный фон", "Светлый фон", "Очистить всё"};
        dialog().setItems(items, (d, w) -> {
            if (w == 0) canvas.setBackgroundTone(DARK);
            else if (w == 1) canvas.setBackgroundTone(PAPER);
            else confirm("Очистить рисунок?", "Это можно отменить кнопкой «Назад».", "Очистить", canvas::clearAll);
        }).show();
    }

    @Override
    public void onBackPressed() {
        if (canvas.isEmpty() && !canvas.edited()) {
            setResult(RESULT_CANCELED);
            finish();
        } else finishSave();
    }

    private void finishSave() {
        if (!canvas.edited()) {
            setResult(RESULT_CANCELED);
            finish();
            return;
        }
        try {
            Bitmap b = canvas.export();
            File f = new File(getCacheDir(), "sketch_" + System.currentTimeMillis() + ".png");
            try (FileOutputStream out = new FileOutputStream(f)) {
                b.compress(Bitmap.CompressFormat.PNG, 100, out);
            }
            setResult(RESULT_OK, new Intent().putExtra("path", f.getPath()));
        } catch (Exception | OutOfMemoryError e) {
            toast("Не удалось сохранить рисунок");
            setResult(RESULT_CANCELED);
        }
        finish();
    }

    /** Холст. Штрихи хранятся в координатах документа, поэтому рисунок не искажается при повороте экрана. */
    final class SketchView extends View {
        final class Stroke {
            final Path path = new Path();
            final int color, tool;
            final float width;

            Stroke(int color, int tool, float width) {
                this.color = color;
                this.tool = tool;
                this.width = width;
            }
        }

        private final Bitmap base;
        private final ArrayList<Stroke> strokes = new ArrayList<>(), redo = new ArrayList<>();
        private Stroke current;
        private Bitmap layer;
        private Canvas layerCanvas;
        private int docW, docH;
        private float scale = 1, offX, offY, lastX, lastY;
        int background = DARK;
        private boolean cleared, toneChanged;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
        private final Paint bmp = new Paint(Paint.FILTER_BITMAP_FLAG);
        private final Matrix m = new Matrix();

        SketchView(Context c, Bitmap base) {
            super(c);
            this.base = base;
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            setClipToOutline(true);
            setOutlineProvider(Ui.rounded(ui.dp(18)));
        }

        boolean isEmpty() {
            return strokes.isEmpty() && base == null;
        }

        boolean edited() {
            return !strokes.isEmpty() || cleared || toneChanged;
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            if (w <= 0 || h <= 0) return;
            if (docW == 0) {
                if (base != null) {
                    docW = base.getWidth();
                    docH = base.getHeight();
                } else {
                    float k = Math.min(1f, 2048f / Math.max(w, h));
                    docW = Math.round(w * k);
                    docH = Math.round(h * k);
                }
                layer = Bitmap.createBitmap(docW, docH, Bitmap.Config.ARGB_8888);
                layerCanvas = new Canvas(layer);
                rebuild();
            }
            scale = Math.min(w / (float) docW, h / (float) docH);
            offX = (w - docW * scale) / 2f;
            offY = (h - docH * scale) / 2f;
        }

        void setBackgroundTone(int c) {
            background = c;
            toneChanged = true;
            rebuild();
        }

        void clearAll() {
            strokes.clear();
            redo.clear();
            cleared = true;
            rebuild();
        }

        void undo() {
            if (strokes.isEmpty()) return;
            redo.add(strokes.remove(strokes.size() - 1));
            rebuild();
        }

        void redo() {
            if (redo.isEmpty()) return;
            strokes.add(redo.remove(redo.size() - 1));
            rebuild();
        }

        /** Перерисовать слой: фон, основа (при дорисовке) и все штрихи. */
        private void rebuild() {
            if (layerCanvas == null) return;
            layerCanvas.drawColor(background);
            if (base != null && !cleared) layerCanvas.drawBitmap(base, 0, 0, bmp);
            for (Stroke s : strokes) drawStroke(layerCanvas, s);
            invalidate();
        }

        private void drawStroke(Canvas c, Stroke s) {
            paint.setColor(s.tool == ERASER ? background : s.color);
            if (s.tool == MARKER) paint.setAlpha(110);
            paint.setStrokeWidth(s.width);
            paint.setStrokeCap(s.tool == MARKER ? Paint.Cap.SQUARE : Paint.Cap.ROUND);
            c.drawPath(s.path, paint);
        }

        @Override
        protected void onDraw(Canvas c) {
            c.drawColor(Theme.mix(background, 0xFF000000, 0.35f));
            if (layer == null) return;
            m.reset();
            m.postScale(scale, scale);
            m.postTranslate(offX, offY);
            c.drawBitmap(layer, m, bmp);
            if (current != null) {
                c.save();
                c.concat(m);
                c.clipRect(new RectF(0, 0, docW, docH));
                drawStroke(c, current);
                c.restore();
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (layer == null) return false;
            float x = (e.getX() - offX) / scale, y = (e.getY() - offY) / scale;
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    getParent().requestDisallowInterceptTouchEvent(true);
                    float w = size * ui.density / scale * (tool == ERASER ? 1.5f : 1f);
                    current = new Stroke(color, tool, w);
                    current.path.moveTo(x, y);
                    current.path.lineTo(x + 0.1f, y + 0.1f);
                    lastX = x;
                    lastY = y;
                    invalidate();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (current == null) return true;
                    for (int i = 0; i < e.getHistorySize(); i++) {
                        float hx = (e.getHistoricalX(i) - offX) / scale, hy = (e.getHistoricalY(i) - offY) / scale;
                        quad(hx, hy);
                    }
                    quad(x, y);
                    invalidate();
                    return true;
                case MotionEvent.ACTION_UP:
                    if (current != null) {
                        current.path.lineTo(x, y);
                        strokes.add(current);
                        redo.clear();
                        drawStroke(layerCanvas, current);
                        current = null;
                        invalidate();
                    }
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    current = null;
                    invalidate();
                    return true;
                default:
                    return true;
            }
        }

        private void quad(float x, float y) {
            current.path.quadTo(lastX, lastY, (x + lastX) / 2, (y + lastY) / 2);
            lastX = x;
            lastY = y;
        }

        Bitmap export() {
            return layer.copy(Bitmap.Config.ARGB_8888, false);
        }
    }
}
