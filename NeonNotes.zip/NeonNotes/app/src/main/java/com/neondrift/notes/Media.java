package com.neondrift.notes;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Файлы вложений: импорт картинок, миниатюры, шифрование для сейфа. */
final class Media {
    private Media() {}

    static final ExecutorService IO = Executors.newFixedThreadPool(2);
    static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final LruCache<String, Bitmap> THUMBS = new LruCache<String, Bitmap>(
            (int) Math.min(Runtime.getRuntime().maxMemory() / 8, 48L * 1024 * 1024)) {
        @Override
        protected int sizeOf(String k, Bitmap b) {
            return b.getByteCount();
        }
    };

    static File dir(Context c) {
        File d = new File(c.getFilesDir(), "att");
        if (!d.isDirectory()) d.mkdirs();
        return d;
    }

    static File openDir(Context c) {
        File d = new File(c.getCacheDir(), "open");
        if (!d.isDirectory()) d.mkdirs();
        return d;
    }

    static File file(Context c, Store.Att a) {
        return new File(dir(c), a.file);
    }

    static String newName(String ext) {
        return UUID.randomUUID().toString().replace("-", "").substring(0, 20) + ext;
    }

    /**
     * Файл, который можно читать как есть. Для вложений сейфа — расшифрованная копия во временной папке
     * (стирается, когда сейф закрывается). null — сейф закрыт или файл повреждён.
     */
    static File plain(Context c, Store.Att a) {
        if (!a.sealed()) return file(c, a);
        File out = new File(openDir(c), a.file.substring(0, a.file.length() - 3));
        if (out.isFile() && out.length() > 0) return out;
        byte[] k = Lock.key();
        if (k == null) return null;
        File tmp = new File(out.getPath() + ".part");
        try (InputStream in = new FileInputStream(file(c, a)); OutputStream os = new FileOutputStream(tmp)) {
            if (!Vault.openStream(k, in, os)) {
                tmp.delete();
                return null;
            }
        } catch (IOException e) {
            tmp.delete();
            return null;
        }
        return tmp.renameTo(out) ? out : null;
    }

    static void deleteFile(Context c, Store.Att a) {
        if (a.file == null) return;
        file(c, a).delete();
        if (a.sealed()) new File(openDir(c), a.file.substring(0, a.file.length() - 3)).delete();
        forget(a);
    }

    static void forget(Store.Att a) {
        synchronized (THUMBS) {
            for (String k : THUMBS.snapshot().keySet()) if (k.startsWith(a.file + "@")) THUMBS.remove(k);
        }
    }

    static String copyFile(Context c, Store.Att a) {
        String ext = a.file.contains(".") ? a.file.substring(a.file.indexOf('.')) : "";
        String name = newName(ext);
        try (InputStream in = new FileInputStream(file(c, a)); OutputStream out = new FileOutputStream(new File(dir(c), name))) {
            copy(in, out);
            return name;
        } catch (IOException e) {
            return null;
        }
    }

    static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[64 * 1024];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
    }

    // ================================================================== сейф

    /** Зашифровать файл вложения (заметка уходит в сейф). Меняет a.file — запись в базе обновляет вызывающий. */
    static boolean seal(Context c, Store.Att a, byte[] key) {
        if (a.sealed()) return true;
        File src = file(c, a);
        String name = a.file + ".nv";
        File dst = new File(dir(c), name);
        try (InputStream in = new FileInputStream(src); OutputStream out = new FileOutputStream(dst)) {
            Vault.sealStream(key, in, out);
        } catch (IOException e) {
            dst.delete();
            return false;
        }
        src.delete();
        forget(a);
        a.file = name;
        return true;
    }

    /** Расшифровать файл обратно (заметка уходит из сейфа). */
    static boolean unseal(Context c, Store.Att a, byte[] key) {
        if (!a.sealed()) return true;
        File src = file(c, a);
        String name = a.file.substring(0, a.file.length() - 3);
        File dst = new File(dir(c), name);
        try (InputStream in = new FileInputStream(src); OutputStream out = new FileOutputStream(dst)) {
            if (!Vault.openStream(key, in, out)) throw new IOException("bad key");
        } catch (IOException e) {
            dst.delete();
            return false;
        }
        src.delete();
        new File(openDir(c), name).delete();
        a.file = name;
        return true;
    }

    /** Перешифровать файл новым ключом (смена PIN). */
    static boolean reseal(Context c, Store.Att a, byte[] oldKey, byte[] newKey) {
        if (!a.sealed()) return true;
        File src = file(c, a), tmp = new File(dir(c), a.file + ".tmp");
        ByteArrayOutputStream plain = new ByteArrayOutputStream();
        try (InputStream in = new FileInputStream(src)) {
            if (!Vault.openStream(oldKey, in, plain)) return false;
        } catch (IOException e) {
            return false;
        }
        try (OutputStream out = new FileOutputStream(tmp)) {
            Vault.sealStream(newKey, new ByteArrayInputStream(plain.toByteArray()), out);
        } catch (IOException e) {
            tmp.delete();
            return false;
        }
        return tmp.renameTo(src);
    }

    /** Записать готовые байты как вложение; при key != null — сразу зашифрованным. */
    static String write(Context c, InputStream in, String ext, byte[] key) throws IOException {
        String name = newName(ext) + (key != null ? ".nv" : "");
        File f = new File(dir(c), name);
        try (OutputStream out = new FileOutputStream(f)) {
            if (key != null) Vault.sealStream(key, in, out);
            else copy(in, out);
        } catch (IOException e) {
            f.delete();
            throw e;
        }
        return name;
    }

    // ================================================================== картинки

    /** Импорт картинки: уменьшить до 2048 px по длинной стороне, повернуть по EXIF, сохранить JPEG. */
    static Store.Att importImage(Context c, Uri uri, byte[] key) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = c.getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(in, null, o);
            }
            if (o.outWidth <= 0 || o.outHeight <= 0) return null;
            int rot = 0;
            try (InputStream in = c.getContentResolver().openInputStream(uri)) {
                if (in != null) rot = rotation(new ExifInterface(in).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL));
            } catch (Exception ignored) {
            }
            BitmapFactory.Options d = new BitmapFactory.Options();
            d.inSampleSize = sample(o.outWidth, o.outHeight, 2048, 2048);
            Bitmap b;
            try (InputStream in = c.getContentResolver().openInputStream(uri)) {
                b = BitmapFactory.decodeStream(in, null, d);
            }
            if (b == null) return null;
            float scale = Math.min(1f, 2048f / Math.max(b.getWidth(), b.getHeight()));
            if (scale < 1f || rot != 0) {
                Matrix m = new Matrix();
                m.postScale(scale, scale);
                m.postRotate(rot);
                Bitmap r = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
                if (r != b) b.recycle();
                b = r;
            }
            return saveBitmap(c, b, Store.IMAGE, key);
        } catch (IOException | SecurityException | OutOfMemoryError e) {
            return null;
        }
    }

    static Store.Att saveBitmap(Context c, Bitmap b, int kind, byte[] key) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        boolean png = kind == Store.DRAWING;
        b.compress(png ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG, png ? 100 : 88, bos);
        Store.Att a = new Store.Att();
        a.kind = kind;
        a.w = b.getWidth();
        a.h = b.getHeight();
        a.file = write(c, new ByteArrayInputStream(bos.toByteArray()), png ? ".png" : ".jpg", key);
        a.created = System.currentTimeMillis();
        return a;
    }

    static int rotation(int exif) {
        switch (exif) {
            case ExifInterface.ORIENTATION_ROTATE_90: return 90;
            case ExifInterface.ORIENTATION_ROTATE_180: return 180;
            case ExifInterface.ORIENTATION_ROTATE_270: return 270;
            default: return 0;
        }
    }

    static int sample(int w, int h, int maxW, int maxH) {
        int s = 1;
        while (w / (s * 2) >= maxW || h / (s * 2) >= maxH) s *= 2;
        return s;
    }

    static Bitmap decode(File f, int maxW, int maxH) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getPath(), o);
            if (o.outWidth <= 0) return null;
            BitmapFactory.Options d = new BitmapFactory.Options();
            d.inSampleSize = sample(o.outWidth, o.outHeight, maxW, maxH);
            return BitmapFactory.decodeFile(f.getPath(), d);
        } catch (OutOfMemoryError e) {
            return null;
        }
    }

    /** Миниатюра в ImageView без подвисаний: декодирование в фоне, кэш в памяти. */
    static void thumb(Context c, Store.Att a, int width, ImageView into) {
        String key = a.file + "@" + width;
        into.setTag(key);
        Bitmap cached = THUMBS.get(key);
        if (cached != null) {
            into.setImageBitmap(cached);
            return;
        }
        into.setImageDrawable(null);
        Context app = c.getApplicationContext();
        IO.execute(() -> {
            File f = plain(app, a);
            Bitmap b = f == null ? null : decode(f, width, width * 3);
            if (b != null && b.getWidth() > width * 1.5f) {
                Bitmap s = Bitmap.createScaledBitmap(b, width, Math.max(1, Math.round(b.getHeight() * (width / (float) b.getWidth()))), true);
                if (s != b) b.recycle();
                b = s;
            }
            if (b != null) THUMBS.put(key, b);
            Bitmap res = b;
            MAIN.post(() -> {
                if (key.equals(into.getTag()) && res != null) {
                    into.setImageBitmap(res);
                    into.setAlpha(0f);
                    into.animate().alpha(1f).setDuration(150).start();
                }
            });
        });
    }

    /** Миниатюра для карточки списка: известно только имя файла. */
    static void thumb(Context c, String file, int width, ImageView into) {
        Store.Att a = new Store.Att();
        a.file = file;
        thumb(c, a, width, into);
    }
}
