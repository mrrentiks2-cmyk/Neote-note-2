package com.neondrift.notes;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StrikethroughSpan;
import android.text.style.StyleSpan;
import android.view.View;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import java.util.ArrayList;
import java.util.List;

/** Строки заметки для виджета. */
public class WidgetService extends RemoteViewsService {
    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new Factory(getApplicationContext(), intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, 0));
    }

    static final class Row {
        CharSequence text;
        int line = -1;
        int box; // 0 — нет, 1 — пустая, 2 — отмечена
    }

    /** Разбить заметку на строки для виджета: галочки отдельно, стили сохраняются. */
    static List<Row> rows(String body) {
        ArrayList<Row> out = new ArrayList<>();
        Md.Rendered r = Md.render(body);
        String text = r.text;
        int[] lineOf = new int[text.length() + 1];
        int ln = 0;
        for (int i = 0; i < text.length(); i++) {
            lineOf[i] = ln;
            if (text.charAt(i) == '\n') ln++;
        }
        lineOf[text.length()] = ln;
        Md.Check[] checkAt = new Md.Check[ln + 1];
        for (Md.Check c : r.checks) checkAt[lineOf[c.pos]] = c;
        int start = 0, idx = 0;
        for (int i = 0; i <= text.length(); i++) {
            if (i < text.length() && text.charAt(i) != '\n') continue;
            Row row = new Row();
            int s = start, e = i;
            Md.Check c = idx < checkAt.length ? checkAt[idx] : null;
            if (c != null) {
                row.box = c.checked ? 2 : 1;
                row.line = c.line;
                s = Math.min(e, c.pos + 2); // без «☐ »
            }
            SpannableStringBuilder sb = new SpannableStringBuilder(text.substring(s, e));
            for (Md.Span sp : r.spans) {
                int a = Math.max(sp.start, s), b = Math.min(sp.end, e);
                if (b <= a) continue;
                Object o = style(sp.type);
                if (o != null) sb.setSpan(o, a - s, b - s, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                if (sp.type == Md.H1 || sp.type == Md.H2) sb.setSpan(new RelativeSizeSpan(sp.type == Md.H1 ? 1.25f : 1.12f), a - s, b - s, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                if (sp.type == Md.CHECKED) sb.setSpan(new ForegroundColorSpan(Theme.MUTED), a - s, b - s, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            row.text = sb;
            out.add(row);
            start = i + 1;
            idx++;
        }
        // убрать пустые строки в конце
        while (!out.isEmpty() && out.get(out.size() - 1).box == 0 && out.get(out.size() - 1).text.toString().trim().isEmpty()) out.remove(out.size() - 1);
        return out;
    }

    private static Object style(int type) {
        switch (type) {
            case Md.H1: case Md.H2: case Md.H3: case Md.BOLD: return new StyleSpan(android.graphics.Typeface.BOLD);
            case Md.ITALIC: case Md.QUOTE: return new StyleSpan(android.graphics.Typeface.ITALIC);
            case Md.STRIKE: case Md.CHECKED: return new StrikethroughSpan();
            case Md.TAG: case Md.BULLET: case Md.NUMBER: return new ForegroundColorSpan(Theme.ACCENT2);
            case Md.HIGHLIGHT: return new android.text.style.BackgroundColorSpan(Styler.HIGHLIGHT_BG);
            default: return null;
        }
    }

    static final class Factory implements RemoteViewsFactory {
        private final Context c;
        private final int widgetId;
        private List<Row> rows = new ArrayList<>();
        private long noteId;

        Factory(Context c, int widgetId) {
            this.c = c;
            this.widgetId = widgetId;
        }

        @Override
        public void onCreate() {
        }

        @Override
        public void onDataSetChanged() {
            Theme.load(c);
            noteId = new Prefs(c).widgetNote(widgetId);
            Note n = noteId > 0 ? Store.get(c).get(noteId) : null;
            if (n == null || n.locked || n.trashed > 0) {
                rows = new ArrayList<>();
                return;
            }
            String body = n.body;
            if (n.title.trim().isEmpty()) { // первая строка уже в заголовке виджета
                int nl = body.indexOf('\n');
                if (nl > 0 && !Md.CHECK_LINE.matcher(body.substring(0, nl)).matches()) body = body.substring(nl + 1);
            }
            rows = rows(body);
        }

        @Override
        public void onDestroy() {
        }

        @Override
        public int getCount() {
            return rows.size();
        }

        @Override
        public RemoteViews getViewAt(int position) {
            RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_row);
            if (position >= rows.size()) return rv;
            Row r = rows.get(position);
            rv.setTextViewText(R.id.r_text, r.text);
            if (r.box == 0) rv.setViewVisibility(R.id.r_box, View.GONE);
            else {
                rv.setViewVisibility(R.id.r_box, View.VISIBLE);
                rv.setImageViewResource(R.id.r_box, r.box == 2 ? R.drawable.ic_w_box_on : R.drawable.ic_w_box);
                rv.setInt(R.id.r_box, "setColorFilter", Theme.ACCENT);
            }
            Intent fill = new Intent().putExtra("note", noteId).putExtra("line", r.line).putExtra("check", r.box > 0);
            rv.setOnClickFillInIntent(R.id.r_root, fill);
            return rv;
        }

        @Override
        public RemoteViews getLoadingView() {
            return null;
        }

        @Override
        public int getViewTypeCount() {
            return 1;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public boolean hasStableIds() {
            return false;
        }
    }
}
