package com.neondrift.notes;

import java.io.DataInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Сейф для заметок под замком: ключ AES-256 выводится из PIN-кода (PBKDF2, 60 000 раундов),
 * текст шифруется AES-GCM. Сам PIN нигде не хранится — без него заметку не прочитать даже с доступом к файлам.
 */
final class Vault {
    private Vault() {}

    private static final SecureRandom RNG = new SecureRandom();
    static final String CHECK = "neon-notes-vault-v1";

    static byte[] salt() {
        byte[] s = new byte[16];
        RNG.nextBytes(s);
        return s;
    }

    static byte[] derive(String pin, byte[] salt) {
        try {
            PBEKeySpec spec = new PBEKeySpec(pin.toCharArray(), salt, 60_000, 256);
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException(e);
        }
    }

    static String seal(byte[] key, String plain) {
        try {
            byte[] nonce = new byte[12];
            RNG.nextBytes(nonce);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, nonce));
            byte[] ct = c.doFinal(plain.getBytes(StandardCharsets.UTF_8));
            byte[] out = new byte[12 + ct.length];
            System.arraycopy(nonce, 0, out, 0, 12);
            System.arraycopy(ct, 0, out, 12, ct.length);
            return "nv1:" + Base64.getEncoder().encodeToString(out);
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException(e);
        }
    }

    /** null — неверный ключ или повреждённые данные. */
    static String open(byte[] key, String sealed) {
        if (sealed == null || !sealed.startsWith("nv1:")) return null;
        try {
            byte[] b = Base64.getDecoder().decode(sealed.substring(4));
            if (b.length < 28) return null;
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, b, 0, 12));
            return new String(c.doFinal(b, 12, b.length - 12), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return null;
        }
    }

    static boolean isSealed(String s) {
        return s != null && s.startsWith("nv1:");
    }

    static boolean same(byte[] a, byte[] b) {
        return MessageDigest.isEqual(a, b);
    }

    /** Заголовок и текст вместе: первая строка — заголовок. */
    static String pack(String title, String body) {
        return (title == null ? "" : title.replace('\n', ' ')) + "\n" + (body == null ? "" : body);
    }

    static String[] unpack(String s) {
        int nl = s.indexOf('\n');
        return nl < 0 ? new String[]{s, ""} : new String[]{s.substring(0, nl), s.substring(nl + 1)};
    }

    // ================================================================== файлы (картинки, голос, рисунки)

    private static final byte[] MAGIC = {'N', 'V', 'F', '1'};
    private static final int CHUNK = 64 * 1024;

    /**
     * Шифрование потока кусками по 64 КБ: каждый кусок — отдельный AES-GCM со своим номером,
     * у последнего — особая метка. Так большие голосовые не нужно держать в памяти целиком,
     * а обрезанный или переставленный файл не расшифруется.
     */
    static void sealStream(byte[] key, InputStream in, OutputStream out) throws IOException {
        byte[] prefix = new byte[8];
        RNG.nextBytes(prefix);
        out.write(MAGIC);
        out.write(prefix);
        byte[] cur = new byte[CHUNK], next = new byte[CHUNK];
        int curLen = readFully(in, cur), index = 0;
        while (true) {
            int nextLen = curLen == CHUNK ? readFully(in, next) : 0;
            boolean last = nextLen == 0;
            out.write(chunk(key, Cipher.ENCRYPT_MODE, prefix, index++, last, cur, curLen));
            if (last) break;
            byte[] t = cur; cur = next; next = t;
            curLen = nextLen;
        }
    }

    /** Возвращает false, если ключ неверный или файл повреждён (тогда out может быть заполнен частично). */
    static boolean openStream(byte[] key, InputStream in, OutputStream out) throws IOException {
        DataInputStream din = new DataInputStream(in);
        byte[] magic = new byte[4], prefix = new byte[8];
        try {
            din.readFully(magic);
            din.readFully(prefix);
        } catch (EOFException e) {
            return false;
        }
        if (!java.util.Arrays.equals(magic, MAGIC)) return false;
        byte[] cur = new byte[CHUNK + 16], next = new byte[CHUNK + 16];
        int curLen = readFully(din, cur), index = 0;
        while (true) {
            if (curLen < 16) return false;
            int nextLen = curLen == CHUNK + 16 ? readFully(din, next) : 0;
            boolean last = nextLen == 0;
            byte[] plain = chunk(key, Cipher.DECRYPT_MODE, prefix, index++, last, cur, curLen);
            if (plain == null) return false;
            out.write(plain);
            if (last) return true;
            byte[] t = cur; cur = next; next = t;
            curLen = nextLen;
        }
    }

    static boolean isSealedFile(InputStream in) throws IOException {
        byte[] m = new byte[4];
        return readFully(in, m) == 4 && java.util.Arrays.equals(m, MAGIC);
    }

    private static byte[] chunk(byte[] key, int mode, byte[] prefix, int index, boolean last, byte[] data, int len) {
        try {
            byte[] nonce = new byte[12];
            System.arraycopy(prefix, 0, nonce, 0, 8);
            int n = index | (last ? 0x80000000 : 0);
            nonce[8] = (byte) (n >>> 24);
            nonce[9] = (byte) (n >>> 16);
            nonce[10] = (byte) (n >>> 8);
            nonce[11] = (byte) n;
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(mode, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, nonce));
            return c.doFinal(data, 0, len);
        } catch (GeneralSecurityException e) {
            if (mode == Cipher.DECRYPT_MODE) return null;
            throw new IllegalStateException(e);
        }
    }

    private static int readFully(InputStream in, byte[] buf) throws IOException {
        int n = 0;
        while (n < buf.length) {
            int r = in.read(buf, n, buf.length - n);
            if (r < 0) break;
            n += r;
        }
        return n;
    }
}
