package com.neondrift.notes;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * Отдаёт файлы другим приложениям по content://-ссылке: «Поделиться» картинкой или голосом,
 * снимок с камеры, экспорт заметки. Доступ только по выданному разрешению на конкретный файл.
 */
public class Files extends ContentProvider {
    static final String AUTHORITY = "com.neondrift.notes.files";

    static File root(Context c, String name) {
        switch (name) {
            case "att": return Media.dir(c);
            case "open": return Media.openDir(c);
            case "cam": return mk(new File(c.getCacheDir(), "cam"));
            case "share": return mk(new File(c.getCacheDir(), "share"));
            default: return null;
        }
    }

    private static File mk(File d) {
        if (!d.isDirectory()) d.mkdirs();
        return d;
    }

    static Uri uri(String root, String name) {
        return new Uri.Builder().scheme("content").authority(AUTHORITY).appendPath(root).appendPath(name).build();
    }

    /** Ссылка на файл для отправки: для вложений сейфа — на расшифрованную копию. */
    static Uri uri(Context c, Store.Att a) {
        if (!a.sealed()) return uri("att", a.file);
        File f = Media.plain(c, a);
        return f == null ? null : uri("open", f.getName());
    }

    private File resolve(Uri uri) throws FileNotFoundException {
        if (uri.getPathSegments().size() != 2) throw new FileNotFoundException(uri.toString());
        File r = root(getContext(), uri.getPathSegments().get(0));
        String name = uri.getPathSegments().get(1);
        if (r == null || name.contains("/") || name.startsWith(".") || name.endsWith(".nv")) throw new FileNotFoundException(uri.toString());
        File f = new File(r, name);
        try {
            if (!f.getCanonicalPath().startsWith(r.getCanonicalPath() + File.separator)) throw new FileNotFoundException(uri.toString());
        } catch (IOException e) {
            throw new FileNotFoundException(uri.toString());
        }
        return f;
    }

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        File f = resolve(uri);
        boolean write = mode.contains("w");
        if (write && !"cam".equals(uri.getPathSegments().get(0))) throw new FileNotFoundException("только чтение");
        return ParcelFileDescriptor.open(f, write ? ParcelFileDescriptor.MODE_READ_WRITE | ParcelFileDescriptor.MODE_CREATE
                | (mode.contains("t") ? ParcelFileDescriptor.MODE_TRUNCATE : 0) : ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] args, String sort) {
        File f;
        try {
            f = resolve(uri);
        } catch (FileNotFoundException e) {
            return null;
        }
        String[] cols = projection != null ? projection : new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE};
        MatrixCursor c = new MatrixCursor(cols, 1);
        Object[] row = new Object[cols.length];
        for (int i = 0; i < cols.length; i++) {
            if (OpenableColumns.DISPLAY_NAME.equals(cols[i])) row[i] = f.getName();
            else if (OpenableColumns.SIZE.equals(cols[i])) row[i] = f.length();
        }
        c.addRow(row);
        return c;
    }

    @Override
    public String getType(Uri uri) {
        return type(uri.getLastPathSegment());
    }

    static String type(String name) {
        String n = name == null ? "" : name.toLowerCase(java.util.Locale.ROOT);
        if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".m4a")) return "audio/mp4";
        if (n.endsWith(".md")) return "text/markdown";
        if (n.endsWith(".txt")) return "text/plain";
        if (n.endsWith(".zip")) return "application/zip";
        return "application/octet-stream";
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        throw new UnsupportedOperationException();
    }

    @Override
    public int delete(Uri uri, String s, String[] a) {
        throw new UnsupportedOperationException();
    }

    @Override
    public int update(Uri uri, ContentValues v, String s, String[] a) {
        throw new UnsupportedOperationException();
    }
}
