package com.neondrift.notes;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Разметка заметок (подмножество Markdown): заголовки, жирный, курсив, зачёркнутый, код, выделение,
 * списки, чек-листы, цитаты, разделители и #теги. Без зависимостей от Android — легко тестировать.
 */
final class Md {
    private Md() {}

    static final int H1 = 1, H2 = 2, H3 = 3, BOLD = 4, ITALIC = 5, STRIKE = 6, CODE = 7, HIGHLIGHT = 8, MARK = 9,
            QUOTE = 10, BULLET = 11, CHECK = 12, CHECKED = 13, RULE = 14, NUMBER = 15, CODEBLOCK = 16, TAG = 17, BOX = 18;

    static final class Span {
        final int start, end, type;

        Span(int start, int end, int type) {
            this.start = start;
            this.end = end;
            this.type = type;
        }

        @Override
        public String toString() {
            return type + "@" + start + "-" + end;
        }
    }

    /** Галочка в режиме чтения: где она на экране и к какой строке исходника относится. */
    static final class Check {
        final int pos, line;
        final boolean checked;

        Check(int pos, int line, boolean checked) {
            this.pos = pos;
            this.line = line;
            this.checked = checked;
        }
    }

    static final class Rendered {
        final String text;
        final List<Span> spans;
        final List<Check> checks;

        Rendered(String text, List<Span> spans, List<Check> checks) {
            this.text = text;
            this.spans = spans;
            this.checks = checks;
        }
    }

    static final Pattern CHECK_LINE = Pattern.compile("^(\\s*)([-*+]) \\[([ xX])\\] ?(.*)$");
    static final Pattern BULLET_LINE = Pattern.compile("^(\\s*)([-*+]) (.*)$");
    static final Pattern NUMBER_LINE = Pattern.compile("^(\\s*)(\\d{1,4})([.)]) (.*)$");
    static final Pattern HEADING = Pattern.compile("^(#{1,3}) (.*)$");
    static final Pattern QUOTE_LINE = Pattern.compile("^> ?(.*)$");
    static final Pattern RULE_LINE = Pattern.compile("^\\s*(-{3,}|\\*{3,}|_{3,})\\s*$");
    private static final Pattern TAG_P = Pattern.compile("(?<=^|[\\s(,;])#([\\p{L}][\\p{L}\\p{N}_-]{0,40})");

    private static final Pattern[] INLINE = {
            Pattern.compile("(\\*\\*|__)(?=\\S)(.+?)(?<=\\S)\\1"),                    // жирный
            Pattern.compile("(?<![*\\w])\\*(?=[^\\s*])(.+?)(?<=[^\\s*])\\*(?![*\\w])|(?<![_\\w])_(?=[^\\s_])(.+?)(?<=[^\\s_])_(?![_\\w])"), // курсив
            Pattern.compile("~~(?=\\S)(.+?)(?<=\\S)~~"),                              // зачёркнутый
            Pattern.compile("==(?=\\S)(.+?)(?<=\\S)=="),                              // выделение
    };
    private static final int[] INLINE_TYPES = {BOLD, ITALIC, STRIKE, HIGHLIGHT};
    private static final Pattern CODE_P = Pattern.compile("`([^`\\n]+)`");

    /** Разбить на строки, сохранив смещения начала каждой. */
    static List<int[]> lines(String text) {
        ArrayList<int[]> out = new ArrayList<>();
        int start = 0;
        for (int i = 0; i <= text.length(); i++) {
            if (i == text.length() || text.charAt(i) == '\n') {
                out.add(new int[]{start, i});
                start = i + 1;
            }
        }
        return out;
    }

    // ================================================================== подсветка в редакторе

    /** Стили для редактора: разметка остаётся видимой, но приглушается. */
    static List<Span> highlight(String text) {
        ArrayList<Span> out = new ArrayList<>();
        boolean code = false;
        for (int[] ln : lines(text)) {
            int s = ln[0], e = ln[1];
            String line = text.substring(s, e);
            if (line.trim().startsWith("```")) {
                out.add(new Span(s, e, MARK));
                out.add(new Span(s, e, CODEBLOCK));
                code = !code;
                continue;
            }
            if (code) {
                if (e > s) out.add(new Span(s, e, CODEBLOCK));
                continue;
            }
            int bodyStart = s;
            Matcher m;
            if ((m = HEADING.matcher(line)).matches()) {
                int lvl = m.group(1).length();
                out.add(new Span(s, s + lvl + 1, MARK));
                out.add(new Span(s, e, lvl == 1 ? H1 : lvl == 2 ? H2 : H3));
                bodyStart = s + lvl + 1;
            } else if (RULE_LINE.matcher(line).matches()) {
                out.add(new Span(s, e, MARK));
                out.add(new Span(s, e, RULE));
                continue;
            } else if ((m = CHECK_LINE.matcher(line)).matches()) {
                int ms = s + m.start(2), me = s + m.start(4);
                boolean done = !m.group(3).equals(" ");
                out.add(new Span(ms, Math.min(e, ms + 5), MARK));
                out.add(new Span(ms, Math.min(e, ms + 5), BOX));
                if (done && me < e) out.add(new Span(me, e, CHECKED));
                bodyStart = me;
            } else if ((m = BULLET_LINE.matcher(line)).matches()) {
                out.add(new Span(s + m.start(2), s + m.start(2) + 1, BULLET));
                bodyStart = s + m.start(3);
            } else if ((m = NUMBER_LINE.matcher(line)).matches()) {
                out.add(new Span(s + m.start(2), s + m.end(3), NUMBER));
                bodyStart = s + m.start(4);
            } else if ((m = QUOTE_LINE.matcher(line)).matches()) {
                out.add(new Span(s, s + m.start(1), MARK));
                out.add(new Span(s, e, QUOTE));
                bodyStart = s + m.start(1);
            }
            inline(text, bodyStart, e, out, true);
        }
        return out;
    }

    /**
     * Строчные стили. withMarks — добавить приглушение для служебных символов.
     * Возвращает диапазоны маркеров (чтобы в режиме чтения их вырезать).
     */
    private static List<int[]> inline(String text, int s, int e, List<Span> out, boolean withMarks) {
        ArrayList<int[]> marks = new ArrayList<>();
        if (e <= s) return marks;
        String line = text.substring(s, e);
        boolean[] prot = new boolean[line.length()];
        Matcher cm = CODE_P.matcher(line);
        while (cm.find()) {
            for (int i = cm.start(); i < cm.end(); i++) prot[i] = true;
            out.add(new Span(s + cm.start(1), s + cm.end(1), CODE));
            marks.add(new int[]{s + cm.start(), s + cm.start() + 1});
            marks.add(new int[]{s + cm.end() - 1, s + cm.end()});
        }
        for (int k = 0; k < INLINE.length; k++) {
            Matcher m = INLINE[k].matcher(line);
            while (m.find()) {
                if (prot[m.start()] || prot[m.end() - 1]) continue;
                // жирный: группа 2 — текст; курсив: *текст* в группе 1, _текст_ в группе 2; остальное — группа 1
                int g = k == 0 ? 2 : k == 1 ? (m.group(1) != null ? 1 : 2) : 1;
                int cs = m.start(g), ce = m.end(g);
                if (cs < 0) continue;
                out.add(new Span(s + cs, s + ce, INLINE_TYPES[k]));
                marks.add(new int[]{s + m.start(), s + cs});
                marks.add(new int[]{s + ce, s + m.end()});
            }
        }
        Matcher tm = TAG_P.matcher(line);
        while (tm.find()) {
            if (prot[tm.start()]) continue;
            out.add(new Span(s + tm.start(), s + tm.end(), TAG));
        }
        if (withMarks) for (int[] mk : marks) out.add(new Span(mk[0], mk[1], MARK));
        return marks;
    }

    // ================================================================== режим чтения

    /** Текст для чтения: служебные символы убраны, галочки кликабельные. */
    static Rendered render(String src) {
        StringBuilder sb = new StringBuilder();
        ArrayList<Span> spans = new ArrayList<>();
        ArrayList<Check> checks = new ArrayList<>();
        boolean code = false;
        List<int[]> ls = lines(src);
        for (int li = 0; li < ls.size(); li++) {
            int s = ls.get(li)[0], e = ls.get(li)[1];
            String line = src.substring(s, e);
            if (line.trim().startsWith("```")) {
                code = !code;
                continue; // строки с ``` в чтении не видны
            }
            if (sb.length() > 0) sb.append('\n');
            int base = sb.length();
            if (code) {
                sb.append(line);
                spans.add(new Span(base, sb.length(), CODEBLOCK));
                continue;
            }
            Matcher m;
            String prefix = "";
            int bodyStart = s, lineType = 0;
            boolean done = false;
            if ((m = HEADING.matcher(line)).matches()) {
                int lvl = m.group(1).length();
                lineType = lvl == 1 ? H1 : lvl == 2 ? H2 : H3;
                bodyStart = s + lvl + 1;
            } else if (RULE_LINE.matcher(line).matches()) {
                sb.append("────────────────");
                spans.add(new Span(base, sb.length(), RULE));
                continue;
            } else if ((m = CHECK_LINE.matcher(line)).matches()) {
                done = !m.group(3).equals(" ");
                prefix = m.group(1) + (done ? "☑" : "☐") + " ";
                checks.add(new Check(base + m.group(1).length(), li, done));
                bodyStart = s + m.start(4);
                lineType = done ? CHECKED : CHECK;
            } else if ((m = BULLET_LINE.matcher(line)).matches()) {
                prefix = m.group(1) + "•  ";
                bodyStart = s + m.start(3);
                lineType = BULLET;
            } else if ((m = NUMBER_LINE.matcher(line)).matches()) {
                prefix = m.group(1) + m.group(2) + m.group(3) + " ";
                bodyStart = s + m.start(4);
                lineType = NUMBER;
            } else if ((m = QUOTE_LINE.matcher(line)).matches()) {
                prefix = "▎ ";
                bodyStart = s + m.start(1);
                lineType = QUOTE;
            }
            sb.append(prefix);
            if (lineType == CHECK || lineType == CHECKED) spans.add(new Span(base + prefix.length() - 2, base + prefix.length() - 1, BOX));
            if (lineType == BULLET || lineType == NUMBER) spans.add(new Span(base, base + prefix.length(), lineType));
            int bodyOut = sb.length();
            // строчные стили: вырезаем маркеры и пересчитываем позиции
            ArrayList<Span> local = new ArrayList<>();
            List<int[]> marks = inline(src, bodyStart, e, local, false);
            boolean[] cut = new boolean[e - bodyStart];
            for (int[] mk : marks) for (int i = mk[0]; i < mk[1]; i++) if (i - bodyStart >= 0 && i - bodyStart < cut.length) cut[i - bodyStart] = true;
            int[] map = new int[e - bodyStart + 1];
            int out = 0;
            for (int i = 0; i < cut.length; i++) {
                map[i] = out;
                if (!cut[i]) {
                    sb.append(src.charAt(bodyStart + i));
                    out++;
                }
            }
            map[cut.length] = out;
            for (Span sp : local) {
                int a = map[sp.start - bodyStart], b = map[sp.end - bodyStart];
                if (b > a) spans.add(new Span(bodyOut + a, bodyOut + b, sp.type));
            }
            if (lineType == H1 || lineType == H2 || lineType == H3 || lineType == QUOTE) spans.add(new Span(base, sb.length(), lineType));
            if (lineType == CHECKED && sb.length() > bodyOut) spans.add(new Span(bodyOut, sb.length(), CHECKED));
        }
        return new Rendered(sb.toString(), spans, checks);
    }

    // ================================================================== чек-листы и списки

    /** Отметить или снять галочку в строке lineIndex. */
    static String toggleCheck(String text, int lineIndex) {
        List<int[]> ls = lines(text);
        if (lineIndex < 0 || lineIndex >= ls.size()) return text;
        int s = ls.get(lineIndex)[0], e = ls.get(lineIndex)[1];
        Matcher m = CHECK_LINE.matcher(text.substring(s, e));
        if (!m.matches()) return text;
        int pos = s + m.start(3);
        char now = text.charAt(pos);
        return text.substring(0, pos) + (now == ' ' ? 'x' : ' ') + text.substring(pos + 1);
    }

    static final String END_LIST = "\u0000";

    /**
     * Что подставить в начало новой строки после Enter: продолжение списка,
     * END_LIST — пустой пункт (список закончить), null — ничего.
     */
    static String continueList(String prevLine) {
        Matcher m;
        if ((m = CHECK_LINE.matcher(prevLine)).matches()) {
            return m.group(4).trim().isEmpty() ? END_LIST : m.group(1) + m.group(2) + " [ ] ";
        }
        if ((m = BULLET_LINE.matcher(prevLine)).matches()) {
            return m.group(3).trim().isEmpty() ? END_LIST : m.group(1) + m.group(2) + " ";
        }
        if ((m = NUMBER_LINE.matcher(prevLine)).matches()) {
            if (m.group(4).trim().isEmpty()) return END_LIST;
            return m.group(1) + (Integer.parseInt(m.group(2)) + 1) + m.group(3) + " ";
        }
        if (prevLine.startsWith("> ")) return prevLine.trim().equals(">") ? END_LIST : "> ";
        return null;
    }

    /** Выполненные пункты — в конец каждого списка (порядок внутри групп сохраняется). */
    static String sortChecked(String text) {
        String[] lines = text.split("\n", -1);
        ArrayList<String> out = new ArrayList<>();
        int i = 0;
        while (i < lines.length) {
            if (!CHECK_LINE.matcher(lines[i]).matches()) {
                out.add(lines[i++]);
                continue;
            }
            ArrayList<String> open = new ArrayList<>(), done = new ArrayList<>();
            while (i < lines.length && CHECK_LINE.matcher(lines[i]).matches()) {
                Matcher m = CHECK_LINE.matcher(lines[i]);
                m.matches();
                (m.group(3).equals(" ") ? open : done).add(lines[i]);
                i++;
            }
            out.addAll(open);
            out.addAll(done);
        }
        return String.join("\n", out);
    }

    /** {выполнено, всего} пунктов чек-листа. */
    static int[] progress(String text) {
        int done = 0, total = 0;
        for (String l : text.split("\n")) {
            Matcher m = CHECK_LINE.matcher(l);
            if (m.matches()) {
                total++;
                if (!m.group(3).equals(" ")) done++;
            }
        }
        return new int[]{done, total};
    }

    /** Превратить обычный текст в чек-лист (и обратно, если он уже чек-лист). */
    static String toggleChecklist(String text) {
        String[] lines = text.split("\n", -1);
        boolean allChecks = true, any = false;
        for (String l : lines) {
            if (l.trim().isEmpty()) continue;
            any = true;
            if (!CHECK_LINE.matcher(l).matches()) allChecks = false;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < lines.length; i++) {
            String l = lines[i];
            if (i > 0) sb.append('\n');
            if (l.trim().isEmpty()) {
                sb.append(l);
                continue;
            }
            Matcher m;
            if (allChecks && any && (m = CHECK_LINE.matcher(l)).matches()) {
                sb.append(m.group(1)).append(m.group(4));
            } else if ((m = BULLET_LINE.matcher(l)).matches() && !CHECK_LINE.matcher(l).matches()) {
                sb.append(m.group(1)).append("- [ ] ").append(m.group(3));
            } else if (!CHECK_LINE.matcher(l).matches()) {
                sb.append("- [ ] ").append(l.trim());
            } else {
                sb.append(l);
            }
        }
        return sb.toString();
    }

    // ================================================================== теги и простой текст

    static Set<String> tags(String text) {
        LinkedHashSet<String> out = new LinkedHashSet<>();
        if (text == null) return out;
        boolean code = false;
        for (String line : text.split("\n")) {
            if (line.trim().startsWith("```")) {
                code = !code;
                continue;
            }
            if (code) continue;
            String l = line.replaceAll("`[^`]*`", " ").replaceAll("https?://\\S+", " ");
            Matcher m = TAG_P.matcher(l);
            while (m.find()) out.add(m.group(1).toLowerCase(Locale.ROOT));
        }
        return out;
    }

    /** Текст без разметки — для карточек, виджета и поиска. */
    static String plain(String text) {
        if (text == null || text.isEmpty()) return "";
        return render(text).text;
    }

    static int words(String text) {
        if (text == null) return 0;
        Matcher m = Pattern.compile("[\\p{L}\\p{N}]+(?:['’-][\\p{L}\\p{N}]+)*").matcher(text);
        int n = 0;
        while (m.find()) n++;
        return n;
    }

    /** Строки чек-листа для карточки: [текст, отмечено ли]. */
    static List<Object[]> checkItems(String text) {
        ArrayList<Object[]> out = new ArrayList<>();
        for (String l : text.split("\n")) {
            Matcher m = CHECK_LINE.matcher(l);
            if (m.matches()) out.add(new Object[]{plain(m.group(4)), !m.group(3).equals(" ")});
        }
        return out;
    }

    /** Заметка почти целиком из пунктов чек-листа? Тогда в карточке рисуем галочки. */
    static boolean isChecklist(String text) {
        int checks = 0, other = 0;
        for (String l : text.split("\n")) {
            if (l.trim().isEmpty()) continue;
            if (CHECK_LINE.matcher(l).matches()) checks++;
            else other++;
        }
        return checks > 0 && checks >= other * 2;
    }
}
